package com.example.engine

import com.example.model.AppLanguage
import com.example.model.ConcreteMixGrade
import com.example.model.EngineeringUnit
import com.example.model.MaterialPriceEntity
import com.example.model.ProjectEntity
import com.example.model.TileLayoutPattern
import com.example.model.UnitDimension
import com.example.model.bi

enum class ToolGroup(val id: String, val titleFa: String, val titleEn: String) {
    GENERAL("general", "۱. محاسبات عمومی ساختمان", "1. General Building"),
    CONCRETE("concrete", "۲. بتن و مصالح", "2. Concrete & Materials"),
    STEEL("steel", "۳. آهن‌آلات و اسکلت", "3. Steel & Rebar"),
    MASONRY("masonry", "۴. دیوارچینی", "4. Masonry & Walls"),
    FINISHING("finishing", "۵. نازک‌کاری", "5. Finishing & Surfaces"),
    MEP("mep", "۶. تأسیسات و تجهیزات", "6. MEP & Fixtures"),
    COST_BOQ("cost_boq", "۷. هزینه و مدیریت پروژه", "7. Cost & Project BOQ");

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

enum class ToolId(val number: Int, val group: ToolGroup) {
    // Group 1: General Building (1-6)
    LAND_AREA(1, ToolGroup.GENERAL),
    BUILT_UP_AREA(2, ToolGroup.GENERAL),
    BUILDING_VOLUME(3, ToolGroup.GENERAL),
    TOTAL_CONCRETE_VOLUME(4, ToolGroup.GENERAL),
    EXCAVATION_VOLUME(5, ToolGroup.GENERAL),
    BACKFILL_VOLUME(6, ToolGroup.GENERAL),

    // Group 2: Concrete & Materials (7-14)
    FOUNDATION_CONCRETE(7, ToolGroup.CONCRETE),
    COLUMN_CONCRETE(8, ToolGroup.CONCRETE),
    BEAM_CONCRETE(9, ToolGroup.CONCRETE),
    SLAB_CONCRETE(10, ToolGroup.CONCRETE),
    STAIRCASE_CONCRETE(11, ToolGroup.CONCRETE),
    CONCRETE_MIX_MATERIALS(12, ToolGroup.CONCRETE),
    MORTAR_MATERIALS(13, ToolGroup.CONCRETE),
    CONCRETE_WEIGHT(14, ToolGroup.CONCRETE),

    // Group 3: Steel & Rebar (15-20)
    REBAR_WEIGHT(15, ToolGroup.STEEL),
    CUT_REBAR_LIST(16, ToolGroup.STEEL),
    STEEL_PROFILE_WEIGHT(17, ToolGroup.STEEL),
    IBEAM_WEIGHT(18, ToolGroup.STEEL),
    STEEL_PLATE_WEIGHT(19, ToolGroup.STEEL),
    TOTAL_PROJECT_STEEL(20, ToolGroup.STEEL),

    // Group 4: Masonry & Walls (21-25)
    BRICK_COUNT(21, ToolGroup.MASONRY),
    CEMENT_BLOCK_COUNT(22, ToolGroup.MASONRY),
    AAC_HEBELX_BLOCK_COUNT(23, ToolGroup.MASONRY),
    MASONRY_MORTAR_VOLUME(24, ToolGroup.MASONRY),
    WALL_NET_AREA(25, ToolGroup.MASONRY),

    // Group 5: Finishing (26-33)
    GYPSUM_SOIL_PLASTER(26, ToolGroup.FINISHING),
    WHITE_PLASTER(27, ToolGroup.FINISHING),
    BUILDING_PAINT(28, ToolGroup.FINISHING),
    FLOOR_CERAMIC(29, ToolGroup.FINISHING),
    WALL_TILE(30, ToolGroup.FINISHING),
    FACADE_STONE(31, ToolGroup.FINISHING),
    FLOOR_STONE(32, ToolGroup.FINISHING),
    SKIRTING_BASEBOARD(33, ToolGroup.FINISHING),

    // Group 6: MEP & Fixtures (34-38)
    PLUMBING_PIPES(34, ToolGroup.MEP),
    ELECTRICAL_CABLES(35, ToolGroup.MEP),
    SWITCHES_OUTLETS(36, ToolGroup.MEP),
    LIGHTING_FIXTURES(37, ToolGroup.MEP),
    SANITARY_FIXTURES(38, ToolGroup.MEP),

    // Group 7: Cost & BOQ (39-40)
    MATERIAL_COST(39, ToolGroup.COST_BOQ),
    FINAL_PROJECT_BOQ(40, ToolGroup.COST_BOQ)
}

data class InputFieldSpec(
    val key: String,
    val labelFa: String,
    val labelEn: String,
    val defaultValue: Double,
    val defaultUnit: EngineeringUnit,
    val allowedUnits: List<EngineeringUnit> = emptyList(),
    val allowZero: Boolean = false,
    val isInteger: Boolean = false,
    val hintFa: String = "",
    val hintEn: String = ""
) {
    fun label(lang: AppLanguage): String = bi(lang, labelFa, labelEn)
}

data class ToolDefinition(
    val id: ToolId,
    val titleFa: String,
    val titleEn: String,
    val subtitleFa: String,
    val subtitleEn: String,
    val formulaFa: String,
    val formulaEn: String,
    val standardRef: String,
    val fields: List<InputFieldSpec>,
    val supportsMixGrade: Boolean = false,
    val supportsTilePattern: Boolean = false,
    val supportsIBeamPicker: Boolean = false,
    val supportsProfilePicker: Boolean = false,
    val supportsCutRebarList: Boolean = false,
    val supportsMaterialCostList: Boolean = false,
    val isStructuralAdvisory: Boolean = false
) {
    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
    fun subtitle(lang: AppLanguage): String = bi(lang, subtitleFa, subtitleEn)
    fun formula(lang: AppLanguage): String = bi(lang, formulaFa, formulaEn)
}

data class DynamicCutRebarRow(
    val id: Int,
    val diameterMm: Int = 14,
    val lengthM: Double = 6.0,
    val count: Int = 10
)

data class DynamicCostRow(
    val id: Int,
    val materialKey: String,
    val nameFa: String,
    val nameEn: String,
    val quantity: Double,
    val unit: EngineeringUnit,
    val unitPrice: Double
)

data class CalculationInput(
    val values: Map<String, Double> = emptyMap(),
    val units: Map<String, EngineeringUnit> = emptyMap(),
    val mixGrade: ConcreteMixGrade = ConcreteMixGrade.M20_1_15_3,
    val tilePattern: TileLayoutPattern = TileLayoutPattern.STRAIGHT,
    val selectedIBeamCode: String = "IPE180",
    val selectedProfileCode: String = "BOX_60x60x2",
    val cutRebarRows: List<DynamicCutRebarRow> = listOf(
        DynamicCutRebarRow(1, 16, 12.0, 20),
        DynamicCutRebarRow(2, 10, 4.5, 40)
    ),
    val costRows: List<DynamicCostRow> = emptyList(),
    val project: ProjectEntity? = null,
    val savedProjectRecords: List<com.example.model.CalculationRecordEntity> = emptyList(),
    val priceCatalog: Map<String, MaterialPriceEntity> = emptyMap(),
    val wastePercentOverride: Double? = null
)

data class CalculationStep(
    val titleFa: String,
    val titleEn: String,
    val expression: String,
    val resultFormatted: String
) {
    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

data class MaterialEstimate(
    val materialKey: String,
    val nameFa: String,
    val nameEn: String,
    val netQuantity: Double,
    val wastePercent: Double,
    val orderQuantity: Double,
    val unit: EngineeringUnit,
    val packageLabelFa: String = "",
    val packageLabelEn: String = "",
    val packageCount: Double = 0.0,
    val unitPrice: Double = 0.0,
    val totalCost: Double = 0.0
) {
    fun name(lang: AppLanguage): String = bi(lang, nameFa, nameEn)
    fun packageLabel(lang: AppLanguage): String = bi(lang, packageLabelFa, packageLabelEn)
}

data class ResultMetric(
    val labelFa: String,
    val labelEn: String,
    val value: Double,
    val unit: EngineeringUnit
) {
    fun label(lang: AppLanguage): String = bi(lang, labelFa, labelEn)
}

data class CalculationOutcome(
    val toolId: ToolId,
    val isSuccess: Boolean,
    val errorFa: String? = null,
    val errorEn: String? = null,
    val isPreliminary: Boolean = false,
    val preliminaryReasonFa: String? = null,
    val preliminaryReasonEn: String? = null,
    val primaryLabelFa: String = "",
    val primaryLabelEn: String = "",
    val primaryValue: Double = 0.0,
    val primaryUnit: EngineeringUnit = EngineeringUnit.M3,
    val secondaryMetrics: List<ResultMetric> = emptyList(),
    val materials: List<MaterialEstimate> = emptyList(),
    val steps: List<CalculationStep> = emptyList(),
    val assumptionsFa: List<String> = emptyList(),
    val assumptionsEn: List<String> = emptyList(),
    val limitationsFa: List<String> = emptyList(),
    val limitationsEn: List<String> = emptyList(),
    val formulaUsed: String = "",
    val standardRef: String = "",
    val totalEstimatedCost: Double = 0.0
) {
    fun error(lang: AppLanguage): String? = if (lang == AppLanguage.FA) errorFa else errorEn
    fun preliminaryReason(lang: AppLanguage): String? =
        if (lang == AppLanguage.FA) preliminaryReasonFa else preliminaryReasonEn
    fun primaryLabel(lang: AppLanguage): String = bi(lang, primaryLabelFa, primaryLabelEn)
    fun assumptions(lang: AppLanguage): List<String> = if (lang == AppLanguage.FA) assumptionsFa else assumptionsEn
    fun limitations(lang: AppLanguage): List<String> = if (lang == AppLanguage.FA) limitationsFa else limitationsEn
}

val lengthUnits = UnitConverter.unitsForDimension(UnitDimension.LENGTH)
val areaUnits = listOf(EngineeringUnit.M2)
val volumeUnits = listOf(EngineeringUnit.M3)
val massUnits = UnitConverter.unitsForDimension(UnitDimension.MASS)
