package com.example.export

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import com.example.engine.CalcHelper
import com.example.engine.UnitConverter.formatNumber
import com.example.model.AppLanguage
import com.example.model.CalculationRecordEntity
import com.example.engine.MaterialEstimate
import com.example.model.ProjectEntity
import com.example.model.UserSettings
import com.example.model.bi
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportExporter {

    private fun dateStr(ts: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ts))

    /**
     * Generates a real multi-page engineering PDF report via Android's native PdfDocument API.
     * Page 1: Project overview & building specifications.
     * Subsequent pages: Calculation records, material BOQ table, costs, assumptions & warnings.
     */
    fun generatePdfBytes(
        project: ProjectEntity?,
        records: List<CalculationRecordEntity>,
        settings: UserSettings
    ): ByteArray {
        return try {
            generateNativeAndroidPdfBytes(project, records, settings)
        } catch (_: Throwable) {
            generatePureKotlinFallbackPdf(project, records, settings)
        }
    }

    private fun generateNativeAndroidPdfBytes(
        project: ProjectEntity?,
        records: List<CalculationRecordEntity>,
        settings: UserSettings
    ): ByteArray {
        val lang = settings.language
        val doc = PdfDocument()
        val pageW = 595 // A4 width in pt
        val pageH = 842 // A4 height in pt
        val margin = 40f

        val headerBg = Paint().apply { color = Color.rgb(10, 21, 49) }
        val accentPaint = Paint().apply { color = Color.rgb(249, 115, 22) }
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitlePaint = Paint().apply {
            color = Color.rgb(148, 163, 184)
            textSize = 11f
        }
        val sectionPaint = Paint().apply {
            color = Color.rgb(15, 29, 61)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
        }
        val bodyPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 10.5f
        }
        val boldBodyPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
        }
        val linePaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }
        val warnPaint = Paint().apply {
            color = Color.rgb(180, 83, 9)
            textSize = 9.5f
        }

        // ===== PAGE 1: Cover & Project Specs =====
        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
        var canvas = page.canvas

        canvas.drawRect(0f, 0f, pageW.toFloat(), 110f, headerBg)
        canvas.drawRect(0f, 106f, pageW.toFloat(), 110f, accentPaint)
        canvas.drawText("BUILD MASTER — Engineering BOQ Report", margin, 46f, titlePaint)
        canvas.drawText(
            "Generated: ${dateStr(System.currentTimeMillis())} | Designed by Ghasem Gholamrezapour",
            margin, 72f, subtitlePaint
        )
        canvas.drawText(
            bi(lang, "گزارش مهندسی متره، برآورد مصالح و هزینه", "Precision Engineering & Material Estimation"),
            margin, 92f, subtitlePaint
        )

        var y = 140f
        canvas.drawText(bi(lang, "مشخصات پروژه (Project Specifications)", "1. Project Specifications"), margin, y, sectionPaint)
        y += 12f
        canvas.drawLine(margin, y, pageW - margin, y, linePaint)
        y += 20f

        val specs = if (project != null) {
            listOf(
                "Project Name" to project.name,
                "Location" to project.location.ifBlank { "-" },
                "Building Type" to project.buildingType.titleEn,
                "Floors / Units" to "${project.floorsCount} floors / ${project.unitsCount} units",
                "Land Dimensions" to "${formatNumber(project.landLengthM)} × ${formatNumber(project.landWidthM)} m (Area: ${formatNumber(project.effectiveLandAreaM2)} m²)",
                "Built-up Area" to "${formatNumber(project.floorBuiltUpAreaM2)} m²/floor (Total: ${formatNumber(project.effectiveTotalBuiltUpAreaM2)} m²)",
                "Floor Height" to "${formatNumber(project.floorHeightM)} m",
                "Frame / Slab" to "${project.frameType.titleEn} / ${project.slabType.titleEn}",
                "Wall / Foundation" to "${project.wallType.titleEn} (${formatNumber(project.wallThicknessCm)} cm) / ${project.foundationType.titleEn}",
                "Rooms / Baths / Kitchens" to "${project.roomsCount} / ${project.bathroomsCount} / ${project.kitchensCount}"
            )
        } else {
            listOf("Project" to "General / All Unlinked Calculations")
        }

        specs.forEach { (k, v) ->
            canvas.drawText("$k:", margin, y, boldBodyPaint)
            canvas.drawText(v.take(65), margin + 150f, y, bodyPaint)
            y += 20f
        }

        if (project != null && project.missingCriticalFields(AppLanguage.EN).isNotEmpty()) {
            y += 8f
            canvas.drawText(
                "WARNING: Incomplete project specs (${project.missingCriticalFields(AppLanguage.EN).joinToString(", ")}). Dependent estimates are preliminary.",
                margin, y, warnPaint
            )
            y += 20f
        }

        // Summary KPIs on Page 1
        y += 16f
        canvas.drawText("2. Executive Summary", margin, y, sectionPaint)
        y += 12f
        canvas.drawLine(margin, y, pageW - margin, y, linePaint)
        y += 22f
        val totalCost = records.sumOf { it.estimatedCost }
        canvas.drawText("Total Saved Calculations: ${records.size}", margin, y, bodyPaint); y += 18f
        canvas.drawText("Total Estimated Material Cost: ${formatNumber(totalCost, 0)} ${settings.currencySymbolEn}", margin, y, boldBodyPaint); y += 22f
        canvas.drawText("Engineering Notice: All structural sizes must be verified by a licensed structural engineer.", margin, y, warnPaint)

        doc.finishPage(page)

        // ===== SUBSEQUENT PAGES: Calculations & Materials Table =====
        fun newPage(): PdfDocument.Page {
            pageNum++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNum).create())
            p.canvas.drawRect(0f, 0f, pageW.toFloat(), 44f, headerBg)
            p.canvas.drawText("BUILD MASTER — Calculations & Materials (Page $pageNum)", margin, 28f, subtitlePaint.apply { color = Color.WHITE })
            return p
        }

        page = newPage()
        canvas = page.canvas
        y = 74f

        canvas.drawText("3. Calculation History & Formulas (${records.size})", margin, y, sectionPaint)
        y += 14f
        canvas.drawLine(margin, y, pageW - margin, y, linePaint)
        y += 18f

        val aggregatedMaterials = linkedMapOf<String, MaterialEstimate>()

        records.forEachIndexed { idx, rec ->
            if (y > pageH - 110f) {
                doc.finishPage(page)
                page = newPage()
                canvas = page.canvas
                y = 74f
            }
            val tag = if (rec.isPreliminary) "[PRELIMINARY]" else "[VERIFIED]"
            canvas.drawText("${idx + 1}. ${rec.toolTitleEn} $tag", margin, y, boldBodyPaint)
            y += 15f
            canvas.drawText(
                "Result: ${formatNumber(rec.primaryValue, 2)} ${rec.primaryUnit.symbolEn} | Formula: ${rec.formulaUsed.take(45)}",
                margin + 12f, y, bodyPaint
            )
            y += 15f
            if (rec.estimatedCost > 0) {
                canvas.drawText("Est. Cost: ${formatNumber(rec.estimatedCost, 0)} ${settings.currencySymbolEn}", margin + 12f, y, bodyPaint)
                y += 15f
            }
            canvas.drawLine(margin, y, pageW - margin, y, linePaint)
            y += 14f

            CalcHelper.parseMaterialsFromJson(rec.payloadJson).forEach { m ->
                val prev = aggregatedMaterials[m.materialKey]
                aggregatedMaterials[m.materialKey] = m.copy(
                    netQuantity = (prev?.netQuantity ?: 0.0) + m.netQuantity,
                    orderQuantity = (prev?.orderQuantity ?: 0.0) + m.orderQuantity,
                    totalCost = (prev?.totalCost ?: 0.0) + m.totalCost
                )
            }
        }

        if (aggregatedMaterials.isNotEmpty()) {
            if (y > pageH - 140f) {
                doc.finishPage(page)
                page = newPage()
                canvas = page.canvas
                y = 74f
            }
            y += 12f
            canvas.drawText("4. Consolidated Materials Schedule (BOQ)", margin, y, sectionPaint)
            y += 14f
            canvas.drawLine(margin, y, pageW - margin, y, linePaint)
            y += 18f
            canvas.drawText("Material", margin, y, boldBodyPaint)
            canvas.drawText("Net Qty", margin + 210f, y, boldBodyPaint)
            canvas.drawText("Order Qty", margin + 295f, y, boldBodyPaint)
            canvas.drawText("Est. Cost", margin + 400f, y, boldBodyPaint)
            y += 14f
            canvas.drawLine(margin, y, pageW - margin, y, linePaint)
            y += 15f

            aggregatedMaterials.values.forEach { m ->
                if (y > pageH - 60f) {
                    doc.finishPage(page)
                    page = newPage()
                    canvas = page.canvas
                    y = 74f
                }
                canvas.drawText(m.nameEn.take(32), margin, y, bodyPaint)
                canvas.drawText("${formatNumber(m.netQuantity)} ${m.unit.symbolEn}", margin + 210f, y, bodyPaint)
                canvas.drawText("${formatNumber(m.orderQuantity)} ${m.unit.symbolEn}", margin + 295f, y, bodyPaint)
                canvas.drawText(formatNumber(m.totalCost, 0), margin + 400f, y, bodyPaint)
                y += 17f
            }
        }

        doc.finishPage(page)
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    private fun generatePureKotlinFallbackPdf(
        project: ProjectEntity?,
        records: List<CalculationRecordEntity>,
        settings: UserSettings
    ): ByteArray {
        val lines = mutableListOf<String>()
        lines += "BUILD MASTER - Engineering BOQ Report"
        lines += "Project: ${project?.name ?: "General"} | Records: ${records.size}"
        lines += "Total Cost: ${formatNumber(records.sumOf { it.estimatedCost }, 0)} ${settings.currencySymbolEn}"
        records.take(25).forEachIndexed { idx, r ->
            lines += "${idx + 1}. ${r.toolTitleEn}: ${formatNumber(r.primaryValue, 2)} ${r.primaryUnit.symbolEn}"
        }
        val streamContent = buildString {
            append("BT\n/F1 11 Tf\n50 780 Td\n16 TL\n")
            lines.forEach { l ->
                val clean = l.replace("(", "[").replace(")", "]").replace("\\", "/")
                append("($clean) Tj T*\n")
            }
            append("ET")
        }
        val objs = listOf(
            "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n",
            "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n",
            "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj\n",
            "4 0 obj << /Length ${streamContent.length} >> stream\n$streamContent\nendstream endobj\n",
            "5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n"
        )
        val sb = StringBuilder("%PDF-1.4\n")
        val offsets = mutableListOf<Int>()
        objs.forEach { obj ->
            offsets += sb.length
            sb.append(obj)
        }
        val xrefPos = sb.length
        sb.append("xref\n0 ${objs.size + 1}\n0000000000 65535 f \n")
        offsets.forEach { off -> sb.append(String.format(Locale.US, "%010d 00000 n \n", off)) }
        sb.append("trailer << /Size ${objs.size + 1} /Root 1 0 R >>\nstartxref\n$xrefPos\n%%EOF")
        return sb.toString().toByteArray(Charsets.ISO_8859_1)
    }

    /**
     * Generates a real Excel-compatible SpreadsheetML XML (.xls) workbook with UTF-8 Persian & English support.
     * Contains 3 sheets: Project Specs, Calculations, and Materials BOQ.
     */
    fun generateExcelXml(
        project: ProjectEntity?,
        records: List<CalculationRecordEntity>,
        settings: UserSettings
    ): String {
        fun esc(s: String): String = s
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")

        fun cellStr(v: String, style: String = "sDefault") =
            "<Cell ss:StyleID=\"$style\"><Data ss:Type=\"String\">${esc(v)}</Data></Cell>"

        fun cellNum(v: Double, style: String = "sNum") =
            "<Cell ss:StyleID=\"$style\"><Data ss:Type=\"Number\">$v</Data></Cell>"

        val sb = StringBuilder()
        sb.append(
            """<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Styles>
  <Style ss:ID="sHeader"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#0A1531" ss:Pattern="Solid"/></Style>
  <Style ss:ID="sDefault"><Font ss:Size="10"/></Style>
  <Style ss:ID="sNum"><NumberFormat ss:Format="#,##0.##"/></Style>
 </Styles>
"""
        )

        // Sheet 1: Project
        sb.append("<Worksheet ss:Name=\"Project\"><Table>")
        sb.append("<Row>${cellStr("Field / مشخصه", "sHeader")}${cellStr("Value / مقدار", "sHeader")}</Row>")
        if (project != null) {
            listOf(
                "Project Name / نام پروژه" to project.name,
                "Location / محل" to project.location,
                "Type / کاربری" to "${project.buildingType.titleFa} (${project.buildingType.titleEn})",
                "Floors / طبقات" to project.floorsCount.toString(),
                "Units / واحدها" to project.unitsCount.toString(),
                "Land Area (m²)" to formatNumber(project.effectiveLandAreaM2),
                "Built-up Area (m²)" to formatNumber(project.effectiveTotalBuiltUpAreaM2),
                "Frame / اسکلت" to project.frameType.titleFa,
                "Slab / سقف" to project.slabType.titleFa,
                "Foundation / فونداسیون" to project.foundationType.titleFa
            ).forEach { (k, v) ->
                sb.append("<Row>${cellStr(k)}${cellStr(v)}</Row>")
            }
        } else {
            sb.append("<Row>${cellStr("Project")}${cellStr("All Projects / Unlinked")}</Row>")
        }
        sb.append("</Table></Worksheet>")

        // Sheet 2: Calculations
        sb.append("<Worksheet ss:Name=\"Calculations\"><Table>")
        sb.append("<Row>${cellStr("#", "sHeader")}${cellStr("Tool (FA)", "sHeader")}${cellStr("Tool (EN)", "sHeader")}${cellStr("Result", "sHeader")}${cellStr("Unit", "sHeader")}${cellStr("Formula", "sHeader")}${cellStr("Status", "sHeader")}${cellStr("Cost", "sHeader")}</Row>")
        records.forEachIndexed { idx, r ->
            val status = if (r.isPreliminary) "برآورد اولیه / Preliminary" else "تأیید هندسی / Verified"
            sb.append("<Row>")
            sb.append(cellNum((idx + 1).toDouble()))
            sb.append(cellStr(r.toolTitleFa))
            sb.append(cellStr(r.toolTitleEn))
            sb.append(cellNum(r.primaryValue))
            sb.append(cellStr(r.primaryUnit.symbol(settings.language)))
            sb.append(cellStr(r.formulaUsed))
            sb.append(cellStr(status))
            sb.append(cellNum(r.estimatedCost))
            sb.append("</Row>")
        }
        sb.append("</Table></Worksheet>")

        // Sheet 3: Materials BOQ
        val mats = linkedMapOf<String, MaterialEstimate>()
        records.forEach { r ->
            CalcHelper.parseMaterialsFromJson(r.payloadJson).forEach { m ->
                val prev = mats[m.materialKey]
                mats[m.materialKey] = m.copy(
                    netQuantity = (prev?.netQuantity ?: 0.0) + m.netQuantity,
                    orderQuantity = (prev?.orderQuantity ?: 0.0) + m.orderQuantity,
                    totalCost = (prev?.totalCost ?: 0.0) + m.totalCost
                )
            }
        }
        sb.append("<Worksheet ss:Name=\"Materials_BOQ\"><Table>")
        sb.append("<Row>${cellStr("Material (FA)", "sHeader")}${cellStr("Material (EN)", "sHeader")}${cellStr("Net Qty", "sHeader")}${cellStr("Order Qty", "sHeader")}${cellStr("Unit", "sHeader")}${cellStr("Est. Cost", "sHeader")}</Row>")
        mats.values.forEach { m ->
            sb.append("<Row>")
            sb.append(cellStr(m.nameFa))
            sb.append(cellStr(m.nameEn))
            sb.append(cellNum(m.netQuantity))
            sb.append(cellNum(m.orderQuantity))
            sb.append(cellStr(m.unit.symbolEn))
            sb.append(cellNum(m.totalCost))
            sb.append("</Row>")
        }
        sb.append("</Table></Worksheet>")

        sb.append("</Workbook>")
        return sb.toString()
    }

    fun writeTempCacheFile(context: Context, fileName: String, bytes: ByteArray): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)
        FileOutputStream(file).use { it.write(bytes) }
        return file
    }

    fun printReport(
        context: Context,
        project: ProjectEntity?,
        records: List<CalculationRecordEntity>,
        settings: UserSettings
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val pdfBytes = generatePdfBytes(project, records, settings)
        val jobName = "BUILD_MASTER_${project?.name ?: "Report"}"
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback
            ) {
                try {
                    val out: OutputStream = FileOutputStream(destination.fileDescriptor)
                    out.write(pdfBytes)
                    out.close()
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                }
            }
        }
        printManager.print(jobName, adapter, null)
    }
}
