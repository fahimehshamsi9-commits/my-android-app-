package com.example.engine

import com.example.model.AppLanguage
import com.example.model.EngineeringUnit
import com.example.model.ProjectEntity

/**
 * Central deterministic engineering Calculation Engine for all 40 tools.
 */
object CalculationEngine {

    fun calculate(toolId: ToolId, input: CalculationInput): CalculationOutcome {
        val def = ToolCatalog.get(toolId)
        CalcHelper.validateInputs(def, input)?.let { return it }

        val rawOutcome = if (toolId.number <= 25) {
            CalculationEnginePart1.execute(def, input)
        } else {
            CalculationEnginePart2.execute(def, input)
        }

        if (!rawOutcome.isSuccess) return rawOutcome

        // Check if active project has incomplete fields relevant to this calculation
        val project = input.project
        if (project != null && !rawOutcome.isPreliminary) {
            val missingFa = project.missingCriticalFields(AppLanguage.FA)
            val missingEn = project.missingCriticalFields(AppLanguage.EN)
            if (missingFa.isNotEmpty() && toolId in setOf(
                    ToolId.LAND_AREA, ToolId.BUILT_UP_AREA, ToolId.BUILDING_VOLUME,
                    ToolId.SLAB_CONCRETE, ToolId.WALL_NET_AREA, ToolId.FINAL_PROJECT_BOQ
                )
            ) {
                return rawOutcome.copy(
                    isPreliminary = true,
                    preliminaryReasonFa = "برآورد اولیه: فیلدهای پروژه ناقص است (${missingFa.joinToString("، ")})",
                    preliminaryReasonEn = "Preliminary Estimate: incomplete project specs (${missingEn.joinToString(", ")})"
                )
            }
        }
        return rawOutcome
    }

    /**
     * Generates default field values and units for a tool, auto-filling from the active ProjectEntity where available.
     */
    fun buildInitialInputs(toolId: ToolId, project: ProjectEntity?, defaultWaste: Double): Pair<Map<String, Double>, Map<String, EngineeringUnit>> {
        val def = ToolCatalog.get(toolId)
        val values = linkedMapOf<String, Double>()
        val units = linkedMapOf<String, EngineeringUnit>()

        def.fields.forEach { f ->
            values[f.key] = if (f.key == "waste") defaultWaste else f.defaultValue
            units[f.key] = f.defaultUnit
        }

        if (project != null) {
            when (toolId) {
                ToolId.LAND_AREA, ToolId.EXCAVATION_VOLUME -> {
                    if (project.landLengthM > 0) { values["length"] = project.landLengthM; units["length"] = EngineeringUnit.M }
                    if (project.landWidthM > 0) { values["width"] = project.landWidthM; units["width"] = EngineeringUnit.M }
                }
                ToolId.BUILT_UP_AREA -> {
                    if (project.floorsCount > 0) values["floors"] = project.floorsCount.toDouble()
                    if (project.floorBuiltUpAreaM2 > 0) values["floorArea"] = project.floorBuiltUpAreaM2
                }
                ToolId.BUILDING_VOLUME -> {
                    if (project.landLengthM > 0) { values["length"] = project.landLengthM; units["length"] = EngineeringUnit.M }
                    if (project.landWidthM > 0) { values["width"] = project.landWidthM; units["width"] = EngineeringUnit.M }
                    if (project.floorsCount > 0 && project.floorHeightM > 0) {
                        values["height"] = project.floorsCount * project.floorHeightM
                        units["height"] = EngineeringUnit.M
                    }
                }
                ToolId.COLUMN_CONCRETE -> {
                    if (project.floorHeightM > 0) { values["height"] = project.floorHeightM; units["height"] = EngineeringUnit.M }
                }
                ToolId.SLAB_CONCRETE -> {
                    if (project.floorBuiltUpAreaM2 > 0) values["area"] = project.floorBuiltUpAreaM2
                    if (project.floorsCount > 0) values["floors"] = project.floorsCount.toDouble()
                    values["thickness"] = project.slabType.defaultConcreteThicknessM * 100.0
                    units["thickness"] = EngineeringUnit.CM
                }
                ToolId.WALL_NET_AREA, ToolId.CEMENT_BLOCK_COUNT -> {
                    if (project.floorHeightM > 0) { values["wallHeight"] = project.floorHeightM; units["wallHeight"] = EngineeringUnit.M }
                }
                ToolId.MASONRY_MORTAR_VOLUME -> {
                    if (project.wallThicknessCm > 0) { values["wallThickness"] = project.wallThicknessCm; units["wallThickness"] = EngineeringUnit.CM }
                }
                ToolId.SANITARY_FIXTURES -> {
                    if (project.bathroomsCount > 0) {
                        values["toilets"] = project.bathroomsCount.toDouble()
                        values["vanities"] = project.bathroomsCount.toDouble()
                        values["showers"] = project.bathroomsCount.toDouble()
                    }
                }
                else -> {}
            }
        }
        return values to units
    }
}
