package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.ui.theme.AppFontChoice

enum class EngineeringUnit(
    val symbolFa: String,
    val symbolEn: String,
    val dimension: UnitDimension,
    val toBaseFactor: Double
) {
    M("متر", "m", UnitDimension.LENGTH, 1.0),
    CM("سانتی‌متر", "cm", UnitDimension.LENGTH, 0.01),
    MM("میلی‌متر", "mm", UnitDimension.LENGTH, 0.001),
    M2("مترمربع", "m²", UnitDimension.AREA, 1.0),
    M3("مترمکعب", "m³", UnitDimension.VOLUME, 1.0),
    KG("کیلوگرم", "kg", UnitDimension.MASS, 1.0),
    TON("تن", "ton", UnitDimension.MASS, 1000.0),
    LITER("لیتر", "L", UnitDimension.LIQUID, 1.0),
    PCS("عدد", "pcs", UnitDimension.COUNT, 1.0),
    BAG("کیسه", "bag", UnitDimension.COUNT, 1.0),
    LM("متر طول", "lm", UnitDimension.LENGTH, 1.0);

    fun symbol(lang: AppLanguage): String = if (lang == AppLanguage.FA) symbolFa else symbolEn
}

enum class UnitDimension {
    LENGTH, AREA, VOLUME, MASS, LIQUID, COUNT
}

enum class BuildingType(val titleFa: String, val titleEn: String) {
    RESIDENTIAL("مسکونی", "Residential"),
    COMMERCIAL("تجاری", "Commercial"),
    OFFICE("اداری", "Office"),
    VILLA("ویلایی", "Villa"),
    INDUSTRIAL("صنعتی", "Industrial"),
    WAREHOUSE("انبار", "Warehouse"),
    MULTI_STORY("ساختمان چندطبقه", "Multi-Story");

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

enum class FrameType(val titleFa: String, val titleEn: String) {
    CONCRETE("بتنی", "Reinforced Concrete"),
    STEEL("فلزی", "Structural Steel"),
    MASONRY("بنایی", "Masonry"),
    COMPOSITE("ترکیبی", "Composite");

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

enum class SlabType(val titleFa: String, val titleEn: String, val defaultConcreteThicknessM: Double) {
    JOIST_BLOCK("تیرچه بلوک", "Joist & Block", 0.11),
    SOLID_SLAB("دال بتنی یکپارچه", "Solid Concrete Slab", 0.16),
    STEEL_DECK("عرشه فولادی", "Composite Steel Deck", 0.11),
    WAFFLE("وافل", "Waffle Slab", 0.18),
    PITCHED_ROOF("سقف شیروانی", "Pitched Roof", 0.06);

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

enum class WallType(val titleFa: String, val titleEn: String) {
    BRICK("آجر فشاری / سفال", "Clay Brick"),
    CEMENT_BLOCK("بلوک سیمانی", "Cement Block"),
    HEBELX("بلوک هبلکس (AAC)", "AAC / Hebelx Block"),
    CLAY_HOLLOW("سفال تیغه‌ای", "Hollow Clay Block");

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

enum class FoundationType(val titleFa: String, val titleEn: String) {
    STRIP("نواری (Strip)", "Strip Foundation"),
    ISOLATED("منفرد (Isolated)", "Isolated Footing"),
    RAFT("گسترده / رادیه (Mat/Raft)", "Mat / Raft Foundation"),
    PILE_CAP("شمع و سرشمع", "Pile & Cap");

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

enum class ConcreteMixGrade(
    val titleFa: String,
    val titleEn: String,
    val cementPart: Double,
    val sandPart: Double,
    val gravelPart: Double,
    val cementKgPerM3: Double,
    val standardRef: String
) {
    M15_1_2_4("بتن مگـر / C12-15 (۱:۲:۴)", "M15 Lean/Low (1:2:4)", 1.0, 2.0, 4.0, 300.0, "ACI 211.1 / مبحث ۹"),
    M20_1_15_3("بتن معمولی C20 (۱:۱.۵:۳)", "M20 Standard (1:1.5:3)", 1.0, 1.5, 3.0, 350.0, "ACI 211.1 / مبحث ۹"),
    M25_1_1_2("بتن سازه‌ای C25 (۱:۱:۲)", "M25 Structural (1:1:2)", 1.0, 1.0, 2.0, 400.0, "ACI 211.1 / مبحث ۹"),
    C30_HIGH("بتن پرمقاومت C30 (عیار ۴۲۵)", "C30 High Strength (425 kg/m³)", 1.0, 1.1, 1.9, 425.0, "ACI 318 / مبحث ۹"),
    C35_SPECIAL("بتن ویژه C35 (عیار ۴۵۰)", "C35 Special (450 kg/m³)", 1.0, 1.0, 1.8, 450.0, "ACI 318 / مبحث ۹");

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

enum class TileLayoutPattern(
    val titleFa: String,
    val titleEn: String,
    val recommendedWastePercent: Double
) {
    STRAIGHT("چیدمان مستقیم (ساده)", "Straight / Grid", 7.0),
    RUNNING_BOND("چیدمان آجری / آفست", "Running Bond / Brick", 10.0),
    DIAGONAL("چیدمان لوزی / مورب", "Diagonal (45°)", 15.0),
    HERRINGBONE("چیدمان جناغی", "Herringbone", 17.0);

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)
}

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val location: String = "",
    val buildingType: BuildingType = BuildingType.RESIDENTIAL,
    val floorsCount: Int = 0,
    val unitsCount: Int = 0,
    val landLengthM: Double = 0.0,
    val landWidthM: Double = 0.0,
    val landAreaM2: Double = 0.0,
    val floorBuiltUpAreaM2: Double = 0.0,
    val floorHeightM: Double = 0.0,
    val frameType: FrameType = FrameType.CONCRETE,
    val slabType: SlabType = SlabType.JOIST_BLOCK,
    val wallType: WallType = WallType.BRICK,
    val foundationType: FoundationType = FoundationType.STRIP,
    val wallThicknessCm: Double = 0.0,
    val roomsCount: Int = 0,
    val bathroomsCount: Int = 0,
    val kitchensCount: Int = 0,
    val materialGradeNote: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun missingCriticalFields(lang: AppLanguage): List<String> {
        val missing = mutableListOf<String>()
        if (floorsCount <= 0) missing += bi(lang, "تعداد طبقات", "Floors count")
        if (landAreaM2 <= 0 && (landLengthM <= 0 || landWidthM <= 0)) {
            missing += bi(lang, "ابعاد یا مساحت زمین", "Land dimensions/area")
        }
        if (floorBuiltUpAreaM2 <= 0) missing += bi(lang, "زیربنای هر طبقه", "Floor built-up area")
        if (floorHeightM <= 0) missing += bi(lang, "ارتفاع طبقات", "Floor height")
        if (wallThicknessCm <= 0) missing += bi(lang, "ضخامت دیوارها", "Wall thickness")
        return missing
    }

    val effectiveLandAreaM2: Double
        get() = if (landAreaM2 > 0) landAreaM2 else (landLengthM * landWidthM)

    val effectiveTotalBuiltUpAreaM2: Double
        get() = if (floorsCount > 0 && floorBuiltUpAreaM2 > 0) floorsCount * floorBuiltUpAreaM2 else 0.0
}

@Entity(tableName = "calculation_records")
data class CalculationRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val projectNameSnapshot: String = "",
    val toolId: String,
    val toolTitleFa: String,
    val toolTitleEn: String,
    val primaryValue: Double,
    val primaryUnit: EngineeringUnit,
    val summaryFa: String,
    val summaryEn: String,
    val formulaUsed: String,
    val isPreliminary: Boolean,
    val estimatedCost: Double = 0.0,
    val payloadJson: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "material_prices")
data class MaterialPriceEntity(
    @PrimaryKey val materialKey: String,
    val nameFa: String,
    val nameEn: String,
    val categoryFa: String,
    val categoryEn: String,
    val unit: EngineeringUnit,
    val unitPrice: Double,
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun name(lang: AppLanguage): String = bi(lang, nameFa, nameEn)
    fun category(lang: AppLanguage): String = bi(lang, categoryFa, categoryEn)
}

data class UserSettings(
    val language: AppLanguage = AppLanguage.FA,
    val darkTheme: Boolean = true,
    val fontChoice: AppFontChoice = AppFontChoice.VAZIRMATN,
    val fontScale: Float = 1.0f,
    val animationsEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val soundVolume: Float = 0.6f,
    val defaultLengthUnit: EngineeringUnit = EngineeringUnit.M,
    val defaultWastePercent: Double = 5.0,
    val currencySymbolFa: String = "تومان",
    val currencySymbolEn: String = "Toman"
) {
    fun currency(lang: AppLanguage): String = if (lang == AppLanguage.FA) currencySymbolFa else currencySymbolEn
}
