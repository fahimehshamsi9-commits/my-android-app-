package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.ToolCatalog
import com.example.engine.ToolId
import com.example.engine.UnitConverter.formatNumber
import com.example.model.AppLanguage
import com.example.model.ProjectEntity
import com.example.model.UserSettings
import com.example.model.bi
import com.example.ui.DashboardSummary
import com.example.ui.SidebarSection
import com.example.ui.components.CostBreakdownDonutChart
import com.example.ui.components.EngineeringCard
import com.example.ui.components.KpiMetricCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PreliminaryAmber
import com.example.ui.theme.VerifiedGreen

@Composable
fun DashboardScreen(
    summary: DashboardSummary,
    activeProject: ProjectEntity?,
    settings: UserSettings,
    onNavigateSection: (SidebarSection) -> Unit,
    onOpenTool: (ToolId) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = settings.language
    val currency = settings.currency(lang)
    val popularTools = listOf(
        ToolId.REBAR_WEIGHT,
        ToolId.CONCRETE_MIX_MATERIALS,
        ToolId.FLOOR_CERAMIC,
        ToolId.BRICK_COUNT,
        ToolId.FOUNDATION_CONCRETE,
        ToolId.FINAL_PROJECT_BOQ
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header Banner
        item {
            EngineeringCard(accentColor = EngineeringOrange) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "BUILD MASTER • ${bi(lang, "مستر ساختمان", "Engineering Suite")}",
                            style = MaterialTheme.typography.titleLarge,
                            color = EngineeringOrange
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = bi(
                                lang,
                                "از نقشه تا برآورد، همه چیز در یک ابزار مهندسی!",
                                "From Blueprint to Estimate, Everything in One Engineering Tool!"
                            ),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Construction,
                        contentDescription = null,
                        tint = ElectricBlue,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onNavigateSection(SidebarSection.PROJECTS) },
                        colors = ButtonDefaults.buttonColors(containerColor = EngineeringOrange),
                        modifier = Modifier.testTag("dashboard_new_project_btn")
                    ) {
                        Icon(Icons.Default.Apartment, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "مدیریت پروژه‌ها", "Projects"))
                    }
                    OutlinedButton(
                        onClick = { onNavigateSection(SidebarSection.BOQ_ESTIMATION) },
                        modifier = Modifier.testTag("dashboard_all_tools_btn")
                    ) {
                        Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "۴۰ ابزار مهندسی", "40 Tools"))
                    }
                }
            }
        }

        // KPI Grid (Adaptive 2 columns on phones, 4 on tablets)
        item {
            BoxWithConstraints {
                val twoCol = maxWidth < 680.dp
                if (twoCol) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                            KpiMetricCard(
                                title = bi(lang, "تعداد پروژه‌ها", "Projects"),
                                value = "${summary.projectsCount}",
                                subtitle = activeProject?.name ?: bi(lang, "بدون پروژه فعال", "No active project"),
                                icon = Icons.Default.FolderOpen,
                                accent = ElectricBlue,
                                modifier = Modifier.weight(1f)
                            )
                            KpiMetricCard(
                                title = bi(lang, "مجموع زیربنا", "Total Built-up"),
                                value = "${formatNumber(summary.totalBuiltUpAreaM2, 0)} m²",
                                subtitle = bi(lang, "تمامی پروژه‌ها", "Across all projects"),
                                icon = Icons.Default.Layers,
                                accent = VerifiedGreen,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                            KpiMetricCard(
                                title = bi(lang, "برآورد هزینه کل", "Est. Total Cost"),
                                value = formatNumber(summary.totalEstimatedCost, 0),
                                subtitle = currency,
                                icon = Icons.Default.MonetizationOn,
                                accent = EngineeringOrange,
                                modifier = Modifier.weight(1f)
                            )
                            KpiMetricCard(
                                title = bi(lang, "محاسبات ثبت‌شده", "Calculations"),
                                value = "${summary.recentCalculations.size}",
                                subtitle = bi(lang, "۴۰ ابزار آفلاین", "40 Offline Tools"),
                                icon = Icons.Default.Straighten,
                                accent = PreliminaryAmber,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        KpiMetricCard(
                            title = bi(lang, "تعداد پروژه‌ها", "Projects"),
                            value = "${summary.projectsCount}",
                            subtitle = activeProject?.name ?: bi(lang, "بدون پروژه", "No project"),
                            icon = Icons.Default.FolderOpen,
                            accent = ElectricBlue,
                            modifier = Modifier.weight(1f)
                        )
                        KpiMetricCard(
                            title = bi(lang, "مجموع زیربنا", "Total Built-up"),
                            value = "${formatNumber(summary.totalBuiltUpAreaM2, 0)} m²",
                            subtitle = bi(lang, "تمامی پروژه‌ها", "All projects"),
                            icon = Icons.Default.Layers,
                            accent = VerifiedGreen,
                            modifier = Modifier.weight(1f)
                        )
                        KpiMetricCard(
                            title = bi(lang, "برآورد هزینه", "Est. Cost"),
                            value = formatNumber(summary.totalEstimatedCost, 0),
                            subtitle = currency,
                            icon = Icons.Default.MonetizationOn,
                            accent = EngineeringOrange,
                            modifier = Modifier.weight(1f)
                        )
                        KpiMetricCard(
                            title = bi(lang, "محاسبات اخیر", "Calculations"),
                            value = "${summary.recentCalculations.size}",
                            subtitle = bi(lang, "آماده گزارش", "Ready to export"),
                            icon = Icons.Default.Straighten,
                            accent = PreliminaryAmber,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Latest / Active Project Card
        item {
            EngineeringCard(accentColor = ElectricBlue) {
                Text(
                    text = bi(lang, "آخرین پروژه / پروژه فعال", "Latest / Active Project"),
                    style = MaterialTheme.typography.titleMedium,
                    color = ElectricBlue
                )
                Spacer(Modifier.height(8.dp))
                if (activeProject == null) {
                    Text(
                        text = bi(
                            lang,
                            "هنوز پروژه‌ای تعریف نشده است. برای محاسبه دقیق و خودکار مصالح، اولین پروژه خود را بسازید.",
                            "No project created yet. Create your first project to auto-fill engineering calculations."
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { onNavigateSection(SidebarSection.PROJECTS) }) {
                        Text(bi(lang, "تعریف پروژه جدید", "Create New Project"))
                    }
                } else {
                    val missing = activeProject.missingCriticalFields(lang)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(activeProject.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(
                                "${activeProject.buildingType.title(lang)} • ${activeProject.frameType.title(lang)} • ${activeProject.location.ifBlank { "-" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusBadge(isPreliminary = missing.isNotEmpty(), lang = lang)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "${bi(lang, "طبقات:", "Floors:")} ${activeProject.floorsCount} | ${bi(lang, "زیربنای کل:", "Total Area:")} ${formatNumber(activeProject.effectiveTotalBuiltUpAreaM2)} m²",
                        style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFontFamily)
                    )
                }
            }
        }

        // Popular Tools Horizontal Carousel
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = bi(lang, "ابزارهای پرکاربرد", "Popular Engineering Tools"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(popularTools) { toolId ->
                        val def = ToolCatalog.get(toolId)
                        EngineeringCard(
                            onClick = { onOpenTool(toolId) },
                            accentColor = EngineeringOrange,
                            modifier = Modifier.fillParentMaxWidth(0.72f)
                        ) {
                            Text(
                                text = def.title(lang),
                                style = MaterialTheme.typography.titleSmall,
                                color = EngineeringOrange,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = def.subtitle(lang),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = def.formula(lang),
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = ElectricBlue,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Required Materials & Cost Chart
        item {
            EngineeringCard(accentColor = VerifiedGreen) {
                Text(
                    text = bi(lang, "مصالح موردنیاز و ترکیب هزینه", "Required Materials & Cost Breakdown"),
                    style = MaterialTheme.typography.titleMedium,
                    color = VerifiedGreen
                )
                Spacer(Modifier.height(10.dp))
                val palette = listOf(EngineeringOrange, ElectricBlue, VerifiedGreen, PreliminaryAmber, Color(0xFFA855F7))
                val costSlices = summary.aggregatedMaterials
                    .filter { it.totalCost > 0 }
                    .sortedByDescending { it.totalCost }
                    .take(5)
                    .mapIndexed { idx, mat -> Triple(mat.name(lang), mat.totalCost, palette[idx % palette.size]) }

                CostBreakdownDonutChart(
                    slices = costSlices,
                    centerLabel = bi(lang, "مصالح", "Materials")
                )

                if (summary.aggregatedMaterials.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    summary.aggregatedMaterials.take(5).forEach { m ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(m.name(lang), style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "${formatNumber(m.orderQuantity)} ${m.unit.symbol(lang)}",
                                style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = ElectricBlue
                            )
                        }
                    }
                } else {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = bi(lang, "با ذخیره محاسبات، جمع مصالح و نمودار هزینه اینجا نمایش داده می‌شود.", "Save calculations to populate the live materials chart."),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Recent Calculations
        item {
            EngineeringCard(accentColor = MaterialTheme.colorScheme.outline) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = bi(lang, "آخرین محاسبات ثبت‌شده", "Recent Calculations"),
                        style = MaterialTheme.typography.titleMedium
                    )
                    OutlinedButton(onClick = { onNavigateSection(SidebarSection.REPORTS) }) {
                        Text(bi(lang, "گزارش کامل", "Full Report"))
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (summary.recentCalculations.isEmpty()) {
                    Text(
                        text = bi(lang, "هنوز محاسبه‌ای ذخیره نشده است.", "No saved calculations yet."),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    summary.recentCalculations.forEachIndexed { idx, rec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(bi(lang, rec.toolTitleFa, rec.toolTitleEn), style = MaterialTheme.typography.labelLarge)
                                Text(bi(lang, rec.summaryFa, rec.summaryEn), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (rec.estimatedCost > 0) {
                                Text(
                                    "${formatNumber(rec.estimatedCost, 0)} $currency",
                                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                                    color = EngineeringOrange
                                )
                            }
                        }
                        if (idx < summary.recentCalculations.lastIndex) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        }
                    }
                }
            }
        }
    }
}
