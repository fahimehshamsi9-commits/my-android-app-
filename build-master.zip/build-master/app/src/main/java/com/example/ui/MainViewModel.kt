package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundCue
import com.example.audio.SoundManager
import com.example.data.AppDatabase
import com.example.data.BuildMasterRepository
import com.example.data.SettingsDataStore
import com.example.engine.CalcHelper
import com.example.engine.CalculationEngine
import com.example.engine.CalculationInput
import com.example.engine.CalculationOutcome
import com.example.engine.ToolCatalog
import com.example.engine.ToolGroup
import com.example.engine.ToolId
import com.example.engine.UnitConverter.formatNumber
import com.example.model.AppLanguage
import com.example.model.CalculationRecordEntity
import com.example.engine.MaterialEstimate
import com.example.model.MaterialPriceEntity
import com.example.model.ProjectEntity
import com.example.model.UserSettings
import com.example.model.bi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SidebarSection(val route: String, val titleFa: String, val titleEn: String) {
    DASHBOARD("dashboard", "۱. داشبورد", "1. Dashboard"),
    PROJECTS("projects", "۲. پروژه‌های من", "2. My Projects"),
    BOQ_ESTIMATION("boq_estimation", "۳. متره و برآورد (۴۰ ابزار)", "3. BOQ & 40 Tools"),
    CONCRETE("concrete", "۴. محاسبات بتن", "4. Concrete"),
    REBAR("rebar", "۵. محاسبات میلگرد", "5. Rebar & Steel"),
    MASONRY("masonry", "۶. محاسبات دیوارچینی", "6. Masonry"),
    SLAB_ROOF("slab_roof", "۷. محاسبات سقف", "7. Slab & Roof"),
    TILES_CERAMIC("tiles_ceramic", "۸. محاسبات کاشی و سرامیک", "8. Tile & Ceramic"),
    MEP("mep", "۹. محاسبات تأسیسات", "9. MEP & Fixtures"),
    COST_PRICING("cost_pricing", "۱۰. محاسبات هزینه و قیمت‌ها", "10. Cost & Prices"),
    EARTHWORK("earthwork", "۱۱. محاسبات خاکبرداری", "11. Earthwork"),
    PAINT_PLASTER("paint_plaster", "۱۲. محاسبات رنگ و گچ", "12. Paint & Plaster"),
    SCIENTIFIC_CALC("scientific_calc", "۱۳. ماشین‌حساب مهندسی", "13. Engineering Calc"),
    REPORTS("reports", "۱۴. گزارش‌ها (PDF / Excel)", "14. Reports"),
    SETTINGS("settings", "۱۵. تنظیمات", "15. Settings");

    fun title(lang: AppLanguage): String = bi(lang, titleFa, titleEn)

    fun filteredTools(): List<ToolId> = when (this) {
        BOQ_ESTIMATION -> ToolCatalog.allTools.map { it.id }
        CONCRETE -> ToolCatalog.byGroup(ToolGroup.CONCRETE).map { it.id } + ToolId.TOTAL_CONCRETE_VOLUME
        REBAR -> ToolCatalog.byGroup(ToolGroup.STEEL).map { it.id }
        MASONRY -> ToolCatalog.byGroup(ToolGroup.MASONRY).map { it.id }
        SLAB_ROOF -> listOf(ToolId.SLAB_CONCRETE, ToolId.BUILT_UP_AREA, ToolId.BUILDING_VOLUME, ToolId.WHITE_PLASTER)
        TILES_CERAMIC -> listOf(ToolId.FLOOR_CERAMIC, ToolId.WALL_TILE, ToolId.FACADE_STONE, ToolId.FLOOR_STONE, ToolId.SKIRTING_BASEBOARD)
        MEP -> ToolCatalog.byGroup(ToolGroup.MEP).map { it.id }
        COST_PRICING -> listOf(ToolId.MATERIAL_COST, ToolId.FINAL_PROJECT_BOQ)
        EARTHWORK -> listOf(ToolId.EXCAVATION_VOLUME, ToolId.BACKFILL_VOLUME, ToolId.LAND_AREA, ToolId.FOUNDATION_CONCRETE)
        PAINT_PLASTER -> listOf(ToolId.GYPSUM_SOIL_PLASTER, ToolId.WHITE_PLASTER, ToolId.BUILDING_PAINT)
        else -> emptyList()
    }
}

data class DashboardSummary(
    val projectsCount: Int = 0,
    val latestProject: ProjectEntity? = null,
    val totalBuiltUpAreaM2: Double = 0.0,
    val totalEstimatedCost: Double = 0.0,
    val aggregatedMaterials: List<MaterialEstimate> = emptyList(),
    val recentCalculations: List<CalculationRecordEntity> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val settingsStore = SettingsDataStore(application)
    val repository = BuildMasterRepository(db, settingsStore)
    val soundManager = SoundManager()

    val settings: StateFlow<UserSettings> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val projects: StateFlow<List<ProjectEntity>> = repository.projects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val calculations: StateFlow<List<CalculationRecordEntity>> = repository.calculations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val materialPrices: StateFlow<List<MaterialPriceEntity>> = repository.materialPrices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProject: StateFlow<ProjectEntity?> = combine(
        repository.projects,
        repository.activeProjectId
    ) { list, activeId ->
        list.firstOrNull { it.id == activeId } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val dashboardSummary: StateFlow<DashboardSummary> = combine(
        projects,
        calculations,
        materialPrices
    ) { projList, calcList, priceList ->
        val priceMap = priceList.associateBy { it.materialKey }
        val totalBuiltUp = projList.sumOf { it.effectiveTotalBuiltUpAreaM2 }
        val matsMap = linkedMapOf<String, MaterialEstimate>()
        calcList.forEach { rec ->
            CalcHelper.parseMaterialsFromJson(rec.payloadJson).forEach { m ->
                val prev = matsMap[m.materialKey]
                val unitPrice = priceMap[m.materialKey]?.unitPrice ?: m.unitPrice
                val newOrder = (prev?.orderQuantity ?: 0.0) + m.orderQuantity
                val newNet = (prev?.netQuantity ?: 0.0) + m.netQuantity
                val newPkg = (prev?.packageCount ?: 0.0) + m.packageCount
                matsMap[m.materialKey] = m.copy(
                    netQuantity = newNet,
                    orderQuantity = newOrder,
                    packageCount = newPkg,
                    unitPrice = unitPrice,
                    totalCost = (prev?.totalCost ?: 0.0) + m.totalCost
                )
            }
        }
        val mats = matsMap.values.toList()
        DashboardSummary(
            projectsCount = projList.size,
            latestProject = projList.firstOrNull(),
            totalBuiltUpAreaM2 = totalBuiltUp,
            totalEstimatedCost = calcList.sumOf { it.estimatedCost },
            aggregatedMaterials = mats,
            recentCalculations = calcList.take(8)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    init {
        viewModelScope.launch {
            repository.ensureDefaultPricesSeeded()
        }
        viewModelScope.launch {
            settings.collect { s ->
                soundManager.enabled = s.soundEnabled
                soundManager.volume = s.soundVolume
            }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun postStatus(msg: String) {
        _statusMessage.value = msg
    }

    fun playCue(cue: SoundCue) {
        soundManager.play(cue)
    }

    fun toggleSoundMute() {
        viewModelScope.launch {
            repository.updateSettings { it.copy(soundEnabled = !it.soundEnabled) }
        }
    }

    fun toggleLanguage() {
        soundManager.play(SoundCue.CLICK)
        viewModelScope.launch {
            repository.updateSettings {
                val nextLang = if (it.language == AppLanguage.FA) AppLanguage.EN else AppLanguage.FA
                it.copy(language = nextLang)
            }
        }
    }

    fun updateSettings(transform: (UserSettings) -> UserSettings) {
        viewModelScope.launch { repository.updateSettings(transform) }
    }

    fun saveProject(project: ProjectEntity, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.saveProject(project)
            soundManager.play(SoundCue.SAVE_PROJECT)
            onSaved(id)
        }
    }

    fun deleteProject(projectId: Long) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            soundManager.play(SoundCue.CLICK)
        }
    }

    fun selectActiveProject(projectId: Long) {
        viewModelScope.launch {
            repository.setActiveProject(projectId)
            soundManager.play(SoundCue.CLICK)
        }
    }

    fun runAndEvaluate(toolId: ToolId, input: CalculationInput): CalculationOutcome {
        val priceMap = materialPrices.value.associateBy { it.materialKey }
        val proj = activeProject.value
        val projRecords = if (proj != null) {
            calculations.value.filter { it.projectId == proj.id }
        } else {
            calculations.value
        }
        val enriched = input.copy(
            project = proj,
            savedProjectRecords = projRecords,
            priceCatalog = priceMap
        )
        return CalculationEngine.calculate(toolId, enriched)
    }

    fun saveCalculationOutcome(outcome: CalculationOutcome) {
        if (!outcome.isSuccess) return
        viewModelScope.launch {
            val def = ToolCatalog.get(outcome.toolId)
            val proj = activeProject.value
            val summaryFa = "${outcome.primaryLabelFa}: ${formatNumber(outcome.primaryValue, 2)} ${outcome.primaryUnit.symbolFa}"
            val summaryEn = "${outcome.primaryLabelEn}: ${formatNumber(outcome.primaryValue, 2)} ${outcome.primaryUnit.symbolEn}"
            val record = CalculationRecordEntity(
                projectId = proj?.id,
                projectNameSnapshot = proj?.name ?: "General",
                toolId = outcome.toolId.name,
                toolTitleFa = def.titleFa,
                toolTitleEn = def.titleEn,
                primaryValue = outcome.primaryValue,
                primaryUnit = outcome.primaryUnit,
                summaryFa = summaryFa,
                summaryEn = summaryEn,
                formulaUsed = outcome.formulaUsed,
                isPreliminary = outcome.isPreliminary,
                estimatedCost = outcome.totalEstimatedCost,
                payloadJson = CalcHelper.outcomeToJson(outcome)
            )
            repository.saveCalculation(record)
            soundManager.play(SoundCue.SAVE_PROJECT)
            val lang = settings.value.language
            _statusMessage.value = bi(lang, "محاسبه در تاریخچه پروژه ذخیره شد.", "Calculation saved to project history.")
        }
    }

    fun deleteCalculation(id: Long) {
        viewModelScope.launch {
            repository.deleteCalculation(id)
            soundManager.play(SoundCue.CLICK)
        }
    }

    fun upsertPrice(price: MaterialPriceEntity) {
        viewModelScope.launch {
            repository.upsertPrice(price)
            soundManager.play(SoundCue.SAVE_PROJECT)
        }
    }

    fun resetDefaultPrices() {
        viewModelScope.launch {
            repository.resetDefaultPrices()
            soundManager.play(SoundCue.CLICK)
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllUserData()
            soundManager.play(SoundCue.CLICK)
        }
    }
}
