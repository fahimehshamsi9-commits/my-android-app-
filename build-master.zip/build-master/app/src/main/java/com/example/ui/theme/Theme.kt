package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val EngineeringDarkColorScheme = darkColorScheme(
    primary = EngineeringOrange,
    onPrimary = Color.White,
    primaryContainer = EngineeringOrangeDark,
    onPrimaryContainer = Color.White,
    secondary = ElectricBlue,
    onSecondary = DeepNavy,
    secondaryContainer = Color(0xFF1A365D),
    onSecondaryContainer = ElectricBlue,
    tertiary = VerifiedGreen,
    onTertiary = DeepNavy,
    tertiaryContainer = Color(0xFF064E3B),
    onTertiaryContainer = Color(0xFFA7F3D0),
    background = DeepNavy,
    onBackground = Color(0xFFF1F5F9),
    surface = NavySurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = NavyCard,
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = GraphiteBorder,
    outlineVariant = GraphiteSlate,
    error = AlertRed,
    onError = Color.White
)

private val EngineeringLightColorScheme = lightColorScheme(
    primary = EngineeringOrangeDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFEDD5),
    onPrimaryContainer = Color(0xFF7C2D12),
    secondary = ElectricBlueDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0C4A6E),
    tertiary = Color(0xFF059669),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD1FAE5),
    onTertiaryContainer = Color(0xFF064E3B),
    background = DraftingPaper,
    onBackground = InkNavy,
    surface = CrispWhite,
    onSurface = InkNavy,
    surfaceVariant = BlueprintSurfaceVariant,
    onSurfaceVariant = MutedSlate,
    outline = LightBorder,
    outlineVariant = Color(0xFFE2E8F0),
    error = Color(0xFFDC2626),
    onError = Color.White
)

private val EngineeringShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun BuildMasterTheme(
    darkTheme: Boolean = true,
    fontChoice: AppFontChoice = AppFontChoice.VAZIRMATN,
    fontScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) EngineeringDarkColorScheme else EngineeringLightColorScheme
    val typography = buildAppTypography(fontChoice, fontScale)
    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = EngineeringShapes,
        content = content
    )
}
