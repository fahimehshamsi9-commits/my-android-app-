package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.bi
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.VerifiedGreen
import kotlinx.coroutines.delay

/**
 * Animated Engineering Splash Screen:
 * 1. Blueprint grid lines appear
 * 2. 3D isometric building slowly forms
 * 3. Dimension lines appear around building
 * 4. BUILD MASTER title appears
 * 5. Creator credit: قاسم غلامرضاپور appears at bottom
 */
@Composable
fun SplashScreen(
    lang: AppLanguage,
    animationsEnabled: Boolean,
    onFinished: () -> Unit
) {
    val gridProgress = remember { Animatable(if (animationsEnabled) 0f else 1f) }
    val buildingProgress = remember { Animatable(if (animationsEnabled) 0f else 1f) }
    val dimProgress = remember { Animatable(if (animationsEnabled) 0f else 1f) }
    var showTitle by remember { mutableStateOf(!animationsEnabled) }
    var showCreator by remember { mutableStateOf(!animationsEnabled) }

    LaunchedEffect(animationsEnabled) {
        if (animationsEnabled) {
            gridProgress.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
            buildingProgress.animateTo(1f, tween(950, easing = FastOutSlowInEasing))
            dimProgress.animateTo(1f, tween(550, easing = FastOutSlowInEasing))
            showTitle = true
            delay(400)
            showCreator = true
            delay(1100)
        } else {
            delay(700)
        }
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF13244D), DeepNavy, Color(0xFF050A18))
                )
            )
            .clickable { onFinished() }
            .navigationBarsPadding()
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Centered 3D Isometric Building + Blueprint Grid + Dimension Lines Canvas
            Canvas(modifier = Modifier.size(230.dp)) {
                val w = size.width
                val h = size.height
                val cx = w / 2f
                val cy = h / 2f + 12f
                val gp = gridProgress.value
                val bp = buildingProgress.value
                val dp = dimProgress.value

                // Stage 1: Blueprint Grid Lines
                val gridColor = ElectricBlue.copy(alpha = 0.22f * gp)
                val step = w / 8f
                for (i in 1..7) {
                    val pos = i * step
                    drawLine(gridColor, Offset(pos, 0f), Offset(pos, h * gp), strokeWidth = 1f)
                    drawLine(gridColor, Offset(0f, pos), Offset(w * gp, pos), strokeWidth = 1f)
                }

                // Stage 2: 3D Isometric Building Frame rising floor by floor
                if (bp > 0f) {
                    val isoW = w * 0.28f
                    val isoH = h * 0.14f
                    val maxTowerH = h * 0.42f * bp
                    val baseCenter = Offset(cx, cy + h * 0.18f)
                    val topCenter = Offset(cx, baseCenter.y - maxTowerH)

                    val leftBottom = Offset(baseCenter.x - isoW, baseCenter.y - isoH)
                    val rightBottom = Offset(baseCenter.x + isoW, baseCenter.y - isoH)
                    val backBottom = Offset(baseCenter.x, baseCenter.y - 2f * isoH)

                    val leftTop = Offset(topCenter.x - isoW, topCenter.y - isoH)
                    val rightTop = Offset(topCenter.x + isoW, topCenter.y - isoH)
                    val backTop = Offset(topCenter.x, topCenter.y - 2f * isoH)

                    // Left face fill
                    val leftFace = Path().apply {
                        moveTo(baseCenter.x, baseCenter.y)
                        lineTo(leftBottom.x, leftBottom.y)
                        lineTo(leftTop.x, leftTop.y)
                        lineTo(topCenter.x, topCenter.y)
                        close()
                    }
                    drawPath(leftFace, Color(0xFF1E3A5F).copy(alpha = 0.78f * bp))

                    // Right face fill
                    val rightFace = Path().apply {
                        moveTo(baseCenter.x, baseCenter.y)
                        lineTo(rightBottom.x, rightBottom.y)
                        lineTo(rightTop.x, rightTop.y)
                        lineTo(topCenter.x, topCenter.y)
                        close()
                    }
                    drawPath(rightFace, Color(0xFF0F2544).copy(alpha = 0.9f * bp))

                    // Roof face fill
                    val roofFace = Path().apply {
                        moveTo(topCenter.x, topCenter.y)
                        lineTo(leftTop.x, leftTop.y)
                        lineTo(backTop.x, backTop.y)
                        lineTo(rightTop.x, rightTop.y)
                        close()
                    }
                    drawPath(roofFace, ElectricBlue.copy(alpha = 0.25f * bp))

                    // Structural wireframe edges
                    val edgeStroke = Stroke(width = 3f, cap = StrokeCap.Round)
                    drawPath(leftFace, Color.White.copy(alpha = 0.85f * bp), style = edgeStroke)
                    drawPath(rightFace, Color.White.copy(alpha = 0.85f * bp), style = edgeStroke)
                    drawPath(roofFace, ElectricBlue.copy(alpha = 0.95f * bp), style = edgeStroke)

                    // Floor slab dividers (3 levels)
                    for (lvl in 1..3) {
                        val frac = lvl / 4f
                        if (bp >= frac) {
                            val yOff = maxTowerH * frac
                            drawLine(
                                ElectricBlue.copy(alpha = 0.65f),
                                Offset(baseCenter.x, baseCenter.y - yOff),
                                Offset(leftBottom.x, leftBottom.y - yOff),
                                strokeWidth = 1.6f
                            )
                            drawLine(
                                ElectricBlue.copy(alpha = 0.65f),
                                Offset(baseCenter.x, baseCenter.y - yOff),
                                Offset(rightBottom.x, rightBottom.y - yOff),
                                strokeWidth = 1.6f
                            )
                        }
                    }

                    // Engineering caliper / crane accent in orange
                    if (bp > 0.6f) {
                        val accentAlpha = ((bp - 0.6f) / 0.4f).coerceIn(0f, 1f)
                        drawLine(
                            EngineeringOrange.copy(alpha = accentAlpha),
                            Offset(topCenter.x + isoW * 0.35f, topCenter.y - isoH * 0.4f),
                            Offset(topCenter.x + isoW * 0.35f, topCenter.y - isoH * 1.45f),
                            strokeWidth = 4f,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            EngineeringOrange.copy(alpha = accentAlpha),
                            Offset(topCenter.x - isoW * 0.2f, topCenter.y - isoH * 1.25f),
                            Offset(topCenter.x + isoW * 1.05f, topCenter.y - isoH * 1.25f),
                            strokeWidth = 3.5f,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Stage 3: Dimension / Measurement Lines around building
                if (dp > 0f) {
                    val dimColor = EngineeringOrange.copy(alpha = 0.9f * dp)
                    val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                    val dimX = w * 0.88f
                    val topY = h * 0.22f
                    val botY = h * 0.78f
                    drawLine(
                        dimColor,
                        Offset(dimX, topY),
                        Offset(dimX, topY + (botY - topY) * dp),
                        strokeWidth = 2f,
                        pathEffect = dash
                    )
                    // Ticks
                    drawLine(dimColor, Offset(dimX - 7f, topY), Offset(dimX + 7f, topY), strokeWidth = 2.5f)
                    if (dp > 0.9f) {
                        drawLine(dimColor, Offset(dimX - 7f, botY), Offset(dimX + 7f, botY), strokeWidth = 2.5f)
                    }
                    // Bottom horizontal dimension line
                    val dimY = h * 0.88f
                    drawLine(
                        VerifiedGreen.copy(alpha = 0.85f * dp),
                        Offset(w * 0.16f, dimY),
                        Offset(w * 0.16f + w * 0.68f * dp, dimY),
                        strokeWidth = 2f
                    )
                }
            }

            Spacer(Modifier.height(22.dp))

            // Stage 4: Title BUILD MASTER
            AnimatedVisibility(
                visible = showTitle,
                enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { 20 }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "BUILD MASTER",
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            letterSpacing = 3.sp
                        ),
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = bi(lang, "مستر ساختمان", "Construction Engineering Suite"),
                        style = MaterialTheme.typography.titleLarge,
                        color = EngineeringOrange
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = bi(
                            lang,
                            "مهندسی دقیق، برآورد هوشمند، ساخت مطمئن",
                            "Precision Engineering, Smart Estimation, Confident Building"
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ElectricBlue,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Stage 5: Creator credit at bottom
        AnimatedVisibility(
            visible = showCreator,
            enter = fadeIn(tween(500)),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = bi(lang, "طراحی و توسعه:", "Designed & Developed by:"),
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFF94A3B8)
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = bi(lang, "قاسم غلامرضاپور", "Ghasem Gholamrezapour"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
