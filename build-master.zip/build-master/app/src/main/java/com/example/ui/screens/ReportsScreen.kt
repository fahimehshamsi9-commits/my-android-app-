package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.CalcHelper
import com.example.engine.ToolId
import com.example.engine.UnitConverter.formatNumber
import com.example.model.CalculationRecordEntity
import com.example.engine.MaterialEstimate
import com.example.model.ProjectEntity
import com.example.model.UserSettings
import com.example.model.bi
import com.example.ui.components.EngineeringCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.VerifiedGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportsScreen(
    activeProject: ProjectEntity?,
    records: List<CalculationRecordEntity>,
    settings: UserSettings,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit,
    onSharePdf: () -> Unit,
    onPrint: () -> Unit,
    onOpenFinalBoqTool: (ToolId) -> Unit,
    onDeleteRecord: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = settings.language
    val currency = settings.currency(lang)

    val projectRecords = remember(activeProject?.id, records) {
        if (activeProject != null) records.filter { it.projectId == activeProject.id || it.projectId == null }
        else records
    }

    val consolidatedMaterials = remember(projectRecords) {
        val map = linkedMapOf<String, MaterialEstimate>()
        projectRecords.forEach { rec ->
            CalcHelper.parseMaterialsFromJson(rec.payloadJson).forEach { m ->
                val prev = map[m.materialKey]
                map[m.materialKey] = m.copy(
                    netQuantity = (prev?.netQuantity ?: 0.0) + m.netQuantity,
                    orderQuantity = (prev?.orderQuantity ?: 0.0) + m.orderQuantity,
                    totalCost = (prev?.totalCost ?: 0.0) + m.totalCost
                )
            }
        }
        map.values.toList()
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("reports_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            EngineeringCard(accentColor = EngineeringOrange) {
                Text(
                    text = bi(lang, "گزارش جامع متره و برآورد (PDF / Excel / چاپ)", "Engineering Reports (PDF / Excel / Print)"),
                    style = MaterialTheme.typography.titleLarge,
                    color = EngineeringOrange
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = activeProject?.let {
                        "${bi(lang, "پروژه:", "Project:")} ${it.name} (${projectRecords.size} ${bi(lang, "محاسبه", "records")})"
                    } ?: bi(lang, "همه محاسبات ثبت‌شده (${projectRecords.size})", "All saved calculations (${projectRecords.size})"),
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onExportPdf,
                        colors = ButtonDefaults.buttonColors(containerColor = EngineeringOrange),
                        modifier = Modifier.testTag("export_pdf_btn")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "خروجی PDF", "Export PDF"))
                    }
                    Button(
                        onClick = onExportExcel,
                        colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen),
                        modifier = Modifier.testTag("export_excel_btn")
                    ) {
                        Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "خروجی Excel", "Export Excel"))
                    }
                    OutlinedButton(onClick = onPrint, modifier = Modifier.testTag("print_report_btn")) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "چاپ گزارش", "Print"))
                    }
                    OutlinedButton(onClick = onSharePdf, modifier = Modifier.testTag("share_report_btn")) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "اشتراک‌گذاری", "Share"))
                    }
                    OutlinedButton(onClick = { onOpenFinalBoqTool(ToolId.FINAL_PROJECT_BOQ) }) {
                        Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "برآورد نهایی (۴۰)", "Final BOQ (#40)"))
                    }
                }
            }
        }

        // Consolidated Materials Table
        if (consolidatedMaterials.isNotEmpty()) {
            item {
                EngineeringCard(accentColor = ElectricBlue) {
                    Text(
                        text = bi(lang, "جدول تجمیعی مصالح پروژه", "Consolidated Materials Schedule"),
                        style = MaterialTheme.typography.titleMedium,
                        color = ElectricBlue
                    )
                    Spacer(Modifier.height(8.dp))
                    consolidatedMaterials.forEachIndexed { idx, m ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(m.name(lang), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text(
                                    "${bi(lang, "خالص:", "Net:")} ${formatNumber(m.netQuantity)} -> ${bi(lang, "پیشنهادی:", "Order:")} ${formatNumber(m.orderQuantity)} ${m.unit.symbol(lang)}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                    color = VerifiedGreen
                                )
                            }
                            if (m.totalCost > 0) {
                                Text(
                                    "${formatNumber(m.totalCost, 0)} $currency",
                                    style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                    color = EngineeringOrange
                                )
                            }
                        }
                        if (idx < consolidatedMaterials.lastIndex) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        }
                    }
                }
            }
        }

        // History of Calculation Records
        item {
            Text(
                text = bi(lang, "تاریخچه محاسبات (${projectRecords.size})", "Calculation History (${projectRecords.size})"),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (projectRecords.isEmpty()) {
            item {
                EngineeringCard(accentColor = MaterialTheme.colorScheme.outline) {
                    Text(
                        text = bi(
                            lang,
                            "هنوز محاسبه‌ای ذخیره نشده است. پس از اجرای هر ابزار، دکمه «ثبت در پروژه» را بزنید تا در گزارش‌ها ظاهر شود.",
                            "No calculations recorded yet. Run any tool and tap 'Save Result' to include it in reports."
                        ),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        items(projectRecords, key = { it.id }) { rec ->
            val dateFormatted = remember(rec.createdAt) {
                SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(rec.createdAt))
            }
            EngineeringCard(accentColor = MaterialTheme.colorScheme.outline) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(bi(lang, rec.toolTitleFa, rec.toolTitleEn), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(dateFormatted, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    StatusBadge(isPreliminary = rec.isPreliminary, lang = lang)
                    IconButton(onClick = { onDeleteRecord(rec.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = bi(lang, "حذف", "Delete"), tint = AlertRed)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = bi(lang, rec.summaryFa, rec.summaryEn),
                    style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = ElectricBlue
                )
                Text(
                    text = "${bi(lang, "فرمول:", "Formula:")} ${rec.formulaUsed}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (rec.estimatedCost > 0) {
                    Text(
                        text = "${bi(lang, "هزینه برآوردی:", "Est. Cost:")} ${formatNumber(rec.estimatedCost, 0)} $currency",
                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = EngineeringOrange
                    )
                }
            }
        }
    }
}
