package com.example.engine

data class SteelSectionSpec(
    val code: String,
    val titleFa: String,
    val titleEn: String,
    val category: SteelCategory,
    val weightKgPerMeter: Double,
    val standardRef: String
) {
    fun title(lang: com.example.model.AppLanguage): String = com.example.model.bi(lang, titleFa, titleEn)
}

enum class SteelCategory(val titleFa: String, val titleEn: String) {
    IBEAM("تیرآهن استاندارد (IPE / IPB / INP)", "Standard I-Beams (IPE / HEB / INP)"),
    HOLLOW_PROFILE("پروفیل و قوطی فولادی", "Hollow Structural Profiles & Sections")
}

object SteelCatalog {
    // Verified standard weights from DIN 1025 / Iranian National Standard 1791 & St37 tables
    val iBeams: List<SteelSectionSpec> = listOf(
        SteelSectionSpec("IPE120", "تیرآهن IPE 120", "IPE 120", SteelCategory.IBEAM, 10.4, "DIN 1025-5"),
        SteelSectionSpec("IPE140", "تیرآهن IPE 140", "IPE 140", SteelCategory.IBEAM, 12.9, "DIN 1025-5"),
        SteelSectionSpec("IPE160", "تیرآهن IPE 160", "IPE 160", SteelCategory.IBEAM, 15.8, "DIN 1025-5"),
        SteelSectionSpec("IPE180", "تیرآهن IPE 180", "IPE 180", SteelCategory.IBEAM, 18.8, "DIN 1025-5"),
        SteelSectionSpec("IPE200", "تیرآهن IPE 200", "IPE 200", SteelCategory.IBEAM, 22.4, "DIN 1025-5"),
        SteelSectionSpec("IPE220", "تیرآهن IPE 220", "IPE 220", SteelCategory.IBEAM, 26.2, "DIN 1025-5"),
        SteelSectionSpec("IPE240", "تیرآهن IPE 240", "IPE 240", SteelCategory.IBEAM, 30.7, "DIN 1025-5"),
        SteelSectionSpec("IPE270", "تیرآهن IPE 270", "IPE 270", SteelCategory.IBEAM, 36.1, "DIN 1025-5"),
        SteelSectionSpec("IPE300", "تیرآهن IPE 300", "IPE 300", SteelCategory.IBEAM, 42.2, "DIN 1025-5"),
        SteelSectionSpec("HEB140", "تیرآهن هاش IPB 140 (HEB)", "HEB 140 (IPB)", SteelCategory.IBEAM, 33.7, "DIN 1025-2"),
        SteelSectionSpec("HEB160", "تیرآهن هاش IPB 160 (HEB)", "HEB 160 (IPB)", SteelCategory.IBEAM, 42.6, "DIN 1025-2"),
        SteelSectionSpec("HEB180", "تیرآهن هاش IPB 180 (HEB)", "HEB 180 (IPB)", SteelCategory.IBEAM, 51.2, "DIN 1025-2"),
        SteelSectionSpec("HEB200", "تیرآهن هاش IPB 200 (HEB)", "HEB 200 (IPB)", SteelCategory.IBEAM, 61.3, "DIN 1025-2"),
        SteelSectionSpec("HEB240", "تیرآهن هاش IPB 240 (HEB)", "HEB 240 (IPB)", SteelCategory.IBEAM, 83.2, "DIN 1025-2"),
        SteelSectionSpec("HEB300", "تیرآهن هاش IPB 300 (HEB)", "HEB 300 (IPB)", SteelCategory.IBEAM, 117.0, "DIN 1025-2"),
        SteelSectionSpec("INP140", "تیرآهن INP 140", "INP 140", SteelCategory.IBEAM, 14.3, "DIN 1025-1"),
        SteelSectionSpec("INP180", "تیرآهن INP 180", "INP 180", SteelCategory.IBEAM, 21.9, "DIN 1025-1"),
        SteelSectionSpec("INP200", "تیرآهن INP 200", "INP 200", SteelCategory.IBEAM, 26.2, "DIN 1025-1")
    )

    val profiles: List<SteelSectionSpec> = listOf(
        SteelSectionSpec("BOX_40x40x2", "قوطی ۴۰×۴۰ ضخامت ۲ میل", "SHS 40x40x2 mm", SteelCategory.HOLLOW_PROFILE, 2.38, "EN 10219"),
        SteelSectionSpec("BOX_40x40x3", "قوطی ۴۰×۴۰ ضخامت ۳ میل", "SHS 40x40x3 mm", SteelCategory.HOLLOW_PROFILE, 3.45, "EN 10219"),
        SteelSectionSpec("BOX_60x60x2", "قوطی ۶۰×۶۰ ضخامت ۲ میل", "SHS 60x60x2 mm", SteelCategory.HOLLOW_PROFILE, 3.63, "EN 10219"),
        SteelSectionSpec("BOX_60x60x3", "قوطی ۶۰×۶۰ ضخامت ۳ میل", "SHS 60x60x3 mm", SteelCategory.HOLLOW_PROFILE, 5.33, "EN 10219"),
        SteelSectionSpec("BOX_80x40x2", "پروفیل ۸۰×۴۰ ضخامت ۲ میل", "RHS 80x40x2 mm", SteelCategory.HOLLOW_PROFILE, 3.63, "EN 10219"),
        SteelSectionSpec("BOX_80x80x3", "قوطی ۸۰×۸۰ ضخامت ۳ میل", "SHS 80x80x3 mm", SteelCategory.HOLLOW_PROFILE, 7.22, "EN 10219"),
        SteelSectionSpec("BOX_100x100x4", "قوطی ۱۰۰×۱۰۰ ضخامت ۴ میل", "SHS 100x100x4 mm", SteelCategory.HOLLOW_PROFILE, 11.95, "EN 10219"),
        SteelSectionSpec("UNP100", "ناودانی UNP 100", "Channel UNP 100", SteelCategory.HOLLOW_PROFILE, 10.6, "DIN 1026-1"),
        SteelSectionSpec("UNP140", "ناودانی UNP 140", "Channel UNP 140", SteelCategory.HOLLOW_PROFILE, 16.0, "DIN 1026-1"),
        SteelSectionSpec("UNP160", "ناودانی UNP 160", "Channel UNP 160", SteelCategory.HOLLOW_PROFILE, 18.8, "DIN 1026-1"),
        SteelSectionSpec("L50x50x5", "نبشی ۵۰×۵۰×۵ میل", "Angle L 50x50x5", SteelCategory.HOLLOW_PROFILE, 3.77, "EN 10056-1"),
        SteelSectionSpec("L60x60x6", "نبشی ۶۰×۶۰×۶ میل", "Angle L 60x60x6", SteelCategory.HOLLOW_PROFILE, 5.42, "EN 10056-1"),
        SteelSectionSpec("L80x80x8", "نبشی ۸۰×۸۰×۸ میل", "Angle L 80x80x8", SteelCategory.HOLLOW_PROFILE, 9.63, "EN 10056-1")
    )

    val standardRebarDiametersMm: List<Int> = listOf(8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32)

    fun findIBeam(code: String): SteelSectionSpec =
        iBeams.firstOrNull { it.code == code } ?: iBeams.first()

    fun findProfile(code: String): SteelSectionSpec =
        profiles.firstOrNull { it.code == code } ?: profiles.first()
}
