package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class SoundCue {
    CLICK,
    CALCULATE,
    MENU_OPEN,
    SAVE_PROJECT,
    REPORT_READY
}

/**
 * 100% offline procedural audio synthesizer using Android AudioTrack.
 * Produces subtle, crisp, non-intrusive engineering UI tones without external audio files.
 */
class SoundManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile var enabled: Boolean = true
    @Volatile var volume: Float = 0.6f

    fun play(cue: SoundCue) {
        if (!enabled || volume <= 0.01f) return
        scope.launch {
            try {
                when (cue) {
                    SoundCue.CLICK -> playTone(freqHz = 780.0, durationMs = 26, gain = 0.25f)
                    SoundCue.MENU_OPEN -> playTone(freqHz = 520.0, durationMs = 45, gain = 0.22f)
                    SoundCue.CALCULATE -> {
                        playTone(freqHz = 660.0, durationMs = 55, gain = 0.28f)
                        playTone(freqHz = 880.0, durationMs = 75, gain = 0.28f)
                    }
                    SoundCue.SAVE_PROJECT -> {
                        playTone(freqHz = 523.25, durationMs = 60, gain = 0.30f)
                        playTone(freqHz = 659.25, durationMs = 85, gain = 0.30f)
                    }
                    SoundCue.REPORT_READY -> {
                        playTone(freqHz = 523.25, durationMs = 55, gain = 0.28f)
                        playTone(freqHz = 659.25, durationMs = 55, gain = 0.28f)
                        playTone(freqHz = 783.99, durationMs = 110, gain = 0.30f)
                    }
                }
            } catch (_: Throwable) {
                // Safe no-op in headless/Robolectric environments
            }
        }
    }

    private fun playTone(freqHz: Double, durationMs: Int, gain: Float) {
        val sampleRate = 22050
        val count = (sampleRate * durationMs) / 1000
        if (count <= 0) return
        val samples = ShortArray(count)
        val effectiveGain = (gain * volume.coerceIn(0f, 1f)).coerceIn(0f, 0.5f)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            // Smooth attack and exponential decay envelope so there is zero harsh clicking
            val attack = (i / (count * 0.12 + 1.0)).coerceAtMost(1.0)
            val decay = exp(-4.0 * i / count)
            val wave = sin(2.0 * PI * freqHz * t) * attack * decay
            samples[i] = (wave * Short.MAX_VALUE * effectiveGain).toInt().toShort()
        }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(samples.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(samples, 0, samples.size)
        track.play()
        Thread.sleep(durationMs.toLong() + 15L)
        track.stop()
        track.release()
    }
}
