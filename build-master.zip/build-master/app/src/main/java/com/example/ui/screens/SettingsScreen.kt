package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.EngineeringUnit
import com.example.model.UserSettings
import com.example.model.bi
import com.example.ui.components.EngineeringCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.AppFontChoice
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.VerifiedGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: UserSettings,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit,
    onExportFullBackup: () -> Unit,
    onImportFullBackup: () -> Unit,
    onClearAllData: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = settings.language
    var showClearDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            EngineeringCard(accentColor = EngineeringOrange) {
                Text(bi(lang, "تنظیمات زبان و ظاهر برنامه", "Language & Appearance"), style = MaterialTheme.typography.titleLarge, color = EngineeringOrange)
                Spacer(Modifier.height(10.dp))

                Text(bi(lang, "زبان رابط کاربری (Language):", "Interface Language:"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppLanguage.entries.forEach { l ->
                        FilterChip(
                            selected = settings.language == l,
                            onClick = { onUpdateSettings { it.copy(language = l) } },
                            label = { Text(l.label) },
                            modifier = Modifier.testTag("lang_chip_${l.code}")
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(bi(lang, "تم تیره مهندسی (Dark Theme)", "Dark Engineering Theme"), style = MaterialTheme.typography.bodyLarge)
                    Switch(
                        checked = settings.darkTheme,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(darkTheme = v) } },
                        modifier = Modifier.testTag("dark_theme_switch")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(bi(lang, "انیمیشن‌های رابط کاربری", "Enable Animations"), style = MaterialTheme.typography.bodyLarge)
                    Switch(
                        checked = settings.animationsEnabled,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(animationsEnabled = v) } }
                    )
                }

                Spacer(Modifier.height(8.dp))
                Text(bi(lang, "انتخاب فونت:", "Font Family:"), style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AppFontChoice.entries.forEach { f ->
                        FilterChip(
                            selected = settings.fontChoice == f,
                            onClick = { onUpdateSettings { it.copy(fontChoice = f) } },
                            label = { Text(bi(lang, f.labelFa, f.labelEn)) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("${bi(lang, "اندازه فونت:", "Font Scale:")} ${(settings.fontScale * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = settings.fontScale,
                    onValueChange = { v -> onUpdateSettings { it.copy(fontScale = v) } },
                    valueRange = 0.85f..1.25f
                )
            }
        }

        item {
            EngineeringCard(accentColor = ElectricBlue) {
                Text(bi(lang, "تنظیمات صوتی و افکت‌ها", "Sound & Audio Feedback"), style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(bi(lang, "پخش افکت‌های صوتی", "Enable Sound Effects"), style = MaterialTheme.typography.bodyLarge)
                    Switch(
                        checked = settings.soundEnabled,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(soundEnabled = v) } }
                    )
                }
                Text("${bi(lang, "حجم صدا:", "Volume:")} ${(settings.soundVolume * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = settings.soundVolume,
                    onValueChange = { v -> onUpdateSettings { it.copy(soundVolume = v) } },
                    valueRange = 0f..1f
                )
            }
        }

        item {
            EngineeringCard(accentColor = VerifiedGreen) {
                Text(bi(lang, "تنظیمات مهندسی و واحدها", "Engineering Defaults"), style = MaterialTheme.typography.titleMedium, color = VerifiedGreen)
                Spacer(Modifier.height(8.dp))

                Text(bi(lang, "واحد پیش‌فرض طول:", "Default Length Unit:"), style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(EngineeringUnit.M, EngineeringUnit.CM, EngineeringUnit.MM).forEach { u ->
                        FilterChip(
                            selected = settings.defaultLengthUnit == u,
                            onClick = { onUpdateSettings { it.copy(defaultLengthUnit = u) } },
                            label = { Text(u.symbol(lang)) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                var wasteStr by remember(settings.defaultWastePercent) { mutableStateOf(settings.defaultWastePercent.toString()) }
                OutlinedTextField(
                    value = wasteStr,
                    onValueChange = { raw ->
                        wasteStr = raw.filter { c -> c.isDigit() || c == '.' }
                        wasteStr.toDoubleOrNull()?.let { v ->
                            if (v in 0.0..50.0) onUpdateSettings { it.copy(defaultWastePercent = v) }
                        }
                    },
                    label = { Text(bi(lang, "درصد پرت پیش‌فرض مصالح (%)", "Default Waste Percentage (%)")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))
                Text(bi(lang, "واحد پول:", "Currency Unit:"), style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "تومان" to "Toman",
                        "ریال" to "Rial",
                        "دلار ($)" to "USD ($)",
                        "یورو (€)" to "EUR (€)"
                    ).forEach { (fa, en) ->
                        FilterChip(
                            selected = settings.currencySymbolFa == fa,
                            onClick = { onUpdateSettings { it.copy(currencySymbolFa = fa, currencySymbolEn = en) } },
                            label = { Text(bi(lang, fa, en)) }
                        )
                    }
                }
            }
        }

        item {
            EngineeringCard(accentColor = MaterialTheme.colorScheme.outline) {
                Text(bi(lang, "مدیریت داده‌ها، پشتیبان‌گیری و بازیابی", "Data Management, Backup & Restore"), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onExportFullBackup,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "پشتیبان‌گیری JSON", "Backup JSON"))
                    }
                    OutlinedButton(
                        onClick = onImportFullBackup,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "بازیابی اطلاعات", "Restore Backup"))
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { showClearDialog = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                    Spacer(Modifier.size(6.dp))
                    Text(bi(lang, "پاک‌سازی همه پروژه‌ها و تاریخچه", "Clear All Projects & History"))
                }
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text(bi(lang, "تأیید پاک‌سازی اطلاعات", "Confirm Clear All Data")) },
            text = { Text(bi(lang, "آیا مطمئن هستید که می‌خواهید تمام پروژه‌ها و محاسبات ذخیره‌شده را حذف کنید؟", "Delete all projects and saved calculation records?")) },
            confirmButton = {
                Button(
                    onClick = { onClearAllData(); showClearDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Text(bi(lang, "حذف کامل", "Delete All"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text(bi(lang, "انصراف", "Cancel")) }
            }
        )
    }
}
