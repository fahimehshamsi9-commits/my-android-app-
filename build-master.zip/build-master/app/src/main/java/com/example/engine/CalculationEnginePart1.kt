package com.example.engine

import com.example.engine.CalcHelper.errorOutcome
import com.example.engine.CalcHelper.getMassKg
import com.example.engine.CalcHelper.getMeters
import com.example.engine.CalcHelper.getMillimeters
import com.example.engine.CalcHelper.getRaw
import com.example.engine.CalcHelper.makeMaterial
import com.example.engine.CalcHelper.standardEngineeringLimitations
import com.example.engine.UnitConverter.formatNumber
import com.example.engine.UnitConverter.roundTo
import com.example.model.EngineeringUnit
import kotlin.math.ceil
import kotlin.math.hypot

internal object CalculationEnginePart1 {

    fun execute(def: ToolDefinition, input: CalculationInput): CalculationOutcome {
        val cat = input.priceCatalog
        val (limFa, limEn) = standardEngineeringLimitations(def.isStructuralAdvisory)
        val missingProject = input.project?.missingCriticalFields(com.example.model.AppLanguage.FA).orEmpty()
        val missingProjectEn = input.project?.missingCriticalFields(com.example.model.AppLanguage.EN).orEmpty()

        return when (def.id) {
            ToolId.LAND_AREA -> {
                val l = getMeters(input, "length", 20.0)
                val w = getMeters(input, "width", 12.0)
                val k = getRaw(input, "shapeFactor", 1.0)
                val area = l * w * k
                val perim = 2.0 * (l + w)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "مساحت زمین", primaryLabelEn = "Land Area",
                    primaryValue = roundTo(area, 2), primaryUnit = EngineeringUnit.M2,
                    secondaryMetrics = listOf(ResultMetric("محیط زمین", "Plot Perimeter", roundTo(perim, 2), EngineeringUnit.M)),
                    steps = listOf(
                        CalculationStep("تبدیل ابعاد به متر", "Dimensions in meters", "L=${formatNumber(l)}m, W=${formatNumber(w)}m, k=${formatNumber(k)}", "${formatNumber(l)} × ${formatNumber(w)}"),
                        CalculationStep("مساحت نهایی", "Total area", "A = ${formatNumber(l)} × ${formatNumber(w)} × ${formatNumber(k)}", "${formatNumber(area)} m²")
                    ),
                    assumptionsFa = listOf("طول = ${formatNumber(l)} متر، عرض = ${formatNumber(w)} متر، ضریب شکل = ${formatNumber(k)}"),
                    assumptionsEn = listOf("Length = ${formatNumber(l)} m, Width = ${formatNumber(w)} m, Shape factor = ${formatNumber(k)}"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            ToolId.BUILT_UP_AREA -> {
                val floors = getRaw(input, "floors", 4.0)
                val floorArea = getRaw(input, "floorArea", 160.0)
                val extra = getRaw(input, "extraArea", 25.0)
                val total = (floors * floorArea) + extra
                val isPrelim = input.project != null && (input.project.floorsCount <= 0 || input.project.floorBuiltUpAreaM2 <= 0)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true, isPreliminary = isPrelim,
                    preliminaryReasonFa = if (isPrelim) "برخی مشخصات طبقات در پروژه ناقص است." else null,
                    preliminaryReasonEn = if (isPrelim) "Some project floor fields are incomplete." else null,
                    primaryLabelFa = "زیربنای کل", primaryLabelEn = "Total Built-up Area",
                    primaryValue = roundTo(total, 2), primaryUnit = EngineeringUnit.M2,
                    secondaryMetrics = listOf(
                        ResultMetric("زیربنای خالص طبقات", "Floors Subtotal", roundTo(floors * floorArea, 2), EngineeringUnit.M2)
                    ),
                    steps = listOf(
                        CalculationStep("زیربنای طبقات", "Floors area", "${floors.toInt()} × ${formatNumber(floorArea)}", "${formatNumber(floors * floorArea)} m²"),
                        CalculationStep("جمع با مشاعات/بالکن", "Add extra area", "${formatNumber(floors * floorArea)} + ${formatNumber(extra)}", "${formatNumber(total)} m²")
                    ),
                    assumptionsFa = listOf("تعداد طبقات: ${floors.toInt()}، زیربنای هر طبقه: ${formatNumber(floorArea)} m²"),
                    assumptionsEn = listOf("Floors: ${floors.toInt()}, Area/floor: ${formatNumber(floorArea)} m²"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            ToolId.BUILDING_VOLUME -> {
                val l = getMeters(input, "length", 16.0)
                val w = getMeters(input, "width", 10.0)
                val h = getMeters(input, "height", 13.5)
                val vol = l * w * h
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم هندسی ساختمان", primaryLabelEn = "Building Volume",
                    primaryValue = roundTo(vol, 2), primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(ResultMetric("سطح اشغال پلان", "Footprint Area", roundTo(l * w, 2), EngineeringUnit.M2)),
                    steps = listOf(
                        CalculationStep("سطح پلان", "Plan footprint", "${formatNumber(l)} × ${formatNumber(w)}", "${formatNumber(l * w)} m²"),
                        CalculationStep("حجم کل", "Gross volume", "${formatNumber(l * w)} × ${formatNumber(h)}", "${formatNumber(vol)} m³")
                    ),
                    assumptionsFa = listOf("ابعاد پلان ${formatNumber(l)}×${formatNumber(w)} متر و ارتفاع کل ${formatNumber(h)} متر"),
                    assumptionsEn = listOf("Footprint ${formatNumber(l)}×${formatNumber(w)} m, height ${formatNumber(h)} m"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            ToolId.TOTAL_CONCRETE_VOLUME -> {
                val vf = getRaw(input, "foundation", 32.0)
                val vc = getRaw(input, "columns", 18.0)
                val vb = getRaw(input, "beams", 22.0)
                val vs = getRaw(input, "slabs", 48.0)
                val vst = getRaw(input, "stairs", 6.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)
                val net = vf + vc + vb + vs + vst
                if (net <= 0.0) return errorOutcome(def.id, "مجموع حجم اجزای بتنی باید بزرگ‌تر از صفر باشد.", "Sum of concrete parts must be > 0.")
                val mat = makeMaterial("ready_concrete", "بتن آماده / مصرفی کل", "Total Ready-Mix Concrete", net, waste, EngineeringUnit.M3, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم کل بتن (با پرت)", primaryLabelEn = "Total Concrete (with waste)",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(
                        ResultMetric("حجم هندسی خالص", "Net Geometric Volume", roundTo(net, 2), EngineeringUnit.M3),
                        ResultMetric("وزن تقریبی بتن مسلح", "Approx. Mass (2500 kg/m³)", roundTo(net * 2500.0 / 1000.0, 2), EngineeringUnit.TON)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("جمع اجزای بتنی", "Sum members", "$vf + $vc + $vb + $vs + $vst", "${formatNumber(net)} m³"),
                        CalculationStep("اعمال ضریب پرت (${formatNumber(waste)}%)", "Apply waste", "${formatNumber(net)} × (1 + ${waste/100.0})", "${formatNumber(mat.orderQuantity)} m³")
                    ),
                    assumptionsFa = listOf("مجموع ۵ عضو سازه‌ای با ضریب پرت ${formatNumber(waste)}%"),
                    assumptionsEn = listOf("Sum of 5 structural concrete elements with ${formatNumber(waste)}% waste"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.EXCAVATION_VOLUME -> {
                val l = getMeters(input, "length", 20.0)
                val w = getMeters(input, "width", 12.0)
                val d = getMeters(input, "depth", 3.2)
                val a = getMeters(input, "overcut", 0.3)
                val swell = getRaw(input, "swell", 1.25)
                if (swell < 1.0) return errorOutcome(def.id, "ضریب تورم خاک معمولاً >= 1.0 است.", "Soil swell factor must be >= 1.0.")
                val effL = l + 2.0 * a
                val effW = w + 2.0 * a
                val bankVol = effL * effW * d
                val looseVol = bankVol * swell
                val trucks = ceil(looseVol / 15.0) // 15m3 dump truck
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم خاکبرداری برجا", primaryLabelEn = "Bank Excavation Volume",
                    primaryValue = roundTo(bankVol, 2), primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(
                        ResultMetric("حجم خاک متورم (حمل)", "Loose Haulage Volume", roundTo(looseVol, 2), EngineeringUnit.M3),
                        ResultMetric("تعداد کامیون ۱۵مترمکعبی", "Est. 15m³ Dump Trucks", trucks, EngineeringUnit.PCS)
                    ),
                    steps = listOf(
                        CalculationStep("ابعاد گود با فضای کار", "Effective pit dimensions", "(${formatNumber(l)}+2×${formatNumber(a)}) × (${formatNumber(w)}+2×${formatNumber(a)})", "${formatNumber(effL)} × ${formatNumber(effW)} m"),
                        CalculationStep("حجم برجا", "Bank volume", "${formatNumber(effL)} × ${formatNumber(effW)} × ${formatNumber(d)}", "${formatNumber(bankVol)} m³"),
                        CalculationStep("حجم با ضریب تورم (${formatNumber(swell)})", "Loose volume", "${formatNumber(bankVol)} × ${formatNumber(swell)}", "${formatNumber(looseVol)} m³")
                    ),
                    assumptionsFa = listOf("فضای کار پیرامونی ${formatNumber(a)} متر در هر طرف و ضریب تورم ${formatNumber(swell)} لحاظ شده است."),
                    assumptionsEn = listOf("Working space ${formatNumber(a)} m per side and swell factor ${formatNumber(swell)} applied."),
                    limitationsFa = limFa + "نیاز به بررسی پایداری جداره گود و نوع خاک توسط مهندس ژئوتکنیک.",
                    limitationsEn = limEn + "Pit wall shoring and soil classification require geotechnical engineering review.",
                    formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            ToolId.BACKFILL_VOLUME -> {
                val l = getMeters(input, "length", 18.0)
                val w = getMeters(input, "width", 10.0)
                val d = getMeters(input, "depth", 0.8)
                val comp = getRaw(input, "compactionFactor", 1.15)
                val swell = getRaw(input, "swellFactor", 1.20)
                val compactedVol = l * w * d
                val bankRequired = compactedVol * comp
                val looseRequired = bankRequired * swell
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم خاک سست موردنیاز برای حمل", primaryLabelEn = "Loose Borrow Soil Required",
                    primaryValue = roundTo(looseRequired, 2), primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(
                        ResultMetric("حجم هندسی متراکم‌شده", "Compacted Net Volume", roundTo(compactedVol, 2), EngineeringUnit.M3),
                        ResultMetric("حجم خاک برجا (Bank)", "Bank Soil Needed", roundTo(bankRequired, 2), EngineeringUnit.M3)
                    ),
                    steps = listOf(
                        CalculationStep("حجم متراکم هدف", "Compacted target", "${formatNumber(l)} × ${formatNumber(w)} × ${formatNumber(d)}", "${formatNumber(compactedVol)} m³"),
                        CalculationStep("اعمال ضریب تراکم (${formatNumber(comp)})", "Compaction factor", "${formatNumber(compactedVol)} × ${formatNumber(comp)}", "${formatNumber(bankRequired)} m³"),
                        CalculationStep("اعمال ضریب تورم حمل (${formatNumber(swell)})", "Swell factor", "${formatNumber(bankRequired)} × ${formatNumber(swell)}", "${formatNumber(looseRequired)} m³")
                    ),
                    assumptionsFa = listOf("ضریب تراکم = ${formatNumber(comp)}، ضریب تورم = ${formatNumber(swell)}"),
                    assumptionsEn = listOf("Compaction factor = ${formatNumber(comp)}, Swell factor = ${formatNumber(swell)}"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            // ================= GROUP 2: CONCRETE & MATERIALS =================
            ToolId.FOUNDATION_CONCRETE -> {
                val n = getRaw(input, "count", 6.0)
                val l = getMeters(input, "length", 12.0)
                val w = getMeters(input, "width", 1.2)
                val h = getMeters(input, "height", 0.65)
                val leanT = getMeters(input, "leanThickness", 0.1)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)
                val structVol = n * l * w * h
                val leanVol = if (leanT > 0) n * (l + 0.2) * (w + 0.2) * leanT else 0.0
                val matStruct = makeMaterial("ready_concrete", "بتن سازه‌ای فونداسیون", "Structural Foundation Concrete", structVol, waste, EngineeringUnit.M3, cat)
                val matLean = if (leanVol > 0) listOf(makeMaterial("ready_concrete", "بتن مگر (نظافت)", "Lean Blinding Concrete", leanVol, waste, EngineeringUnit.M3, cat)) else emptyList()
                val allMats = listOf(matStruct) + matLean
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "بتن سازه‌ای فونداسیون (با پرت)", primaryLabelEn = "Foundation Concrete (with waste)",
                    primaryValue = matStruct.orderQuantity, primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(
                        ResultMetric("حجم خالص سازه‌ای", "Net Structural Volume", roundTo(structVol, 2), EngineeringUnit.M3),
                        ResultMetric("بتن مگر (با پرت)", "Lean Concrete Order", roundTo(leanVol * (1 + waste / 100.0), 2), EngineeringUnit.M3)
                    ),
                    materials = allMats,
                    steps = listOf(
                        CalculationStep("بتن سازه‌ای خالص", "Net structural concrete", "${n.toInt()} × ${formatNumber(l)} × ${formatNumber(w)} × ${formatNumber(h)}", "${formatNumber(structVol)} m³"),
                        CalculationStep("بتن مگر (با ۱۰ سانت اضافه طرفین)", "Lean concrete (+10cm side)", "${n.toInt()} × (${formatNumber(l)}+0.2) × (${formatNumber(w)}+0.2) × ${formatNumber(leanT)}", "${formatNumber(leanVol)} m³"),
                        CalculationStep("سفارش با پرت ${formatNumber(waste)}%", "Order with waste", "${formatNumber(structVol)} × (1 + ${waste/100.0})", "${formatNumber(matStruct.orderQuantity)} m³")
                    ),
                    assumptionsFa = listOf("مقطع پی مستطیلی با ${n.toInt()} بخش و پرت ${formatNumber(waste)}%"),
                    assumptionsEn = listOf("Rectangular footing segments (${n.toInt()}) with ${formatNumber(waste)}% waste"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = allMats.sumOf { it.totalCost }
                )
            }

            ToolId.COLUMN_CONCRETE -> {
                val n = getRaw(input, "count", 16.0)
                val b = getMeters(input, "width", 0.45)
                val h = getMeters(input, "depth", 0.45)
                val ht = getMeters(input, "height", 3.2)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 4.0)
                val net = n * b * h * ht
                val mat = makeMaterial("ready_concrete", "بتن ستون‌ها", "Column Concrete", net, waste, EngineeringUnit.M3, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم سفارش بتن ستون", primaryLabelEn = "Column Concrete Order",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(ResultMetric("حجم هندسی خالص", "Net Volume", roundTo(net, 2), EngineeringUnit.M3)),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("مساحت مقطع یک ستون", "Single column area", "${formatNumber(b)} × ${formatNumber(h)}", "${formatNumber(b * h, 4)} m²"),
                        CalculationStep("حجم کل ${n.toInt()} ستون", "Total net volume", "${n.toInt()} × ${formatNumber(b * h, 4)} × ${formatNumber(ht)}", "${formatNumber(net)} m³")
                    ),
                    assumptionsFa = listOf("${n.toInt()} ستون با مقطع ${formatNumber(b*100)}×${formatNumber(h*100)} سانتی‌متر و ارتفاع ${formatNumber(ht)} متر"),
                    assumptionsEn = listOf("${n.toInt()} columns of ${formatNumber(b*100)}×${formatNumber(h*100)} cm, height ${formatNumber(ht)} m"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.BEAM_CONCRETE -> {
                val n = getRaw(input, "count", 14.0)
                val l = getMeters(input, "length", 5.5)
                val b = getMeters(input, "width", 0.35)
                val h = getMeters(input, "depth", 0.45)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 4.0)
                val net = n * l * b * h
                val mat = makeMaterial("ready_concrete", "بتن تیرها", "Beam Concrete", net, waste, EngineeringUnit.M3, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم سفارش بتن تیر", primaryLabelEn = "Beam Concrete Order",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(ResultMetric("حجم هندسی خالص", "Net Volume", roundTo(net, 2), EngineeringUnit.M3)),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("حجم یک تیر", "One beam volume", "${formatNumber(l)} × ${formatNumber(b)} × ${formatNumber(h)}", "${formatNumber(l * b * h, 3)} m³"),
                        CalculationStep("حجم کل ${n.toInt()} تیر", "Total net", "${n.toInt()} × ${formatNumber(l * b * h, 3)}", "${formatNumber(net)} m³")
                    ),
                    assumptionsFa = listOf("${n.toInt()} تیر به طول ${formatNumber(l)} متر و مقطع ${formatNumber(b*100)}×${formatNumber(h*100)} سانتی‌متر"),
                    assumptionsEn = listOf("${n.toInt()} beams of length ${formatNumber(l)} m, section ${formatNumber(b*100)}×${formatNumber(h*100)} cm"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.SLAB_CONCRETE -> {
                val area = getRaw(input, "area", 160.0)
                val thick = getMeters(input, "thickness", 0.11)
                val floors = getRaw(input, "floors", 1.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)
                val net = area * thick * floors
                val mat = makeMaterial("ready_concrete", "بتن سقف", "Slab Concrete", net, waste, EngineeringUnit.M3, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم سفارش بتن سقف", primaryLabelEn = "Slab Concrete Order",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(ResultMetric("حجم خالص سقف", "Net Slab Volume", roundTo(net, 2), EngineeringUnit.M3)),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("حجم یک سقف", "Single slab volume", "${formatNumber(area)} × ${formatNumber(thick, 3)}", "${formatNumber(area * thick)} m³"),
                        CalculationStep("ضرب در ${floors.toInt()} سقف + پرت", "Multiply floors + waste", "${formatNumber(net)} × (1+${waste/100.0})", "${formatNumber(mat.orderQuantity)} m³")
                    ),
                    assumptionsFa = listOf("مساحت ${formatNumber(area)} m²، ضخامت معادل ${formatNumber(thick*100)} سانتی‌متر، تعداد سقف ${floors.toInt()}"),
                    assumptionsEn = listOf("Area ${formatNumber(area)} m², effective thickness ${formatNumber(thick*100)} cm, ${floors.toInt()} slabs"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.STAIRCASE_CONCRETE -> {
                val flights = getRaw(input, "flights", 2.0)
                val width = getMeters(input, "width", 1.2)
                val steps = getRaw(input, "stepsPerFlight", 9.0)
                val riser = getMeters(input, "riser", 0.18)
                val tread = getMeters(input, "tread", 0.30)
                val waist = getMeters(input, "waistThickness", 0.15)
                val landingA = getRaw(input, "landingArea", 3.6)
                val landingT = getMeters(input, "landingThickness", 0.15)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)

                val slopeStep = hypot(riser, tread)
                val flightLength = steps * slopeStep
                val waistVolPerFlight = width * flightLength * waist
                val stepsVolPerFlight = steps * (0.5 * riser * tread * width)
                val landingVol = landingA * landingT
                val net = flights * (waistVolPerFlight + stepsVolPerFlight) + landingVol
                val mat = makeMaterial("ready_concrete", "بتن راه‌پله", "Staircase Concrete", net, waste, EngineeringUnit.M3, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم سفارش بتن راه‌پله", primaryLabelEn = "Staircase Concrete Order",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(
                        ResultMetric("حجم هندسی خالص", "Net Volume", roundTo(net, 2), EngineeringUnit.M3),
                        ResultMetric("طول شیب‌دار هر بازو", "Slope Length/Flight", roundTo(flightLength, 2), EngineeringUnit.M)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("طول شیب‌دار هر بازو", "Flight slope length", "${steps.toInt()} × √(${formatNumber(riser)}²+${formatNumber(tread)}²)", "${formatNumber(flightLength)} m"),
                        CalculationStep("بتن کمرپله و مثلث پله‌ها", "Waist + triangular steps", "${flights.toInt()} × (${formatNumber(waistVolPerFlight,3)} + ${formatNumber(stepsVolPerFlight,3)})", "${formatNumber(flights*(waistVolPerFlight+stepsVolPerFlight),3)} m³"),
                        CalculationStep("جمع با بتن پاگرد", "Add landing concrete", "+ ${formatNumber(landingVol,3)} m³", "${formatNumber(net,3)} m³")
                    ),
                    assumptionsFa = listOf("${flights.toInt()} بازو، ${steps.toInt()} پله (${formatNumber(riser*100)}×${formatNumber(tread*100)} cm)، کمرپله ${formatNumber(waist*100)} cm"),
                    assumptionsEn = listOf("${flights.toInt()} flights, ${steps.toInt()} steps (${formatNumber(riser*100)}×${formatNumber(tread*100)} cm), waist ${formatNumber(waist*100)} cm"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.CONCRETE_MIX_MATERIALS -> {
                val vol = getRaw(input, "volume", 25.0)
                val dryFactor = getRaw(input, "dryFactor", 1.54)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)
                val mix = input.mixGrade
                val totalParts = mix.cementPart + mix.sandPart + mix.gravelPart
                val dryVol = vol * dryFactor
                val cementKgNet = vol * mix.cementKgPerM3
                val sandM3Net = (mix.sandPart / totalParts) * dryVol
                val gravelM3Net = (mix.gravelPart / totalParts) * dryVol

                val matCement = makeMaterial("cement", "سیمان پرتلند (${mix.titleFa})", "Portland Cement", cementKgNet, waste, EngineeringUnit.KG, cat, 50.0, "کیسه ۵۰ کیلویی", "50 kg Bags")
                val matSand = makeMaterial("sand", "ماسه شسته", "Washed Sand", sandM3Net, waste, EngineeringUnit.M3, cat)
                val matGravel = makeMaterial("gravel", "شن دانه بندی شده", "Coarse Gravel", gravelM3Net, waste, EngineeringUnit.M3, cat)
                val mats = listOf(matCement, matSand, matGravel)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "سیمان موردنیاز (کیسه ۵۰ کیلویی)", primaryLabelEn = "Cement Required (50kg Bags)",
                    primaryValue = matCement.packageCount, primaryUnit = EngineeringUnit.BAG,
                    secondaryMetrics = listOf(
                        ResultMetric("وزن سیمان (با پرت)", "Cement Mass (w/ waste)", matCement.orderQuantity, EngineeringUnit.KG),
                        ResultMetric("ماسه موردنیاز (با پرت)", "Sand Required", matSand.orderQuantity, EngineeringUnit.M3),
                        ResultMetric("شن موردنیاز (با پرت)", "Gravel Required", matGravel.orderQuantity, EngineeringUnit.M3)
                    ),
                    materials = mats,
                    steps = listOf(
                        CalculationStep("طرح اختلاط انتخاب‌شده", "Selected mix grade", "${mix.titleEn} | نسبت ${mix.cementPart}:${mix.sandPart}:${mix.gravelPart}", "${mix.cementKgPerM3.toInt()} kg/m³"),
                        CalculationStep("حجم خشک کل", "Total dry volume", "${formatNumber(vol)} × ${formatNumber(dryFactor)}", "${formatNumber(dryVol)} m³"),
                        CalculationStep("سیمان خالص و کیسه", "Cement weight & bags", "${formatNumber(vol)} × ${mix.cementKgPerM3.toInt()} kg", "${formatNumber(cementKgNet)} kg -> ${matCement.packageCount.toInt()} bags"),
                        CalculationStep("ماسه و شن خالص", "Net sand & gravel", "Sand=${formatNumber(sandM3Net)} m³, Gravel=${formatNumber(gravelM3Net)} m³", "Done")
                    ),
                    assumptionsFa = listOf("طرح اختلاط: ${mix.titleFa} (نسبت حجمی ${mix.cementPart}:${mix.sandPart}:${mix.gravelPart})، عیار سیمان ${mix.cementKgPerM3.toInt()} kg/m³، ضریب تبدیل خشک ${formatNumber(dryFactor)}"),
                    assumptionsEn = listOf("Mix: ${mix.titleEn} (ratio ${mix.cementPart}:${mix.sandPart}:${mix.gravelPart}), cement content ${mix.cementKgPerM3.toInt()} kg/m³, dry factor ${formatNumber(dryFactor)}"),
                    limitationsFa = limFa + "رطوبت مصالح سنگی و دانه‌بندی باید در کارگاه آزمایش و تعدیل شود.",
                    limitationsEn = limEn + "Aggregate moisture content and gradation must be verified by lab/batching trial mix.",
                    formulaUsed = def.formulaEn, standardRef = mix.standardRef,
                    totalEstimatedCost = mats.sumOf { it.totalCost }
                )
            }

            ToolId.MORTAR_MATERIALS -> {
                val vol = getRaw(input, "volume", 4.5)
                val sandRatio = getRaw(input, "sandRatio", 4.0)
                val dryFactor = getRaw(input, "dryFactor", 1.33)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)
                val dryVol = vol * dryFactor
                val parts = 1.0 + sandRatio
                val cementM3 = (1.0 / parts) * dryVol
                val cementKgNet = cementM3 * 1440.0
                val sandM3Net = (sandRatio / parts) * dryVol
                val matCement = makeMaterial("cement", "سیمان ملات", "Mortar Cement", cementKgNet, waste, EngineeringUnit.KG, cat, 50.0, "کیسه ۵۰ کیلویی", "50 kg Bags")
                val matSand = makeMaterial("sand", "ماسه نرم ملات", "Mortar Sand", sandM3Net, waste, EngineeringUnit.M3, cat)
                val mats = listOf(matCement, matSand)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "سیمان ملات (کیسه ۵۰ کیلویی)", primaryLabelEn = "Mortar Cement (50kg Bags)",
                    primaryValue = matCement.packageCount, primaryUnit = EngineeringUnit.BAG,
                    secondaryMetrics = listOf(
                        ResultMetric("ماسه موردنیاز", "Sand Volume", matSand.orderQuantity, EngineeringUnit.M3),
                        ResultMetric("وزن سیمان", "Cement Mass", matCement.orderQuantity, EngineeringUnit.KG)
                    ),
                    materials = mats,
                    steps = listOf(
                        CalculationStep("حجم خشک ملات", "Dry mortar volume", "${formatNumber(vol)} × ${formatNumber(dryFactor)}", "${formatNumber(dryVol)} m³"),
                        CalculationStep("نسبت اختلاط 1:${formatNumber(sandRatio)}", "Mix 1:${formatNumber(sandRatio)}", "Cement=${formatNumber(cementKgNet)} kg, Sand=${formatNumber(sandM3Net)} m³", "${matCement.packageCount.toInt()} bags")
                    ),
                    assumptionsFa = listOf("نسبت ملات ۱ به ${formatNumber(sandRatio)}، وزن مخصوص فله سیمان ۱۴۴۰ kg/m³"),
                    assumptionsEn = listOf("Mortar ratio 1:${formatNumber(sandRatio)}, bulk cement density 1440 kg/m³"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mats.sumOf { it.totalCost }
                )
            }

            ToolId.CONCRETE_WEIGHT -> {
                val vol = getRaw(input, "volume", 20.0)
                val density = getRaw(input, "density", 2500.0)
                val kg = vol * density
                val tons = kg / 1000.0
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "وزن کل بتن", primaryLabelEn = "Total Concrete Weight",
                    primaryValue = roundTo(tons, 2), primaryUnit = EngineeringUnit.TON,
                    secondaryMetrics = listOf(ResultMetric("وزن به کیلوگرم", "Weight in kg", roundTo(kg, 1), EngineeringUnit.KG)),
                    steps = listOf(CalculationStep("ضرب حجم در چگالی", "V × ρ", "${formatNumber(vol)} × ${formatNumber(density)}", "${formatNumber(kg)} kg = ${formatNumber(tons)} ton")),
                    assumptionsFa = listOf("چگالی انتخابی: ${formatNumber(density)} kg/m³"),
                    assumptionsEn = listOf("Selected density: ${formatNumber(density)} kg/m³"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            // ================= GROUP 3: STEEL & REBAR =================
            ToolId.REBAR_WEIGHT -> {
                val dMm = getMillimeters(input, "diameter", 16.0)
                val lenM = getMeters(input, "length", 12.0)
                val count = getRaw(input, "count", 50.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 3.0)
                val kgPerM = (dMm * dMm) / 162.0
                val netKg = kgPerM * lenM * count
                val totalLen = lenM * count
                val bars12m = ceil((totalLen * (1 + waste / 100.0)) / 12.0)
                val mat = makeMaterial("rebar", "میلگرد سایز ${dMm.toInt()}", "Rebar Ø${dMm.toInt()} mm", netKg, waste, EngineeringUnit.KG, cat, 12.0 * kgPerM, "شاخه ۱۲ متری", "12m Stock Bars")
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "وزن کل میلگرد (با پرت)", primaryLabelEn = "Total Rebar Weight (w/ waste)",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.KG,
                    secondaryMetrics = listOf(
                        ResultMetric("وزن خالص هندسی", "Net Weight", roundTo(netKg, 2), EngineeringUnit.KG),
                        ResultMetric("وزن واحد هر متر", "Unit Weight (kg/m)", roundTo(kgPerM, 3), EngineeringUnit.KG),
                        ResultMetric("معادل شاخه ۱۲ متری", "12m Stock Bars", bars12m, EngineeringUnit.PCS),
                        ResultMetric("وزن به تن", "Weight in Tons", roundTo(mat.orderQuantity / 1000.0, 3), EngineeringUnit.TON)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("وزن هر متر میلگرد", "Unit weight d²/162", "${formatNumber(dMm)}² / 162", "${formatNumber(kgPerM, 3)} kg/m"),
                        CalculationStep("وزن خالص کل", "Net total weight", "${formatNumber(kgPerM, 3)} × ${formatNumber(lenM)} × ${count.toInt()}", "${formatNumber(netKg)} kg"),
                        CalculationStep("با ضریب پرت ${formatNumber(waste)}%", "With waste", "${formatNumber(netKg)} × (1+${waste/100.0})", "${formatNumber(mat.orderQuantity)} kg")
                    ),
                    assumptionsFa = listOf("فرمول نظری d²/162 برای فولاد با چگالی ۷۸۵۰ kg/m³ و قطر ${formatNumber(dMm)} میلی‌متر"),
                    assumptionsEn = listOf("Theoretical d²/162 formula (steel density 7850 kg/m³), diameter ${formatNumber(dMm)} mm"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = "W = (d² / 162) × L × N", standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.CUT_REBAR_LIST -> {
                val rows = input.cutRebarRows
                if (rows.isEmpty()) return errorOutcome(def.id, "حداقل یک ردیف میلگرد اضافه کنید.", "Add at least one rebar row.")
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 4.0)
                var netKg = 0.0
                var totalLen = 0.0
                val steps = mutableListOf<CalculationStep>()
                rows.forEachIndexed { idx, r ->
                    if (r.diameterMm <= 0 || r.lengthM <= 0 || r.count <= 0) {
                        return errorOutcome(def.id, "ردیف ${idx + 1} دارای مقدار صفر یا منفی است.", "Row ${idx + 1} has zero or negative values.")
                    }
                    val unitW = (r.diameterMm * r.diameterMm) / 162.0
                    val rowW = unitW * r.lengthM * r.count
                    netKg += rowW
                    totalLen += r.lengthM * r.count
                    steps.add(
                        CalculationStep(
                            "ردیف ${idx + 1}: Ø${r.diameterMm}",
                            "Row ${idx + 1}: Ø${r.diameterMm}",
                            "(${r.diameterMm}²/162) × ${r.lengthM}m × ${r.count}",
                            "${formatNumber(rowW)} kg"
                        )
                    )
                }
                val mat = makeMaterial("rebar", "مجموع میلگردهای برش‌خورده", "Total Cut Rebar Schedule", netKg, waste, EngineeringUnit.KG, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "وزن کل لیست میلگرد (با پرت)", primaryLabelEn = "Total Schedule Weight (w/ waste)",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.KG,
                    secondaryMetrics = listOf(
                        ResultMetric("وزن خالص لیست", "Net Weight", roundTo(netKg, 2), EngineeringUnit.KG),
                        ResultMetric("طول کل برش‌ها", "Total Cut Length", roundTo(totalLen, 2), EngineeringUnit.LM),
                        ResultMetric("وزن به تن", "Total Tons", roundTo(mat.orderQuantity / 1000.0, 3), EngineeringUnit.TON)
                    ),
                    materials = listOf(mat),
                    steps = steps,
                    assumptionsFa = listOf("${rows.size} ردیف برش با پرت برشکاری ${formatNumber(waste)}%"),
                    assumptionsEn = listOf("${rows.size} bar rows with ${formatNumber(waste)}% cutting waste"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.STEEL_PROFILE_WEIGHT -> {
                val spec = SteelCatalog.findProfile(input.selectedProfileCode)
                val len = getMeters(input, "length", 6.0)
                val count = getRaw(input, "count", 20.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 2.5)
                val netKg = spec.weightKgPerMeter * len * count
                val mat = makeMaterial("steel_profile", spec.titleFa, spec.titleEn, netKg, waste, EngineeringUnit.KG, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "وزن کل پروفیل (با پرت)", primaryLabelEn = "Total Profile Weight (w/ waste)",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.KG,
                    secondaryMetrics = listOf(
                        ResultMetric("وزن واحد جدول اشتال", "Table Unit Weight", spec.weightKgPerMeter, EngineeringUnit.KG),
                        ResultMetric("وزن خالص", "Net Weight", roundTo(netKg, 2), EngineeringUnit.KG)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("وزن واحد مقطع", "Section unit weight", spec.titleEn, "${spec.weightKgPerMeter} kg/m"),
                        CalculationStep("وزن خالص کل", "Net weight", "${spec.weightKgPerMeter} × ${formatNumber(len)} × ${count.toInt()}", "${formatNumber(netKg)} kg")
                    ),
                    assumptionsFa = listOf("مقطع ${spec.titleFa} با وزن ${spec.weightKgPerMeter} kg/m مطابق ${spec.standardRef}"),
                    assumptionsEn = listOf("Section ${spec.titleEn} at ${spec.weightKgPerMeter} kg/m per ${spec.standardRef}"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = spec.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.IBEAM_WEIGHT -> {
                val spec = SteelCatalog.findIBeam(input.selectedIBeamCode)
                val len = getMeters(input, "length", 12.0)
                val count = getRaw(input, "count", 8.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 2.0)
                val netKg = spec.weightKgPerMeter * len * count
                val mat = makeMaterial("ibeam", spec.titleFa, spec.titleEn, netKg, waste, EngineeringUnit.KG, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "وزن کل تیرآهن (با پرت)", primaryLabelEn = "Total I-Beam Weight (w/ waste)",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.KG,
                    secondaryMetrics = listOf(
                        ResultMetric("وزن واحد تیرآهن", "Unit Weight (kg/m)", spec.weightKgPerMeter, EngineeringUnit.KG),
                        ResultMetric("وزن خالص", "Net Weight", roundTo(netKg, 2), EngineeringUnit.KG),
                        ResultMetric("وزن به تن", "Tons", roundTo(mat.orderQuantity / 1000.0, 3), EngineeringUnit.TON)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("وزن هر متر از جدول", "Table unit mass", spec.titleEn, "${spec.weightKgPerMeter} kg/m"),
                        CalculationStep("وزن خالص", "Net mass", "${spec.weightKgPerMeter} × ${formatNumber(len)} × ${count.toInt()}", "${formatNumber(netKg)} kg")
                    ),
                    assumptionsFa = listOf("تیرآهن ${spec.titleFa} با وزن اسمی ${spec.weightKgPerMeter} kg/m (${spec.standardRef})"),
                    assumptionsEn = listOf("I-Beam ${spec.titleEn} nominal ${spec.weightKgPerMeter} kg/m (${spec.standardRef})"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = spec.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.STEEL_PLATE_WEIGHT -> {
                val l = getMeters(input, "length", 2.0)
                val w = getMeters(input, "width", 1.0)
                val t = getMeters(input, "thickness", 0.01)
                val count = getRaw(input, "count", 4.0)
                val density = getRaw(input, "density", 7850.0)
                val kg = l * w * t * density * count
                val mat = makeMaterial("steel_profile", "ورق فولادی", "Steel Plate", kg, 0.0, EngineeringUnit.KG, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "وزن کل ورق فولادی", primaryLabelEn = "Total Steel Plate Weight",
                    primaryValue = roundTo(kg, 2), primaryUnit = EngineeringUnit.KG,
                    secondaryMetrics = listOf(ResultMetric("حجم ورق", "Plate Volume", roundTo(l * w * t * count, 4), EngineeringUnit.M3)),
                    materials = listOf(mat),
                    steps = listOf(CalculationStep("حجم × چگالی × تعداد", "L×W×t×ρ×N", "${formatNumber(l)}×${formatNumber(w)}×${formatNumber(t,4)}×${density.toInt()}×${count.toInt()}", "${formatNumber(kg)} kg")),
                    assumptionsFa = listOf("چگالی فولاد ${density.toInt()} kg/m³"),
                    assumptionsEn = listOf("Steel density ${density.toInt()} kg/m³"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.TOTAL_PROJECT_STEEL -> {
                val extraKg = getMassKg(input, "extraSteelKg", 0.0)
                val steelIds = setOf(
                    ToolId.REBAR_WEIGHT.name, ToolId.CUT_REBAR_LIST.name,
                    ToolId.STEEL_PROFILE_WEIGHT.name, ToolId.IBEAM_WEIGHT.name, ToolId.STEEL_PLATE_WEIGHT.name
                )
                val savedSteel = input.savedProjectRecords.filter { it.toolId in steelIds }
                val fromRecordsKg = savedSteel.sumOf { it.primaryValue }
                val totalKg = fromRecordsKg + extraKg
                val isPrelim = savedSteel.isEmpty() && extraKg == 0.0
                val mat = makeMaterial("rebar", "مجموع فولاد مصرفی پروژه", "Total Project Steel", totalKg, 0.0, EngineeringUnit.KG, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true, isPreliminary = isPrelim,
                    preliminaryReasonFa = if (isPrelim) "هنوز محاسبه میلگرد یا تیرآهن در این پروژه ذخیره نشده است." else null,
                    preliminaryReasonEn = if (isPrelim) "No rebar or structural steel calculations saved in active project yet." else null,
                    primaryLabelFa = "مجموع فولاد پروژه", primaryLabelEn = "Total Project Steel",
                    primaryValue = roundTo(totalKg, 2), primaryUnit = EngineeringUnit.KG,
                    secondaryMetrics = listOf(
                        ResultMetric("از محاسبات ذخیره‌شده (${savedSteel.size} مورد)", "From Saved Records (${savedSteel.size})", roundTo(fromRecordsKg, 2), EngineeringUnit.KG),
                        ResultMetric("مجموع به تن", "Total in Tons", roundTo(totalKg / 1000.0, 3), EngineeringUnit.TON)
                    ),
                    materials = if (totalKg > 0) listOf(mat) else emptyList(),
                    steps = listOf(
                        CalculationStep("جمع اقلام فولادی ثبت‌شده", "Sum saved steel records", "${savedSteel.size} items", "${formatNumber(fromRecordsKg)} kg"),
                        CalculationStep("جمع با مقدار دستی", "Add manual steel", "${formatNumber(fromRecordsKg)} + ${formatNumber(extraKg)}", "${formatNumber(totalKg)} kg")
                    ),
                    assumptionsFa = listOf("تجمیع خودکار رکوردهای میلگرد، پروفیل، تیرآهن و ورق در پروژه فعال"),
                    assumptionsEn = listOf("Aggregates saved rebar, profile, I-beam & plate records in active project"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            // ================= GROUP 4: MASONRY & WALLS =================
            ToolId.BRICK_COUNT -> {
                val area = getRaw(input, "wallArea", 45.0)
                val bL = getMeters(input, "brickLength", 0.215)
                val bH = getMeters(input, "brickHeight", 0.055)
                val j = getMeters(input, "jointThickness", 0.012)
                val wythes = getRaw(input, "wythes", 1.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)
                val perM2 = (1.0 / ((bL + j) * (bH + j))) * wythes
                val netCount = ceil(area * perM2)
                val mat = makeMaterial("brick", "آجر دیوارچینی", "Wall Bricks", netCount, waste, EngineeringUnit.PCS, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "تعداد آجر پیشنهادی خرید", primaryLabelEn = "Recommended Bricks to Order",
                    primaryValue = ceil(mat.orderQuantity), primaryUnit = EngineeringUnit.PCS,
                    secondaryMetrics = listOf(
                        ResultMetric("تعداد خالص هندسی", "Net Brick Count", netCount, EngineeringUnit.PCS),
                        ResultMetric("تعداد آجر در هر مترمربع", "Bricks per m²", roundTo(perM2, 1), EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat.copy(orderQuantity = ceil(mat.orderQuantity))),
                    steps = listOf(
                        CalculationStep("تعداد آجر در ۱ مترمربع", "Bricks per m²", "1 / ((${formatNumber(bL,3)}+${formatNumber(j,3)})×(${formatNumber(bH,3)}+${formatNumber(j,3)})) × $wythes", "${formatNumber(perM2, 1)} pcs/m²"),
                        CalculationStep("تعداد خالص و با پرت", "Net & with waste", "${formatNumber(area)} × ${formatNumber(perM2,1)} × (1+${waste/100.0})", "${ceil(mat.orderQuantity).toInt()} pcs")
                    ),
                    assumptionsFa = listOf("ابعاد آجر ${formatNumber(bL*100)}×${formatNumber(bH*100)} سانتی‌متر، بند ${formatNumber(j*100)} سانتی‌متر، ضریب ضخامت $wythes"),
                    assumptionsEn = listOf("Brick ${formatNumber(bL*100)}×${formatNumber(bH*100)} cm, joint ${formatNumber(j*100)} cm, wythe factor $wythes"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.CEMENT_BLOCK_COUNT -> {
                val wL = getMeters(input, "wallLength", 14.0)
                val wH = getMeters(input, "wallHeight", 3.0)
                val openA = getRaw(input, "openingsArea", 4.5)
                val bL = getMeters(input, "blockLength", 0.40)
                val bH = getMeters(input, "blockHeight", 0.20)
                val j = getMeters(input, "jointThickness", 0.015)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)
                val grossA = wL * wH
                val netA = grossA - openA
                if (netA <= 0.0) return errorOutcome(def.id, "مساحت بازشوها نمی‌تواند بزرگ‌تر یا مساوی کل دیوار باشد.", "Openings area must be smaller than gross wall area.")
                val perM2 = 1.0 / ((bL + j) * (bH + j))
                val netCount = ceil(netA * perM2)
                val mat = makeMaterial("cement_block", "بلوک سیمانی", "Cement Blocks", netCount, waste, EngineeringUnit.PCS, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "تعداد بلوک سیمانی (با پرت)", primaryLabelEn = "Cement Blocks Order",
                    primaryValue = ceil(mat.orderQuantity), primaryUnit = EngineeringUnit.PCS,
                    secondaryMetrics = listOf(
                        ResultMetric("مساحت خالص دیوار", "Net Wall Area", roundTo(netA, 2), EngineeringUnit.M2),
                        ResultMetric("تعداد خالص بلوک", "Net Blocks", netCount, EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat.copy(orderQuantity = ceil(mat.orderQuantity))),
                    steps = listOf(
                        CalculationStep("مساحت خالص دیوار", "Net wall area", "(${formatNumber(wL)}×${formatNumber(wH)}) - ${formatNumber(openA)}", "${formatNumber(netA)} m²"),
                        CalculationStep("تعداد بلوک", "Block count", "${formatNumber(netA)} × ${formatNumber(perM2, 2)} pcs/m²", "${netCount.toInt()} -> ${ceil(mat.orderQuantity).toInt()} pcs")
                    ),
                    assumptionsFa = listOf("بلوک ${formatNumber(bL*100)}×${formatNumber(bH*100)} سانتی‌متر و بند ${formatNumber(j*100)} سانتی‌متر"),
                    assumptionsEn = listOf("Block ${formatNumber(bL*100)}×${formatNumber(bH*100)} cm, joint ${formatNumber(j*100)} cm"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.AAC_HEBELX_BLOCK_COUNT -> {
                val area = getRaw(input, "wallArea", 50.0)
                val bL = getMeters(input, "blockLength", 0.60)
                val bH = getMeters(input, "blockHeight", 0.25)
                val bT = getMeters(input, "blockThickness", 0.15)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 4.0)
                val j = 0.003 // 3mm thin-bed adhesive joint
                val perM2 = 1.0 / ((bL + j) * (bH + j))
                val netCount = ceil(area * perM2)
                val adhesiveKg = area * (bT / 0.15) * 3.5 // ~3.5 kg/m² for 15cm wall
                val matBlock = makeMaterial("aac_block", "بلوک هبلکس (${(bT*100).toInt()} cm)", "AAC Hebelx Blocks", netCount, waste, EngineeringUnit.PCS, cat)
                val matGlue = makeMaterial("adhesive", "چسب مخصوص هبلکس", "AAC Thin-Bed Adhesive", adhesiveKg, waste, EngineeringUnit.KG, cat, 25.0, "کیسه ۲۵ کیلویی", "25 kg Bags")
                val mats = listOf(matBlock.copy(orderQuantity = ceil(matBlock.orderQuantity)), matGlue)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "تعداد بلوک هبلکس (با پرت)", primaryLabelEn = "AAC Blocks Order",
                    primaryValue = ceil(matBlock.orderQuantity), primaryUnit = EngineeringUnit.PCS,
                    secondaryMetrics = listOf(
                        ResultMetric("حجم کل بلوک‌ها", "Total Block Volume", roundTo(area * bT, 2), EngineeringUnit.M3),
                        ResultMetric("چسب موردنیاز", "Thin-bed Adhesive", matGlue.orderQuantity, EngineeringUnit.KG)
                    ),
                    materials = mats,
                    steps = listOf(
                        CalculationStep("بلوک در مترمربع (بند ۳ میل)", "Blocks/m² (3mm joint)", "1 / ((${formatNumber(bL,2)}+0.003)×(${formatNumber(bH,2)}+0.003))", "${formatNumber(perM2, 2)} pcs/m²"),
                        CalculationStep("تعداد کل و چسب", "Blocks & adhesive", "${netCount.toInt()} -> ${ceil(matBlock.orderQuantity).toInt()} pcs", "${formatNumber(matGlue.orderQuantity)} kg adhesive")
                    ),
                    assumptionsFa = listOf("بند نازک ۳ میلی‌متری چسب هبلکس و ضخامت دیوار ${formatNumber(bT*100)} سانتی‌متر"),
                    assumptionsEn = listOf("3mm thin-bed adhesive joint, wall thickness ${formatNumber(bT*100)} cm"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mats.sumOf { it.totalCost }
                )
            }

            ToolId.MASONRY_MORTAR_VOLUME -> {
                val area = getRaw(input, "wallArea", 45.0)
                val wallT = getMeters(input, "wallThickness", 0.20)
                val uL = getMeters(input, "unitLength", 0.215)
                val uW = getMeters(input, "unitWidth", 0.10)
                val uH = getMeters(input, "unitHeight", 0.055)
                val j = getMeters(input, "jointThickness", 0.012)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 7.0)

                val wallVol = area * wallT
                val effectiveUnitWithMortarVol = (uL + j) * (uW + j) * (uH + j)
                val unitsInWall = wallVol / effectiveUnitWithMortarVol
                val solidUnitsVol = unitsInWall * (uL * uW * uH)
                val netMortar = (wallVol - solidUnitsVol).coerceAtLeast(0.0)
                val orderMortar = netMortar * (1.0 + waste / 100.0)
                val cementKg = orderMortar * 1.33 * (1.0 / 5.0) * 1440.0 // 1:4 standard masonry mortar
                val sandM3 = orderMortar * 1.33 * (4.0 / 5.0)
                val matCement = makeMaterial("cement", "سیمان ملات (نسبت ۱:۴)", "Mortar Cement (1:4)", cementKg, 0.0, EngineeringUnit.KG, cat, 50.0, "کیسه ۵۰ کیلویی", "50 kg Bags")
                val matSand = makeMaterial("sand", "ماسه ملات", "Mortar Sand", sandM3, 0.0, EngineeringUnit.M3, cat)
                val mats = listOf(matCement, matSand)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "حجم ملات دیوارچینی (با پرت)", primaryLabelEn = "Masonry Mortar Volume",
                    primaryValue = roundTo(orderMortar, 3), primaryUnit = EngineeringUnit.M3,
                    secondaryMetrics = listOf(
                        ResultMetric("حجم خالص ملات", "Net Mortar Volume", roundTo(netMortar, 3), EngineeringUnit.M3),
                        ResultMetric("تعداد تقریبی واحد بنایی", "Est. Masonry Units", ceil(unitsInWall), EngineeringUnit.PCS)
                    ),
                    materials = mats,
                    steps = listOf(
                        CalculationStep("حجم کل دیوار", "Gross wall volume", "${formatNumber(area)} × ${formatNumber(wallT)}", "${formatNumber(wallVol, 3)} m³"),
                        CalculationStep("کسر حجم خالص واحدهای بنایی", "Subtract solid unit volume", "${formatNumber(wallVol,3)} - ${formatNumber(solidUnitsVol,3)}", "${formatNumber(netMortar, 3)} m³")
                    ),
                    assumptionsFa = listOf("کسر حجم واحد بنایی از حجم کل دیوار، ملات ۱:۴ برای برآورد سیمان و ماسه"),
                    assumptionsEn = listOf("Wall volume minus net masonry unit volume; 1:4 cement-sand mortar ratio"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mats.sumOf { it.totalCost }
                )
            }

            ToolId.WALL_NET_AREA -> {
                val wc = getRaw(input, "wallCount", 4.0)
                val wl = getMeters(input, "wallLength", 6.0)
                val wh = getMeters(input, "wallHeight", 3.0)
                val dc = getRaw(input, "doorCount", 2.0)
                val da = getRaw(input, "doorArea", 1.9)
                val winc = getRaw(input, "windowCount", 2.0)
                val wina = getRaw(input, "windowArea", 2.4)
                val gross = wc * wl * wh
                val openings = (dc * da) + (winc * wina)
                val net = gross - openings
                if (net <= 0.0) return errorOutcome(def.id, "مساحت بازشوها نباید بزرگ‌تر یا مساوی مساحت کل دیوار باشد.", "Openings cannot exceed gross wall area.")
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "مساحت خالص دیوارها", primaryLabelEn = "Net Wall Area",
                    primaryValue = roundTo(net, 2), primaryUnit = EngineeringUnit.M2,
                    secondaryMetrics = listOf(
                        ResultMetric("مساحت ناخالص", "Gross Wall Area", roundTo(gross, 2), EngineeringUnit.M2),
                        ResultMetric("مجموع بازشوها", "Total Openings", roundTo(openings, 2), EngineeringUnit.M2)
                    ),
                    steps = listOf(
                        CalculationStep("مساحت ناخالص", "Gross area", "${wc.toInt()} × ${formatNumber(wl)} × ${formatNumber(wh)}", "${formatNumber(gross)} m²"),
                        CalculationStep("کسر در و پنجره", "Subtract openings", "${formatNumber(gross)} - ${formatNumber(openings)}", "${formatNumber(net)} m²")
                    ),
                    assumptionsFa = listOf("${wc.toInt()} دیوار، ${dc.toInt()} در، ${winc.toInt()} پنجره"),
                    assumptionsEn = listOf("${wc.toInt()} walls, ${dc.toInt()} doors, ${winc.toInt()} windows"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            else -> errorOutcome(def.id, "ابزار نامعتبر", "Unsupported tool in part 1")
        }
    }
}
