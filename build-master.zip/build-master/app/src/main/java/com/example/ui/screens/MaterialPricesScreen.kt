package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.engine.ToolId
import com.example.engine.UnitConverter.formatNumber
import com.example.model.AppLanguage
import com.example.model.EngineeringUnit
import com.example.model.MaterialPriceEntity
import com.example.model.UserSettings
import com.example.model.bi
import com.example.ui.components.EngineeringCard
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.VerifiedGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MaterialPricesScreen(
    prices: List<MaterialPriceEntity>,
    settings: UserSettings,
    onUpsertPrice: (MaterialPriceEntity) -> Unit,
    onResetDefaultPrices: () -> Unit,
    onOpenCostTool: (ToolId) -> Unit,
    modifier: Modifier = Modifier
) {
    val lang = settings.language
    val currency = settings.currency(lang)
    var editing by remember { mutableStateOf<MaterialPriceEntity?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("material_prices_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            EngineeringCard(accentColor = EngineeringOrange) {
                Text(
                    text = bi(lang, "سیستم قیمت‌گذاری آفلاین مصالح", "Offline Material Price Catalog"),
                    style = MaterialTheme.typography.titleLarge,
                    color = EngineeringOrange
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = bi(
                        lang,
                        "قیمت‌ها به‌صورت دستی توسط شما تنظیم و ذخیره می‌شوند (بدون دریافت خودکار از اینترنت) و در برآورد هزینه تمام ۴۰ ابزار اعمال می‌گردند.",
                        "Prices are updated manually by you offline (never fetched from internet) and automatically applied across all 40 tools."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onOpenCostTool(ToolId.MATERIAL_COST) },
                        colors = ButtonDefaults.buttonColors(containerColor = EngineeringOrange)
                    ) {
                        Text(bi(lang, "محاسبه هزینه مصالح (۳۹)", "Material Cost (#39)"))
                    }
                    OutlinedButton(onClick = {
                        editing = MaterialPriceEntity(
                            materialKey = "custom_${System.currentTimeMillis()}",
                            nameFa = "", nameEn = "",
                            categoryFa = "سایر", categoryEn = "Other",
                            unit = EngineeringUnit.PCS, unitPrice = 0.0
                        )
                    }) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.size(4.dp))
                        Text(bi(lang, "افزودن", "Add"))
                    }
                    IconButton(onClick = onResetDefaultPrices) {
                        Icon(Icons.Default.Refresh, contentDescription = bi(lang, "بازنشانی قیمت‌های پایه", "Reset defaults"))
                    }
                }
            }
        }

        items(prices, key = { it.materialKey }) { item ->
            val dateFormatted = remember(item.updatedAt) {
                SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(item.updatedAt))
            }
            EngineeringCard(
                onClick = { editing = item },
                accentColor = ElectricBlue
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.name(lang), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${item.category(lang)} • ${bi(lang, "بروزرسانی:", "Updated:")} $dateFormatted",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${formatNumber(item.unitPrice, 0)} $currency",
                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = VerifiedGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "/ ${item.unit.symbol(lang)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricBlue
                        )
                    }
                    IconButton(onClick = { editing = item }) {
                        Icon(Icons.Default.Edit, contentDescription = bi(lang, "ویرایش قیمت", "Edit price"), tint = EngineeringOrange)
                    }
                }
            }
        }
    }

    editing?.let { item ->
        var nameFa by remember(item) { mutableStateOf(item.nameFa) }
        var nameEn by remember(item) { mutableStateOf(item.nameEn) }
        var priceStr by remember(item) { mutableStateOf(if (item.unitPrice > 0) item.unitPrice.toLong().toString() else "") }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(bi(lang, "بروزرسانی قیمت مصالح", "Update Material Price")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nameFa,
                        onValueChange = { nameFa = it },
                        label = { Text(bi(lang, "نام فارسی", "Persian Name")) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = nameEn,
                        onValueChange = { nameEn = it },
                        label = { Text(bi(lang, "نام انگلیسی", "English Name")) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("${bi(lang, "قیمت واحد", "Unit Price")} ($currency / ${item.unit.symbol(lang)})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("edit_price_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = priceStr.toDoubleOrNull() ?: 0.0
                        onUpsertPrice(
                            item.copy(
                                nameFa = nameFa.ifBlank { nameEn.ifBlank { "مصالح" } },
                                nameEn = nameEn.ifBlank { nameFa.ifBlank { "Material" } },
                                unitPrice = p.coerceAtLeast(0.0)
                            )
                        )
                        editing = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EngineeringOrange)
                ) {
                    Text(bi(lang, "ذخیره قیمت", "Save Price"))
                }
            },
            dismissButton = {
                TextButton(onClick = { editing = null }) { Text(bi(lang, "انصراف", "Cancel")) }
            }
        )
    }
}
