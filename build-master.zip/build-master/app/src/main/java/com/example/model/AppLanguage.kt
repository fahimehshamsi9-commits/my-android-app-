package com.example.model

enum class AppLanguage(val code: String, val label: String) {
    FA("fa", "فارسی"),
    EN("en", "English");

    val isRtl: Boolean get() = this == FA
}

fun bi(lang: AppLanguage, fa: String, en: String): String =
    if (lang == AppLanguage.FA) fa else en
