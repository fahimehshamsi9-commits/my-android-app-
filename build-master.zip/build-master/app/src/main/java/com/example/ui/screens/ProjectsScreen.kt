package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.engine.UnitConverter.formatNumber
import com.example.model.AppLanguage
import com.example.model.BuildingType
import com.example.model.FoundationType
import com.example.model.FrameType
import com.example.model.ProjectEntity
import com.example.model.SlabType
import com.example.model.WallType
import com.example.model.bi
import com.example.ui.components.EngineeringCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PreliminaryAmber
import com.example.ui.theme.VerifiedGreen

@Composable
fun ProjectsScreen(
    projects: List<ProjectEntity>,
    activeProjectId: Long?,
    lang: AppLanguage,
    onSelectProject: (Long) -> Unit,
    onSaveProject: (ProjectEntity) -> Unit,
    onDeleteProject: (Long) -> Unit,
    onExportProjectJson: (Long) -> Unit,
    onImportProjectJson: () -> Unit,
    modifier: Modifier = Modifier
) {
    var editingProject by remember { mutableStateOf<ProjectEntity?>(null) }

    Scaffold(
        modifier = modifier.fillMaxSize().testTag("projects_screen"),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editingProject = ProjectEntity(name = "") },
                containerColor = EngineeringOrange,
                modifier = Modifier.testTag("add_project_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = bi(lang, "پروژه جدید", "New Project"))
            }
        }
    ) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = bi(lang, "پروژه‌های من (${projects.size})", "My Projects (${projects.size})"),
                        style = MaterialTheme.typography.titleLarge
                    )
                    OutlinedButton(onClick = onImportProjectJson) {
                        Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text(bi(lang, "ورود پروژه JSON", "Import JSON"))
                    }
                }
            }

            if (projects.isEmpty()) {
                item {
                    EngineeringCard(accentColor = ElectricBlue) {
                        Text(
                            text = bi(
                                lang,
                                "هیچ پروژه‌ای ثبت نشده است. دکمه «+» را بزنید تا اولین پروژه ساختمانی خود را با تمام مشخصات تعریف کنید.",
                                "No projects yet. Tap '+' to define your first construction project."
                            ),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            items(projects, key = { it.id }) { proj ->
                val isActive = proj.id == activeProjectId
                val missing = proj.missingCriticalFields(lang)
                EngineeringCard(
                    accentColor = if (isActive) VerifiedGreen else MaterialTheme.colorScheme.outline,
                    onClick = { onSelectProject(proj.id) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(proj.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(
                                "${proj.buildingType.title(lang)} • ${proj.frameType.title(lang)} • ${proj.location.ifBlank { "-" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (isActive) {
                            Icon(Icons.Default.Check, contentDescription = "Active", tint = VerifiedGreen)
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    StatusBadge(isPreliminary = missing.isNotEmpty(), lang = lang)
                    if (missing.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "${bi(lang, "اطلاعات ناقص:", "Missing specs:")} ${missing.joinToString("، ")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = PreliminaryAmber
                        )
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "${bi(lang, "طبقات:", "Floors:")} ${proj.floorsCount} | ${bi(lang, "واحد:", "Units:")} ${proj.unitsCount} | ${bi(lang, "زمین:", "Land:")} ${formatNumber(proj.effectiveLandAreaM2)} m² | ${bi(lang, "زیربنا:", "Built-up:")} ${formatNumber(proj.effectiveTotalBuiltUpAreaM2)} m²",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily)
                    )
                    Text(
                        text = "${proj.slabType.title(lang)} | ${proj.wallType.title(lang)} (${formatNumber(proj.wallThicknessCm)}cm) | ${proj.foundationType.title(lang)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onSelectProject(proj.id) }) {
                            Text(if (isActive) bi(lang, "پروژه فعال", "Active") else bi(lang, "انتخاب", "Select"))
                        }
                        IconButton(onClick = { editingProject = proj }) {
                            Icon(Icons.Default.Edit, contentDescription = bi(lang, "ویرایش", "Edit"), tint = ElectricBlue)
                        }
                        IconButton(onClick = { onExportProjectJson(proj.id) }) {
                            Icon(Icons.Default.Download, contentDescription = bi(lang, "خروجی JSON", "Export JSON"), tint = EngineeringOrange)
                        }
                        IconButton(onClick = { onDeleteProject(proj.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = bi(lang, "حذف", "Delete"), tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }

    editingProject?.let { initial ->
        ProjectEditorDialog(
            initial = initial,
            lang = lang,
            onDismiss = { editingProject = null },
            onSave = { saved ->
                onSaveProject(saved)
                editingProject = null
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProjectEditorDialog(
    initial: ProjectEntity,
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (ProjectEntity) -> Unit
) {
    var name by remember { mutableStateOf(initial.name) }
    var location by remember { mutableStateOf(initial.location) }
    var buildingType by remember { mutableStateOf(initial.buildingType) }
    var floors by remember { mutableStateOf(if (initial.floorsCount > 0) initial.floorsCount.toString() else "") }
    var units by remember { mutableStateOf(if (initial.unitsCount > 0) initial.unitsCount.toString() else "") }
    var landL by remember { mutableStateOf(if (initial.landLengthM > 0) initial.landLengthM.toString() else "") }
    var landW by remember { mutableStateOf(if (initial.landWidthM > 0) initial.landWidthM.toString() else "") }
    var landArea by remember { mutableStateOf(if (initial.landAreaM2 > 0) initial.landAreaM2.toString() else "") }
    var floorArea by remember { mutableStateOf(if (initial.floorBuiltUpAreaM2 > 0) initial.floorBuiltUpAreaM2.toString() else "") }
    var floorHeight by remember { mutableStateOf(if (initial.floorHeightM > 0) initial.floorHeightM.toString() else "") }
    var frameType by remember { mutableStateOf(initial.frameType) }
    var slabType by remember { mutableStateOf(initial.slabType) }
    var wallType by remember { mutableStateOf(initial.wallType) }
    var foundationType by remember { mutableStateOf(initial.foundationType) }
    var wallThick by remember { mutableStateOf(if (initial.wallThicknessCm > 0) initial.wallThicknessCm.toString() else "") }
    var rooms by remember { mutableStateOf(if (initial.roomsCount > 0) initial.roomsCount.toString() else "") }
    var baths by remember { mutableStateOf(if (initial.bathroomsCount > 0) initial.bathroomsCount.toString() else "") }
    var kitchens by remember { mutableStateOf(if (initial.kitchensCount > 0) initial.kitchensCount.toString() else "") }
    var materialGrade by remember { mutableStateOf(initial.materialGradeNote) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (initial.id == 0L) bi(lang, "تعریف پروژه جدید", "Create New Project")
                else bi(lang, "ویرایش مشخصات پروژه", "Edit Project Specifications")
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = bi(
                        lang,
                        "می‌توانید برخی فیلدها را خالی بگذارید؛ در این حالت محاسبات وابسته با برچسب «برآورد اولیه» نمایش داده می‌شوند.",
                        "Incomplete fields are allowed; dependent results will be marked 'Preliminary Estimate'."
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = PreliminaryAmber
                )

                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text(bi(lang, "نام پروژه *", "Project Name *")) },
                    modifier = Modifier.fillMaxWidth().testTag("project_name_input")
                )
                OutlinedTextField(
                    value = location, onValueChange = { location = it },
                    label = { Text(bi(lang, "محل پروژه", "Location")) },
                    modifier = Modifier.fillMaxWidth()
                )

                Text(bi(lang, "نوع ساختمان:", "Building Type:"), style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    BuildingType.entries.forEach { t ->
                        FilterChip(selected = buildingType == t, onClick = { buildingType = t }, label = { Text(t.title(lang)) })
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(floors, { floors = it }, bi(lang, "تعداد طبقات", "Floors"), Modifier.weight(1f))
                    NumField(units, { units = it }, bi(lang, "تعداد واحد", "Units"), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(landL, { landL = it }, bi(lang, "طول زمین (m)", "Land L (m)"), Modifier.weight(1f))
                    NumField(landW, { landW = it }, bi(lang, "عرض زمین (m)", "Land W (m)"), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(landArea, { landArea = it }, bi(lang, "مساحت زمین (m²)", "Land Area"), Modifier.weight(1f))
                    NumField(floorArea, { floorArea = it }, bi(lang, "زیربنای طبقه (m²)", "Floor Area"), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(floorHeight, { floorHeight = it }, bi(lang, "ارتفاع طبقه (m)", "Floor Ht (m)"), Modifier.weight(1f))
                    NumField(wallThick, { wallThick = it }, bi(lang, "ضخامت دیوار (cm)", "Wall Thick (cm)"), Modifier.weight(1f))
                }

                Text(bi(lang, "نوع اسکلت:", "Frame Type:"), style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FrameType.entries.forEach { f ->
                        FilterChip(selected = frameType == f, onClick = { frameType = f }, label = { Text(f.title(lang)) })
                    }
                }

                Text(bi(lang, "نوع سقف:", "Slab / Roof Type:"), style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SlabType.entries.forEach { s ->
                        FilterChip(selected = slabType == s, onClick = { slabType = s }, label = { Text(s.title(lang)) })
                    }
                }

                Text(bi(lang, "نوع دیوارچینی:", "Wall Type:"), style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WallType.entries.forEach { w ->
                        FilterChip(selected = wallType == w, onClick = { wallType = w }, label = { Text(w.title(lang)) })
                    }
                }

                Text(bi(lang, "نوع فونداسیون:", "Foundation Type:"), style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FoundationType.entries.forEach { fn ->
                        FilterChip(selected = foundationType == fn, onClick = { foundationType = fn }, label = { Text(fn.title(lang)) })
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField(rooms, { rooms = it }, bi(lang, "اتاق‌ها", "Rooms"), Modifier.weight(1f))
                    NumField(baths, { baths = it }, bi(lang, "سرویس", "Baths"), Modifier.weight(1f))
                    NumField(kitchens, { kitchens = it }, bi(lang, "آشپزخانه", "Kitchens"), Modifier.weight(1f))
                }

                OutlinedTextField(
                    value = materialGrade, onValueChange = { materialGrade = it },
                    label = { Text(bi(lang, "نوع مصالح مصرفی (بتن C25، میلگرد AIII...)", "Material Specs Note")) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val lVal = landL.toDoubleOrNull() ?: 0.0
                    val wVal = landW.toDoubleOrNull() ?: 0.0
                    val aVal = landArea.toDoubleOrNull() ?: (lVal * wVal)
                    onSave(
                        initial.copy(
                            name = name.trim().ifBlank { bi(lang, "پروژه بدون نام", "Untitled Project") },
                            location = location.trim(),
                            buildingType = buildingType,
                            floorsCount = floors.toIntOrNull() ?: 0,
                            unitsCount = units.toIntOrNull() ?: 0,
                            landLengthM = lVal,
                            landWidthM = wVal,
                            landAreaM2 = aVal,
                            floorBuiltUpAreaM2 = floorArea.toDoubleOrNull() ?: 0.0,
                            floorHeightM = floorHeight.toDoubleOrNull() ?: 0.0,
                            frameType = frameType,
                            slabType = slabType,
                            wallType = wallType,
                            foundationType = foundationType,
                            wallThicknessCm = wallThick.toDoubleOrNull() ?: 0.0,
                            roomsCount = rooms.toIntOrNull() ?: 0,
                            bathroomsCount = baths.toIntOrNull() ?: 0,
                            kitchensCount = kitchens.toIntOrNull() ?: 0,
                            materialGradeNote = materialGrade.trim()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = EngineeringOrange),
                modifier = Modifier.testTag("save_project_confirm_btn")
            ) {
                Text(bi(lang, "ذخیره پروژه", "Save Project"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(bi(lang, "انصراف", "Cancel")) }
        }
    )
}

@Composable
private fun NumField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { ch -> ch.isDigit() || ch == '.' }) },
        label = { Text(label, maxLines = 1) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}
