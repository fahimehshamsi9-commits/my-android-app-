package com.example.engine

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

sealed class SciEvalResult {
    data class Success(val value: Double, val formatted: String) : SciEvalResult()
    data class Error(val messageFa: String, val messageEn: String) : SciEvalResult()
}

/**
 * Recursive-descent scientific expression parser supporting:
 * +, -, *, /, ^, %, parentheses (), functions sin, cos, tan, sqrt, log, ln, abs,
 * constants pi, e, and Degree/Radian trigonometric mode.
 */
object ScientificCalculatorEngine {
    fun evaluate(expression: String, useDegrees: Boolean = true): SciEvalResult {
        val cleaned = expression
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace("π", "pi")
            .replace("√", "sqrt")
            .replace(" ", "")
            .lowercase()

        if (cleaned.isBlank()) {
            return SciEvalResult.Error("عبارت خالی است.", "Expression is empty.")
        }

        return try {
            val parser = Parser(cleaned, useDegrees)
            val result = parser.parse()
            if (result.isNaN() || result.isInfinite()) {
                SciEvalResult.Error("خطای ریاضی (تقسیم بر صفر یا خارج از دامنه).", "Math error (division by zero or domain error).")
            } else {
                SciEvalResult.Success(result, UnitConverter.formatNumber(result, 6))
            }
        } catch (e: IllegalArgumentException) {
            SciEvalResult.Error(e.message ?: "خطای نحوی در عبارت.", e.message ?: "Syntax error.")
        }
    }

    private class Parser(private val str: String, private val useDegrees: Boolean) {
        private var pos = -1
        private var ch = 0

        fun parse(): Double {
            nextChar()
            val x = parseExpression()
            if (pos < str.length) {
                throw IllegalArgumentException("Unexpected character: '${ch.toChar()}'")
            }
            return x
        }

        private fun nextChar() {
            ch = if (++pos < str.length) str[pos].code else -1
        }

        private fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        private fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                when {
                    eat('+'.code) -> x += parseTerm()
                    eat('-'.code) -> x -= parseTerm()
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                when {
                    eat('*'.code) -> x *= parseFactor()
                    eat('/'.code) -> {
                        val divisor = parseFactor()
                        if (divisor == 0.0) throw IllegalArgumentException("Division by zero")
                        x /= divisor
                    }
                    eat('%'.code) -> {
                        // Treat as percentage of 1 if trailing or modulo? Standard engineering: % operator as /100 when unary or mod?
                        // If followed by number/expr, modulo; otherwise handled in factor!
                        val rhs = parseFactor()
                        if (rhs == 0.0) throw IllegalArgumentException("Division by zero")
                        x %= rhs
                    }
                    else -> return x
                }
            }
        }

        private fun parseFactor(): Double {
            var x = parseUnary()
            if (eat('^'.code)) {
                x = x.pow(parseFactor())
            }
            return x
        }

        private fun parseUnary(): Double {
            if (eat('+'.code)) return parseUnary()
            if (eat('-'.code)) return -parseUnary()
            return parsePrimary()
        }

        private fun parsePrimary(): Double {
            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseExpression()
                if (!eat(')'.code)) throw IllegalArgumentException("Missing ')'")
            } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                x = str.substring(startPos, pos).toDoubleOrNull()
                    ?: throw IllegalArgumentException("Invalid number")
            } else if (ch in 'a'.code..'z'.code) {
                while (ch in 'a'.code..'z'.code) nextChar()
                val ident = str.substring(startPos, pos)
                x = when (ident) {
                    "pi" -> PI
                    "e" -> Math.E
                    else -> {
                        val arg = if (eat('('.code)) {
                            val inner = parseExpression()
                            if (!eat(')'.code)) throw IllegalArgumentException("Missing ')' after $ident")
                            inner
                        } else {
                            parseUnary()
                        }
                        when (ident) {
                            "sqrt" -> {
                                if (arg < 0) throw IllegalArgumentException("Square root of negative")
                                sqrt(arg)
                            }
                            "sin" -> sin(if (useDegrees) Math.toRadians(arg) else arg)
                            "cos" -> cos(if (useDegrees) Math.toRadians(arg) else arg)
                            "tan" -> tan(if (useDegrees) Math.toRadians(arg) else arg)
                            "log" -> {
                                if (arg <= 0) throw IllegalArgumentException("Log domain error")
                                log10(arg)
                            }
                            "ln" -> {
                                if (arg <= 0) throw IllegalArgumentException("Ln domain error")
                                ln(arg)
                            }
                            "abs" -> kotlin.math.abs(arg)
                            else -> throw IllegalArgumentException("Unknown function: $ident")
                        }
                    }
                }
            } else {
                throw IllegalArgumentException("Unexpected token")
            }

            // Support postfix % (e.g. 15% = 0.15) when not followed by digit/paren
            while (ch == '%'.code && (pos + 1 >= str.length || (str[pos + 1] !in '0'..'9' && str[pos + 1] != '('))) {
                eat('%'.code)
                x /= 100.0
            }
            return x
        }
    }
}
