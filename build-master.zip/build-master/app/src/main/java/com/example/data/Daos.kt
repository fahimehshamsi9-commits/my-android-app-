package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.CalculationRecordEntity
import com.example.model.MaterialPriceEntity
import com.example.model.ProjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    suspend fun getAllProjectsSnapshot(): List<ProjectEntity>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)

    @Query("DELETE FROM projects")
    suspend fun clearAllProjects()
}

@Dao
interface CalculationDao {
    @Query("SELECT * FROM calculation_records ORDER BY createdAt DESC")
    fun getAllRecords(): Flow<List<CalculationRecordEntity>>

    @Query("SELECT * FROM calculation_records WHERE projectId = :projectId ORDER BY createdAt DESC")
    fun getRecordsByProject(projectId: Long): Flow<List<CalculationRecordEntity>>

    @Query("SELECT * FROM calculation_records ORDER BY createdAt DESC")
    suspend fun getAllRecordsSnapshot(): List<CalculationRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: CalculationRecordEntity): Long

    @Query("DELETE FROM calculation_records WHERE id = :id")
    suspend fun deleteRecordById(id: Long)

    @Query("DELETE FROM calculation_records WHERE projectId = :projectId")
    suspend fun deleteRecordsByProject(projectId: Long)

    @Query("DELETE FROM calculation_records")
    suspend fun clearAllRecords()
}

@Dao
interface MaterialPriceDao {
    @Query("SELECT * FROM material_prices ORDER BY categoryFa ASC, nameFa ASC")
    fun getAllPrices(): Flow<List<MaterialPriceEntity>>

    @Query("SELECT * FROM material_prices")
    suspend fun getAllPricesSnapshot(): List<MaterialPriceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<MaterialPriceEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: MaterialPriceEntity)

    @Query("DELETE FROM material_prices WHERE materialKey = :key")
    suspend fun deleteByKey(key: String)
}
