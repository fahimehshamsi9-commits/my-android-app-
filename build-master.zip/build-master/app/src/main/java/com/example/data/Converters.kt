package com.example.data

import androidx.room.TypeConverter
import com.example.model.BuildingType
import com.example.model.EngineeringUnit
import com.example.model.FoundationType
import com.example.model.FrameType
import com.example.model.SlabType
import com.example.model.WallType

class Converters {
    @TypeConverter fun fromBuildingType(v: BuildingType): String = v.name
    @TypeConverter fun toBuildingType(v: String): BuildingType =
        BuildingType.entries.firstOrNull { it.name == v } ?: BuildingType.RESIDENTIAL

    @TypeConverter fun fromFrameType(v: FrameType): String = v.name
    @TypeConverter fun toFrameType(v: String): FrameType =
        FrameType.entries.firstOrNull { it.name == v } ?: FrameType.CONCRETE

    @TypeConverter fun fromSlabType(v: SlabType): String = v.name
    @TypeConverter fun toSlabType(v: String): SlabType =
        SlabType.entries.firstOrNull { it.name == v } ?: SlabType.JOIST_BLOCK

    @TypeConverter fun fromWallType(v: WallType): String = v.name
    @TypeConverter fun toWallType(v: String): WallType =
        WallType.entries.firstOrNull { it.name == v } ?: WallType.BRICK

    @TypeConverter fun fromFoundationType(v: FoundationType): String = v.name
    @TypeConverter fun toFoundationType(v: String): FoundationType =
        FoundationType.entries.firstOrNull { it.name == v } ?: FoundationType.STRIP

    @TypeConverter fun fromEngineeringUnit(v: EngineeringUnit): String = v.name
    @TypeConverter fun toEngineeringUnit(v: String): EngineeringUnit =
        EngineeringUnit.entries.firstOrNull { it.name == v } ?: EngineeringUnit.PCS
}
