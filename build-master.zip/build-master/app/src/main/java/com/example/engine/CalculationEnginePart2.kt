package com.example.engine

import com.example.engine.CalcHelper.errorOutcome
import com.example.engine.CalcHelper.getMeters
import com.example.engine.CalcHelper.getRaw
import com.example.engine.CalcHelper.makeMaterial
import com.example.engine.CalcHelper.parseMaterialsFromJson
import com.example.engine.CalcHelper.standardEngineeringLimitations
import com.example.engine.UnitConverter.formatNumber
import com.example.engine.UnitConverter.roundTo
import com.example.model.EngineeringUnit
import kotlin.math.ceil

internal object CalculationEnginePart2 {

    fun execute(def: ToolDefinition, input: CalculationInput): CalculationOutcome {
        val cat = input.priceCatalog
        val (limFa, limEn) = standardEngineeringLimitations(def.isStructuralAdvisory)

        return when (def.id) {
            // ================= GROUP 5: FINISHING =================
            ToolId.GYPSUM_SOIL_PLASTER -> {
                val area = getRaw(input, "area", 120.0)
                val thickM = getMeters(input, "thickness", 0.02)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 8.0)
                val netKg = area * thickM * 1100.0
                val mat = makeMaterial("gypsum", "گچ و خاک (گچ زیرکار)", "Gypsum-Soil Plaster", netKg, waste, EngineeringUnit.KG, cat, 40.0, "کیسه ۴۰ کیلویی", "40 kg Bags")
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "وزن گچ و خاک (با پرت)", primaryLabelEn = "Undercoat Plaster (w/ waste)",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.KG,
                    secondaryMetrics = listOf(
                        ResultMetric("تعداد کیسه ۴۰ کیلویی", "40 kg Bags", mat.packageCount, EngineeringUnit.BAG),
                        ResultMetric("وزن خالص", "Net Weight", roundTo(netKg, 1), EngineeringUnit.KG)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("حجم لایه × چگالی خشک", "Area × Thickness × 1100", "${formatNumber(area)} × ${formatNumber(thickM,3)} × 1100", "${formatNumber(netKg)} kg"),
                        CalculationStep("با پرت و تبدیل به کیسه", "With waste & 40kg bags", "${formatNumber(mat.orderQuantity)} / 40", "${mat.packageCount.toInt()} bags")
                    ),
                    assumptionsFa = listOf("چگالی خشک گچ و خاک ۱۱۰۰ kg/m³ و کیسه ۴۰ کیلویی"),
                    assumptionsEn = listOf("Dry plaster density 1100 kg/m³, 40 kg bags"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.WHITE_PLASTER -> {
                val wallA = getRaw(input, "wallArea", 120.0)
                val ceilA = getRaw(input, "ceilingArea", 45.0)
                val totalA = wallA + ceilA
                if (totalA <= 0.0) return errorOutcome(def.id, "مجموع مساحت دیوار و سقف باید بزرگ‌تر از صفر باشد.", "Wall + Ceiling area must be > 0.")
                val thickM = getMeters(input, "thickness", 0.005)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 7.0)
                val netKg = totalA * thickM * 950.0
                val mat = makeMaterial("gypsum", "گچ سفیدکاری روکار", "White Finish Gypsum", netKg, waste, EngineeringUnit.KG, cat, 40.0, "کیسه ۴۰ کیلویی", "40 kg Bags")
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "گچ سفیدکاری (با پرت)", primaryLabelEn = "Finish Gypsum (w/ waste)",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.KG,
                    secondaryMetrics = listOf(
                        ResultMetric("تعداد کیسه ۴۰ کیلویی", "40 kg Bags", mat.packageCount, EngineeringUnit.BAG),
                        ResultMetric("مساحت کل زیر کار", "Total Area", roundTo(totalA, 2), EngineeringUnit.M2)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("مساحت کل", "Total area", "${formatNumber(wallA)} + ${formatNumber(ceilA)}", "${formatNumber(totalA)} m²"),
                        CalculationStep("مصرف گچ سفید", "Finish gypsum weight", "${formatNumber(totalA)} × ${formatNumber(thickM,4)} × 950", "${formatNumber(netKg)} kg")
                    ),
                    assumptionsFa = listOf("چگالی خشک گچ سفید ۹۵۰ kg/m³، ضخامت ${formatNumber(thickM*1000)} میلی‌متر"),
                    assumptionsEn = listOf("Dry finish gypsum 950 kg/m³, thickness ${formatNumber(thickM*1000)} mm"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.BUILDING_PAINT -> {
                val area = getRaw(input, "area", 180.0)
                val coats = getRaw(input, "coats", 2.0)
                val coverage = getRaw(input, "coverage", 10.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 5.0)
                val netLiters = (area * coats) / coverage
                val mat = makeMaterial("paint", "رنگ ساختمانی", "Building Paint", netLiters, waste, EngineeringUnit.LITER, cat, 10.0, "دبه ۱۰ لیتری", "10L Buckets")
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "مقدار رنگ موردنیاز (لیتر)", primaryLabelEn = "Paint Required (Liters)",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.LITER,
                    secondaryMetrics = listOf(
                        ResultMetric("مقدار خالص", "Net Paint", roundTo(netLiters, 2), EngineeringUnit.LITER),
                        ResultMetric("سطل ۱۰ لیتری", "10L Buckets", mat.packageCount, EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("مساحت × تعداد دست / پوشش", "Area × Coats / Coverage", "(${formatNumber(area)} × ${coats.toInt()}) / ${formatNumber(coverage)}", "${formatNumber(netLiters)} L"),
                        CalculationStep("با پرت ${formatNumber(waste)}%", "With waste", "${formatNumber(netLiters)} × (1+${waste/100.0})", "${formatNumber(mat.orderQuantity)} L")
                    ),
                    assumptionsFa = listOf("${coats.toInt()} دست رنگ با پوشش ${formatNumber(coverage)} m²/L و پرت ${formatNumber(waste)}%"),
                    assumptionsEn = listOf("${coats.toInt()} coats at ${formatNumber(coverage)} m²/L coverage and ${formatNumber(waste)}% waste"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.FLOOR_CERAMIC -> {
                val rL = getMeters(input, "roomLength", 10.0)
                val rW = getMeters(input, "roomWidth", 10.0)
                val tL = getMeters(input, "tileLength", 0.60)
                val tW = getMeters(input, "tileWidth", 0.60)
                val boxCov = getRaw(input, "boxCoverage", 1.44)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", input.tilePattern.recommendedWastePercent)
                val netArea = rL * rW
                val tileArea = tL * tW
                val mat = makeMaterial("ceramic", "سرامیک کف (${input.tilePattern.titleFa})", "Floor Ceramic (${input.tilePattern.titleEn})", netArea, waste, EngineeringUnit.M2, cat, boxCov, "کارتن", "Boxes")
                val tilesCount = ceil(mat.orderQuantity / tileArea)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "مقدار پیشنهادی خرید سرامیک", primaryLabelEn = "Recommended Ceramic Order",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.M2,
                    secondaryMetrics = listOf(
                        ResultMetric("مساحت خالص کف", "Net Floor Area", roundTo(netArea, 2), EngineeringUnit.M2),
                        ResultMetric("تعداد قطعه سرامیک", "Total Tile Pieces", tilesCount, EngineeringUnit.PCS),
                        ResultMetric("تعداد کارتن", "Total Boxes", mat.packageCount, EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("مساحت خالص کف", "Net floor area", "${formatNumber(rL)} × ${formatNumber(rW)}", "${formatNumber(netArea)} m²"),
                        CalculationStep("الگوی چیدمان و پرت (${formatNumber(waste)}%)", "Pattern & waste", "${input.tilePattern.titleEn}: +${formatNumber(waste)}%", "${formatNumber(mat.orderQuantity)} m²"),
                        CalculationStep("تعداد قطعه و کارتن", "Pieces & boxes", "${formatNumber(mat.orderQuantity)} / ${formatNumber(tileArea,3)}", "${tilesCount.toInt()} pcs | ${mat.packageCount.toInt()} boxes")
                    ),
                    assumptionsFa = listOf("الگوی چیدمان: ${input.tilePattern.titleFa}، ابعاد سرامیک ${formatNumber(tL*100)}×${formatNumber(tW*100)} cm، هر کارتن ${formatNumber(boxCov)} m²"),
                    assumptionsEn = listOf("Pattern: ${input.tilePattern.titleEn}, tile ${formatNumber(tL*100)}×${formatNumber(tW*100)} cm, ${formatNumber(boxCov)} m²/box"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.WALL_TILE -> {
                val netArea = getRaw(input, "netArea", 42.0)
                val tL = getMeters(input, "tileLength", 0.60)
                val tW = getMeters(input, "tileWidth", 0.30)
                val boxCov = getRaw(input, "boxCoverage", 1.26)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 10.0)
                val tileArea = tL * tW
                val matTile = makeMaterial("ceramic", "کاشی دیوار", "Wall Tiles", netArea, waste, EngineeringUnit.M2, cat, boxCov, "کارتن", "Boxes")
                val matAdhesive = makeMaterial("adhesive", "چسب کاشی", "Tile Adhesive", netArea * 4.5, 5.0, EngineeringUnit.KG, cat, 25.0, "کیسه ۲۵ کیلویی", "25 kg Bags")
                val mats = listOf(matTile, matAdhesive)
                val pieces = ceil(matTile.orderQuantity / tileArea)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "متراژ خرید کاشی دیوار", primaryLabelEn = "Wall Tile Order Area",
                    primaryValue = matTile.orderQuantity, primaryUnit = EngineeringUnit.M2,
                    secondaryMetrics = listOf(
                        ResultMetric("تعداد عدد کاشی", "Tile Pieces", pieces, EngineeringUnit.PCS),
                        ResultMetric("تعداد کارتن", "Boxes", matTile.packageCount, EngineeringUnit.PCS),
                        ResultMetric("چسب کاشی پیشنهادی", "Tile Adhesive", matAdhesive.orderQuantity, EngineeringUnit.KG)
                    ),
                    materials = mats,
                    steps = listOf(
                        CalculationStep("متراژ خرید با پرت", "Order area", "${formatNumber(netArea)} × (1+${waste/100.0})", "${formatNumber(matTile.orderQuantity)} m²"),
                        CalculationStep("تعداد کاشی و کارتن", "Pieces & boxes", "${pieces.toInt()} pcs", "${matTile.packageCount.toInt()} boxes")
                    ),
                    assumptionsFa = listOf("کاشی ${formatNumber(tL*100)}×${formatNumber(tW*100)} cm، مصرف تقریبی چسب ۴.۵ kg/m²"),
                    assumptionsEn = listOf("Tile ${formatNumber(tL*100)}×${formatNumber(tW*100)} cm, adhesive ~4.5 kg/m²"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mats.sumOf { it.totalCost }
                )
            }

            ToolId.FACADE_STONE -> {
                val area = getRaw(input, "facadeArea", 140.0)
                val sL = getMeters(input, "stoneLength", 0.80)
                val sW = getMeters(input, "stoneWidth", 0.40)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 12.0)
                val mat = makeMaterial("stone", "سنگ نما", "Facade Stone", area, waste, EngineeringUnit.M2, cat)
                val slabs = ceil(mat.orderQuantity / (sL * sW))
                val anchors = slabs * 2.0 // minimum 2 scoop/anchor pins per stone slab
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "متراژ سنگ نما (با پرت)", primaryLabelEn = "Facade Stone Order Area",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.M2,
                    secondaryMetrics = listOf(
                        ResultMetric("تعداد پلاک سنگ", "Stone Slabs", slabs, EngineeringUnit.PCS),
                        ResultMetric("تعداد اسکوپ مهار (۲ عدد/پلاک)", "Anchor Clips (2/slab)", anchors, EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("متراژ سفارش", "Order area", "${formatNumber(area)} × (1+${waste/100.0})", "${formatNumber(mat.orderQuantity)} m²"),
                        CalculationStep("تعداد پلاک و اسکوپ", "Slabs & anchors", "${slabs.toInt()} slabs", "${anchors.toInt()} anchor clips")
                    ),
                    assumptionsFa = listOf("ابعاد پلاک ${formatNumber(sL*100)}×${formatNumber(sW*100)} سانتی‌متر و ۲ اسکوپ برای هر پلاک مطابق مبحث پنجم"),
                    assumptionsEn = listOf("Slab ${formatNumber(sL*100)}×${formatNumber(sW*100)} cm, 2 safety anchors per slab"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.FLOOR_STONE -> {
                val area = getRaw(input, "floorArea", 85.0)
                val sL = getMeters(input, "stoneLength", 0.60)
                val sW = getMeters(input, "stoneWidth", 0.60)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 10.0)
                val mat = makeMaterial("stone", "سنگ کف", "Floor Stone", area, waste, EngineeringUnit.M2, cat)
                val pieces = ceil(mat.orderQuantity / (sL * sW))
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "متراژ سنگ کف (با پرت)", primaryLabelEn = "Floor Stone Order Area",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.M2,
                    secondaryMetrics = listOf(
                        ResultMetric("متراژ خالص", "Net Area", roundTo(area, 2), EngineeringUnit.M2),
                        ResultMetric("تعداد پلاک سنگ", "Stone Pieces", pieces, EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("مساحت کل با پرت", "Total with waste", "${formatNumber(area)} × (1+${waste/100.0})", "${formatNumber(mat.orderQuantity)} m²"),
                        CalculationStep("تعداد قطعه", "Piece count", "${formatNumber(mat.orderQuantity)} / ${formatNumber(sL*sW,3)}", "${pieces.toInt()} pcs")
                    ),
                    assumptionsFa = listOf("ابعاد سنگ ${formatNumber(sL*100)}×${formatNumber(sW*100)} سانتی‌متر، پرت ${formatNumber(waste)}%"),
                    assumptionsEn = listOf("Stone ${formatNumber(sL*100)}×${formatNumber(sW*100)} cm, ${formatNumber(waste)}% waste"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.SKIRTING_BASEBOARD -> {
                val perim = getMeters(input, "perimeter", 48.0)
                val doors = getMeters(input, "doorsTotalWidth", 4.5)
                val h = getMeters(input, "skirtingHeight", 0.10)
                val pieceL = getMeters(input, "pieceLength", 0.60)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 7.0)
                val netLen = perim - doors
                if (netLen <= 0.0) return errorOutcome(def.id, "مجموع عرض درها نمی‌تواند بزرگ‌تر یا مساوی محیط باشد.", "Doors width cannot exceed perimeter.")
                val orderLen = netLen * (1.0 + waste / 100.0)
                val areaM2 = orderLen * h
                val pieces = ceil(orderLen / pieceL)
                val mat = makeMaterial("stone", "قرنیز (متر طول/مساحت)", "Skirting Area", areaM2, 0.0, EngineeringUnit.M2, cat)
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "طول قرنیز موردنیاز (با پرت)", primaryLabelEn = "Skirting Linear Length",
                    primaryValue = roundTo(orderLen, 2), primaryUnit = EngineeringUnit.LM,
                    secondaryMetrics = listOf(
                        ResultMetric("طول خالص", "Net Length", roundTo(netLen, 2), EngineeringUnit.LM),
                        ResultMetric("مساحت معادل قرنیز", "Skirting Area", roundTo(areaM2, 2), EngineeringUnit.M2),
                        ResultMetric("تعداد قطعه قرنیز", "Skirting Pieces", pieces, EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("طول خالص با کسر درها", "Net length", "${formatNumber(perim)} - ${formatNumber(doors)}", "${formatNumber(netLen)} m"),
                        CalculationStep("طول سفارش و تعداد شاخه", "Order length & pieces", "${formatNumber(orderLen)} / ${formatNumber(pieceL,2)}", "${pieces.toInt()} pcs")
                    ),
                    assumptionsFa = listOf("ارتفاع قرنیز ${formatNumber(h*100)} سانتی‌متر و طول هر شاخه ${formatNumber(pieceL*100)} سانتی‌متر"),
                    assumptionsEn = listOf("Height ${formatNumber(h*100)} cm, piece length ${formatNumber(pieceL*100)} cm"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            // ================= GROUP 6: MEP & FIXTURES =================
            ToolId.PLUMBING_PIPES -> {
                val horiz = getMeters(input, "horizontalLength", 65.0)
                val vert = getMeters(input, "verticalLength", 24.0)
                val diamMm = getRaw(input, "diameterMm", 25.0)
                val fittings = getRaw(input, "fittingsCount", 34.0)
                val stockL = getMeters(input, "stockLength", 4.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 8.0)
                val netLen = horiz + vert
                val mat = makeMaterial("pipe", "لوله سایز ${diamMm.toInt()}mm", "Plumbing Pipe Ø${diamMm.toInt()}mm", netLen, waste, EngineeringUnit.LM, cat, stockL, "شاخه", "Stock Pipes")
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "طول کل لوله (با پرت)", primaryLabelEn = "Total Pipe Length",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.LM,
                    secondaryMetrics = listOf(
                        ResultMetric("طول خالص مسیر", "Net Route Length", roundTo(netLen, 2), EngineeringUnit.LM),
                        ResultMetric("تعداد شاخه لوله", "Stock Pipes Needed", mat.packageCount, EngineeringUnit.PCS),
                        ResultMetric("تعداد اتصالات ثبت‌شده", "Fittings Count", fittings, EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("طول خالص افقی و عمودی", "Horizontal + Vertical", "${formatNumber(horiz)} + ${formatNumber(vert)}", "${formatNumber(netLen)} m"),
                        CalculationStep("طول سفارش و تعداد شاخه", "Order length & stocks", "${formatNumber(mat.orderQuantity)} / ${formatNumber(stockL)}", "${mat.packageCount.toInt()} pipes")
                    ),
                    assumptionsFa = listOf("قطر ${diamMm.toInt()} میلی‌متر، شاخه استاندارد ${formatNumber(stockL)} متری، ${fittings.toInt()} عدد اتصال"),
                    assumptionsEn = listOf("Diameter ${diamMm.toInt()} mm, ${formatNumber(stockL)}m stock length, ${fittings.toInt()} fittings"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.ELECTRICAL_CABLES -> {
                val circuits = getRaw(input, "circuits", 12.0)
                val avgL = getMeters(input, "avgRouteLength", 18.0)
                val drop = getMeters(input, "dropAllowance", 3.5)
                val conductors = getRaw(input, "conductors", 3.0)
                val waste = input.wastePercentOverride ?: getRaw(input, "waste", 7.0)
                val netWire = circuits * (avgL + drop) * conductors
                val mat = makeMaterial("cable", "سیم و کابل برق", "Electrical Wire/Cable", netWire, waste, EngineeringUnit.LM, cat, 100.0, "حلقه ۱۰۰ متری", "100m Coils")
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "متراژ کل سیم موردنیاز", primaryLabelEn = "Total Wire Length",
                    primaryValue = mat.orderQuantity, primaryUnit = EngineeringUnit.LM,
                    secondaryMetrics = listOf(
                        ResultMetric("متراژ خالص", "Net Wire Length", roundTo(netWire, 1), EngineeringUnit.LM),
                        ResultMetric("تعداد حلقه ۱۰۰ متری", "100m Coils", mat.packageCount, EngineeringUnit.PCS)
                    ),
                    materials = listOf(mat),
                    steps = listOf(
                        CalculationStep("طول هر مدار با سرسیم", "Length per circuit", "${formatNumber(avgL)} + ${formatNumber(drop)}", "${formatNumber(avgL + drop)} m"),
                        CalculationStep("ضرب در مدار و رشته", "× Circuits × Conductors", "${circuits.toInt()} × ${formatNumber(avgL+drop)} × ${conductors.toInt()}", "${formatNumber(netWire)} m -> ${mat.packageCount.toInt()} coils")
                    ),
                    assumptionsFa = listOf("${circuits.toInt()} مدار، ${conductors.toInt()} رشته سیم در هر مدار، حلقه ۱۰۰ متری"),
                    assumptionsEn = listOf("${circuits.toInt()} circuits, ${conductors.toInt()} conductors/circuit, 100m coils"),
                    limitationsFa = limFa + "سایز مقطع سیم (۱.۵، ۲.۵، ۴ یا ۶) باید بر اساس محاسبه بار و افت ولتاژ مهندس برق تعیین شود.",
                    limitationsEn = limEn + "Conductor gauge (mm²) must be sized by a licensed electrical engineer for load and voltage drop.",
                    formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = mat.totalCost
                )
            }

            ToolId.SWITCHES_OUTLETS -> {
                val s1 = getRaw(input, "singleSwitches", 12.0)
                val s2 = getRaw(input, "doubleSwitches", 6.0)
                val pwr = getRaw(input, "powerOutlets", 28.0)
                val data = getRaw(input, "dataOutlets", 6.0)
                val spare = getRaw(input, "sparePercent", 5.0)
                val net = s1 + s2 + pwr + data
                if (net <= 0.0) return errorOutcome(def.id, "حداقل یک کلید یا پریز وارد کنید.", "Enter at least one switch or outlet.")
                val total = ceil(net * (1.0 + spare / 100.0))
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "مجموع کلید و پریز (با ذخیره)", primaryLabelEn = "Total Switches & Outlets",
                    primaryValue = total, primaryUnit = EngineeringUnit.PCS,
                    secondaryMetrics = listOf(
                        ResultMetric("مجموع کلیدها", "Total Switches", s1 + s2, EngineeringUnit.PCS),
                        ResultMetric("مجموع پریزها", "Total Outlets", pwr + data, EngineeringUnit.PCS),
                        ResultMetric("قوطی کلید و پریز موردنیاز", "Wall Back-boxes", total, EngineeringUnit.PCS)
                    ),
                    steps = listOf(
                        CalculationStep("جمع نقاط نقشه", "Sum plan points", "$s1 + $s2 + $pwr + $data", "${net.toInt()} pcs"),
                        CalculationStep("با درصد ذخیره ${formatNumber(spare)}%", "With spare", "${net.toInt()} × (1+${spare/100.0})", "${total.toInt()} pcs")
                    ),
                    assumptionsFa = listOf("تعداد بر اساس نقاط نقشه برق و ${formatNumber(spare)}% ذخیره"),
                    assumptionsEn = listOf("Based on registered plan points with ${formatNumber(spare)}% spare"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            ToolId.LIGHTING_FIXTURES -> {
                val m = getRaw(input, "mainLights", 10.0)
                val sp = getRaw(input, "spotLights", 24.0)
                val wl = getRaw(input, "wallLights", 8.0)
                val watt = getRaw(input, "avgWattage", 12.0)
                val spare = getRaw(input, "sparePercent", 5.0)
                val net = m + sp + wl
                if (net <= 0.0) return errorOutcome(def.id, "تعداد چراغ‌ها نمی‌تواند صفر باشد.", "Total lighting fixtures must be > 0.")
                val total = ceil(net * (1.0 + spare / 100.0))
                val totalWatt = net * watt
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "تعداد کل چراغ‌ها (با ذخیره)", primaryLabelEn = "Total Lighting Fixtures",
                    primaryValue = total, primaryUnit = EngineeringUnit.PCS,
                    secondaryMetrics = listOf(
                        ResultMetric("تعداد نقاط روشنایی خالص", "Net Lighting Points", net, EngineeringUnit.PCS),
                        ResultMetric("توان روشنایی کل (وات)", "Total Load (Watts)", roundTo(totalWatt, 1), EngineeringUnit.PCS)
                    ),
                    steps = listOf(
                        CalculationStep("جمع چراغ‌های نقشه", "Sum fixtures", "$m + $sp + $wl", "${net.toInt()} pcs"),
                        CalculationStep("محاسبه توان روشنایی", "Total connected wattage", "${net.toInt()} × ${formatNumber(watt)} W", "${formatNumber(totalWatt)} W")
                    ),
                    assumptionsFa = listOf("متوسط توان هر چراغ ${formatNumber(watt)} وات، ذخیره ${formatNumber(spare)}%"),
                    assumptionsEn = listOf("Avg ${formatNumber(watt)}W per fixture, ${formatNumber(spare)}% spare"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            ToolId.SANITARY_FIXTURES -> {
                val wc = getRaw(input, "toilets", 3.0)
                val van = getRaw(input, "vanities", 3.0)
                val sh = getRaw(input, "showers", 2.0)
                val fau = getRaw(input, "faucets", 8.0)
                val dr = getRaw(input, "drains", 5.0)
                val total = wc + van + sh + fau + dr
                if (total <= 0.0) return errorOutcome(def.id, "حداقل یک تجهیز بهداشتی ثبت کنید.", "Enter at least one sanitary fixture.")
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "مجموع اقلام تجهیزات بهداشتی", primaryLabelEn = "Total Sanitary Fixtures",
                    primaryValue = total, primaryUnit = EngineeringUnit.PCS,
                    secondaryMetrics = listOf(
                        ResultMetric("سرویس (توالت + روشویی + دوش)", "Major Fixtures", wc + van + sh, EngineeringUnit.PCS),
                        ResultMetric("شیرآلات و کف‌شور", "Faucets & Drains", fau + dr, EngineeringUnit.PCS)
                    ),
                    steps = listOf(
                        CalculationStep("تجمیع تجهیزات", "Sum sanitary items", "$wc + $van + $sh + $fau + $dr", "${total.toInt()} pcs")
                    ),
                    assumptionsFa = listOf("شامل ${wc.toInt()} توالت، ${van.toInt()} روشویی، ${sh.toInt()} دوش، ${fau.toInt()} شیرآلات، ${dr.toInt()} کف‌شور"),
                    assumptionsEn = listOf("${wc.toInt()} toilets, ${van.toInt()} vanities, ${sh.toInt()} showers, ${fau.toInt()} faucets, ${dr.toInt()} drains"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef
                )
            }

            // ================= GROUP 7: COST & BOQ =================
            ToolId.MATERIAL_COST -> {
                val transport = getRaw(input, "transportCost", 0.0)
                val contingencyPct = getRaw(input, "contingencyPercent", 5.0)
                val rows = input.costRows.ifEmpty {
                    // Build automatic default rows from price catalog if user didn't add custom rows yet
                    listOf(
                        DynamicCostRow(1, "cement", "سیمان (کیسه)", "Cement (bags)", 120.0, EngineeringUnit.BAG, cat["cement"]?.unitPrice ?: 0.0),
                        DynamicCostRow(2, "rebar", "میلگرد (کیلوگرم)", "Rebar (kg)", 4500.0, EngineeringUnit.KG, cat["rebar"]?.unitPrice ?: 0.0),
                        DynamicCostRow(3, "brick", "آجر (عدد)", "Bricks (pcs)", 12000.0, EngineeringUnit.PCS, cat["brick"]?.unitPrice ?: 0.0)
                    )
                }
                val materials = rows.map { r ->
                    val cost = r.quantity * r.unitPrice
                    MaterialEstimate(
                        materialKey = r.materialKey,
                        nameFa = r.nameFa,
                        nameEn = r.nameEn,
                        netQuantity = r.quantity,
                        wastePercent = 0.0,
                        orderQuantity = r.quantity,
                        unit = r.unit,
                        unitPrice = r.unitPrice,
                        totalCost = roundTo(cost, 0)
                    )
                }
                val subtotal = materials.sumOf { it.totalCost }
                val contingency = (subtotal + transport) * (contingencyPct / 100.0)
                val grandTotal = subtotal + transport + contingency
                CalculationOutcome(
                    toolId = def.id, isSuccess = true,
                    primaryLabelFa = "جمع کل هزینه مصالح", primaryLabelEn = "Total Material Cost",
                    primaryValue = roundTo(grandTotal, 0), primaryUnit = EngineeringUnit.PCS,
                    secondaryMetrics = listOf(
                        ResultMetric("جمع خالص مصالح", "Materials Subtotal", roundTo(subtotal, 0), EngineeringUnit.PCS),
                        ResultMetric("حمل و پیش‌بینی‌نشده", "Transport + Contingency", roundTo(transport + contingency, 0), EngineeringUnit.PCS)
                    ),
                    materials = materials,
                    steps = listOf(
                        CalculationStep("جمع ردیف‌های مصالح (${rows.size})", "Sum ${rows.size} material rows", "Σ (Qty × UnitPrice)", formatNumber(subtotal, 0)),
                        CalculationStep("اضافه حمل و ضریب احتیاط", "Add transport & contingency", "${formatNumber(subtotal,0)} + ${formatNumber(transport,0)} + ${formatNumber(contingency,0)}", formatNumber(grandTotal, 0))
                    ),
                    assumptionsFa = listOf("محاسبه بر اساس قیمت‌های ثبت‌شده دستی در بخش قیمت مصالح"),
                    assumptionsEn = listOf("Calculated strictly from manual unit prices in Material Price Catalog"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = roundTo(grandTotal, 0)
                )
            }

            ToolId.FINAL_PROJECT_BOQ -> {
                val laborPerM2 = getRaw(input, "laborCostPerM2", 3500000.0)
                val transport = getRaw(input, "transportCost", 45000000.0)
                val equipment = getRaw(input, "equipmentCost", 80000000.0)
                val contingencyPct = getRaw(input, "contingencyPercent", 10.0)
                val proj = input.project
                val records = input.savedProjectRecords
                val builtUp = proj?.effectiveTotalBuiltUpAreaM2 ?: 0.0
                val isPrelim = proj == null || builtUp <= 0.0 || records.isEmpty()

                // Aggregate material estimates by materialKey from all saved calculations
                val aggregated = linkedMapOf<String, MaterialEstimate>()
                records.forEach { rec ->
                    val mats = parseMaterialsFromJson(rec.payloadJson)
                    mats.forEach { m ->
                        val prev = aggregated[m.materialKey]
                        val unitPrice = cat[m.materialKey]?.unitPrice ?: m.unitPrice
                        val newNet = (prev?.netQuantity ?: 0.0) + m.netQuantity
                        val newOrder = (prev?.orderQuantity ?: 0.0) + m.orderQuantity
                        val newPkg = (prev?.packageCount ?: 0.0) + m.packageCount
                        val billable = if (m.materialKey == "cement" && m.unit == EngineeringUnit.KG) ceil(newOrder / 50.0) else newOrder
                        aggregated[m.materialKey] = m.copy(
                            netQuantity = roundTo(newNet, 2),
                            orderQuantity = roundTo(newOrder, 2),
                            packageCount = newPkg,
                            unitPrice = unitPrice,
                            totalCost = roundTo(billable * unitPrice, 0)
                        )
                    }
                }

                val matList = aggregated.values.toList()
                val matCost = matList.sumOf { it.totalCost }
                val laborCost = builtUp * laborPerM2
                val baseTotal = matCost + laborCost + transport + equipment
                val contingency = baseTotal * (contingencyPct / 100.0)
                val grandTotal = baseTotal + contingency

                CalculationOutcome(
                    toolId = def.id, isSuccess = true, isPreliminary = isPrelim,
                    preliminaryReasonFa = if (isPrelim) "پروژه انتخاب نشده، زیربنا کامل نیست یا هنوز محاسبات بخش‌ها ذخیره نشده‌اند." else null,
                    preliminaryReasonEn = if (isPrelim) "No project selected, built-up area missing, or no saved sub-calculations yet." else null,
                    primaryLabelFa = "برآورد هزینه کل پروژه", primaryLabelEn = "Grand Total Project Cost",
                    primaryValue = roundTo(grandTotal, 0), primaryUnit = EngineeringUnit.PCS,
                    secondaryMetrics = listOf(
                        ResultMetric("هزینه کل مصالح", "Materials Cost", roundTo(matCost, 0), EngineeringUnit.PCS),
                        ResultMetric("هزینه دستمزد (${formatNumber(builtUp)} m²)", "Labor Cost", roundTo(laborCost, 0), EngineeringUnit.PCS),
                        ResultMetric("حمل و تجهیزات", "Transport + Equipment", roundTo(transport + equipment, 0), EngineeringUnit.PCS),
                        ResultMetric("ذخیره احتیاط (${formatNumber(contingencyPct)}%)", "Contingency", roundTo(contingency, 0), EngineeringUnit.PCS)
                    ),
                    materials = matList,
                    steps = listOf(
                        CalculationStep("تجمیع ${records.size} محاسبه ثبت‌شده", "Aggregate ${records.size} saved records", "${matList.size} distinct materials", formatNumber(matCost, 0)),
                        CalculationStep("دستمزد بر اساس زیربنا", "Labor = Built-up × Rate", "${formatNumber(builtUp)} × ${formatNumber(laborPerM2,0)}", formatNumber(laborCost, 0)),
                        CalculationStep("جمع کل با حمل، تجهیزات و احتیاط", "Grand Total", "Base + ${formatNumber(contingencyPct)}%", formatNumber(grandTotal, 0))
                    ),
                    assumptionsFa = listOf("تجمیع ${records.size} رکورد پروژه، زیربنای کل ${formatNumber(builtUp)} m²، ضریب احتیاط ${formatNumber(contingencyPct)}%"),
                    assumptionsEn = listOf("Aggregated ${records.size} records, built-up ${formatNumber(builtUp)} m², contingency ${formatNumber(contingencyPct)}%"),
                    limitationsFa = limFa, limitationsEn = limEn, formulaUsed = def.formulaEn, standardRef = def.standardRef,
                    totalEstimatedCost = roundTo(grandTotal, 0)
                )
            }

            else -> errorOutcome(def.id, "ابزار نامعتبر", "Unsupported tool in part 2")
        }
    }
}
