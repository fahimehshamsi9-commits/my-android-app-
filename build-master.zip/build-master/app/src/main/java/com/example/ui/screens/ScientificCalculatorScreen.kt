package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.audio.SoundCue
import com.example.engine.SciEvalResult
import com.example.engine.ScientificCalculatorEngine
import com.example.engine.UnitConverter
import com.example.model.AppLanguage
import com.example.model.EngineeringUnit
import com.example.model.UnitDimension
import com.example.model.bi
import com.example.ui.components.EngineeringCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.VerifiedGreen

@Composable
fun ScientificCalculatorScreen(
    lang: AppLanguage,
    onPlayCue: (SoundCue) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableIntStateOf(0) }
    var expression by remember { mutableStateOf("") }
    var useDegrees by remember { mutableStateOf(true) }
    var resultText by remember { mutableStateOf("0") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var history by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }

    fun evaluate() {
        when (val res = ScientificCalculatorEngine.evaluate(expression, useDegrees)) {
            is SciEvalResult.Success -> {
                resultText = res.formatted
                errorText = null
                history = (listOf(expression to res.formatted) + history).take(15)
                onPlayCue(SoundCue.CALCULATE)
            }
            is SciEvalResult.Error -> {
                errorText = if (lang == AppLanguage.FA) res.messageFa else res.messageEn
                onPlayCue(SoundCue.CLICK)
            }
        }
    }

    Column(modifier = modifier.fillMaxSize().testTag("scientific_calculator_screen")) {
        TabRow(selectedTabIndex = activeTab) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text(bi(lang, "ماشین‌حساب علمی", "Scientific Calc")) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text(bi(lang, "تبدیل واحد مهندسی", "Unit Converter")) }
            )
        }

        if (activeTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    EngineeringCard(accentColor = ElectricBlue) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = useDegrees,
                                onClick = { useDegrees = !useDegrees },
                                label = { Text(if (useDegrees) "DEG" else "RAD") }
                            )
                            Text(
                                text = resultText,
                                style = MaterialTheme.typography.displayLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = VerifiedGreen,
                                textAlign = TextAlign.End
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = expression,
                            onValueChange = { expression = it },
                            label = { Text(bi(lang, "عبارت ریاضی (با پرانتز و توابع)", "Expression (e.g. 2*sin(30)+sqrt(144))")) },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                            modifier = Modifier.fillMaxWidth().testTag("sci_expression_input")
                        )
                        errorText?.let {
                            Spacer(Modifier.height(6.dp))
                            Text(it, color = AlertRed, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                item {
                    val rows = listOf(
                        listOf("sin(", "cos(", "tan(", "sqrt(", "C"),
                        listOf("log(", "ln(", "^", "(", ")"),
                        listOf("7", "8", "9", "/", "%"),
                        listOf("4", "5", "6", "*", "pi"),
                        listOf("1", "2", "3", "-", "DEL"),
                        listOf("0", ".", "e", "+", "=")
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        rows.forEach { row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                row.forEach { key ->
                                    val isEq = key == "="
                                    val isClear = key == "C" || key == "DEL"
                                    Button(
                                        onClick = {
                                            onPlayCue(SoundCue.CLICK)
                                            when (key) {
                                                "C" -> {
                                                    expression = ""
                                                    resultText = "0"
                                                    errorText = null
                                                }
                                                "DEL" -> if (expression.isNotEmpty()) expression = expression.dropLast(1)
                                                "=" -> evaluate()
                                                else -> expression += key
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = when {
                                                isEq -> EngineeringOrange
                                                isClear -> AlertRed.copy(alpha = 0.85f)
                                                key in listOf("+", "-", "*", "/", "^", "%") -> ElectricBlue.copy(alpha = 0.25f)
                                                else -> MaterialTheme.colorScheme.surfaceVariant
                                            },
                                            contentColor = if (isEq || isClear) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                        ),
                                        contentPadding = PaddingValues(vertical = 12.dp, horizontal = 4.dp),
                                        modifier = Modifier.weight(1f).testTag("sci_btn_$key")
                                    ) {
                                        Text(
                                            text = key,
                                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (history.isNotEmpty()) {
                    item {
                        Text(bi(lang, "تاریخچه ماشین‌حساب", "Calculation History"), style = MaterialTheme.typography.titleMedium)
                    }
                    items(history) { (expr, ans) ->
                        EngineeringCard(
                            onClick = { expression = expr },
                            accentColor = MaterialTheme.colorScheme.outline
                        ) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(expr, style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFontFamily))
                                Text("= $ans", style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFontFamily), color = VerifiedGreen)
                            }
                        }
                    }
                }
            }
        } else {
            UnitConverterPanel(lang = lang)
        }
    }
}

@Composable
private fun UnitConverterPanel(lang: AppLanguage) {
    var selectedDimension by remember { mutableStateOf(UnitDimension.LENGTH) }
    val units = remember(selectedDimension) { UnitConverter.unitsForDimension(selectedDimension) }
    var fromUnit by remember(selectedDimension) { mutableStateOf(units.first()) }
    var toUnit by remember(selectedDimension) { mutableStateOf(units.last()) }
    var inputStr by remember { mutableStateOf("10") }

    val inputVal = inputStr.toDoubleOrNull() ?: 0.0
    val converted = remember(inputVal, fromUnit, toUnit) {
        if (UnitConverter.canConvert(fromUnit, toUnit)) {
            UnitConverter.convert(inputVal, fromUnit, toUnit)
        } else 0.0
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        EngineeringCard(accentColor = ElectricBlue) {
            Text(bi(lang, "انتخاب کمیت:", "Dimension:"), style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    UnitDimension.LENGTH to bi(lang, "طول", "Length"),
                    UnitDimension.MASS to bi(lang, "جرم", "Mass"),
                    UnitDimension.AREA to bi(lang, "مساحت", "Area"),
                    UnitDimension.VOLUME to bi(lang, "حجم", "Volume")
                ).forEach { (dim, label) ->
                    FilterChip(
                        selected = selectedDimension == dim,
                        onClick = { selectedDimension = dim },
                        label = { Text(label) }
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = inputStr,
                onValueChange = { inputStr = it.filter { c -> c.isDigit() || c == '.' } },
                label = { Text(bi(lang, "مقدار ورودی", "Input Value")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                UnitPickerButton(
                    label = bi(lang, "از واحد", "From"),
                    selected = fromUnit,
                    options = units,
                    lang = lang,
                    onSelect = { fromUnit = it },
                    modifier = Modifier.weight(1f)
                )
                UnitPickerButton(
                    label = bi(lang, "به واحد", "To"),
                    selected = toUnit,
                    options = units,
                    lang = lang,
                    onSelect = { toUnit = it },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(16.dp))
            Text(
                text = "${UnitConverter.formatNumber(converted, 4)} ${toUnit.symbol(lang)}",
                style = MaterialTheme.typography.headlineMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                fontWeight = FontWeight.Bold,
                color = VerifiedGreen
            )
        }
    }
}

@Composable
private fun UnitPickerButton(
    label: String,
    selected: EngineeringUnit,
    options: List<EngineeringUnit>,
    lang: AppLanguage,
    onSelect: (EngineeringUnit) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier = modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${selected.symbol(lang)}")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { u ->
                DropdownMenuItem(
                    text = { Text("${u.symbolFa} (${u.symbolEn})") },
                    onClick = { onSelect(u); expanded = false }
                )
            }
        }
    }
}
