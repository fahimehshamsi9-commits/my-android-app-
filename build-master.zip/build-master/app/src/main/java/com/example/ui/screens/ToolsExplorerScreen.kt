package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.ToolCatalog
import com.example.engine.ToolGroup
import com.example.engine.ToolId
import com.example.model.AppLanguage
import com.example.model.bi
import com.example.ui.SidebarSection
import com.example.ui.components.EngineeringCard
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PreliminaryAmber

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ToolsExplorerScreen(
    section: SidebarSection,
    lang: AppLanguage,
    onOpenTool: (ToolId) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    var selectedGroup by remember(section) { mutableStateOf<ToolGroup?>(null) }

    val baseTools = remember(section) {
        val ids = section.filteredTools()
        if (ids.isEmpty()) ToolCatalog.allTools else ids.map { ToolCatalog.get(it) }
    }

    val filtered = remember(baseTools, query, selectedGroup) {
        baseTools.filter { def ->
            val matchesGroup = selectedGroup == null || def.id.group == selectedGroup
            val q = query.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                def.titleFa.lowercase().contains(q) ||
                def.titleEn.lowercase().contains(q) ||
                def.subtitleFa.lowercase().contains(q) ||
                def.subtitleEn.lowercase().contains(q)
            matchesGroup && matchesQuery
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("tools_explorer_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = section.title(lang),
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringOrange
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                label = { Text(bi(lang, "جستجو در بین ابزارهای مهندسی...", "Search engineering tools...")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("tools_search_input")
            )
        }

        if (section == SidebarSection.BOQ_ESTIMATION) {
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selectedGroup == null,
                        onClick = { selectedGroup = null },
                        label = { Text(bi(lang, "همه ۴۰ ابزار", "All 40 Tools")) }
                    )
                    ToolGroup.entries.forEach { g ->
                        FilterChip(
                            selected = selectedGroup == g,
                            onClick = { selectedGroup = g },
                            label = { Text(g.title(lang)) }
                        )
                    }
                }
            }
        }

        items(filtered, key = { it.id.name }) { def ->
            EngineeringCard(
                onClick = { onOpenTool(def.id) },
                accentColor = if (def.isStructuralAdvisory) PreliminaryAmber else ElectricBlue,
                modifier = Modifier.testTag("tool_card_${def.id.name}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = def.title(lang),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    if (def.isStructuralAdvisory) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = bi(lang, "نیازمند کنترل مهندس محاسب", "Structural check required"),
                            tint = PreliminaryAmber
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = def.subtitle(lang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${def.formula(lang)}  •  ${def.standardRef}",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = ElectricBlue
                )
            }
        }
    }
}
