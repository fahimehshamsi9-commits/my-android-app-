package com.example.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Architecture
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Plumbing
import androidx.compose.material.icons.filled.Roofing
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.PermanentDrawerSheet
import androidx.compose.material3.PermanentNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.SoundCue
import com.example.engine.ToolId
import com.example.export.ReportExporter
import com.example.model.AppLanguage
import com.example.model.UserSettings
import com.example.model.bi
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MaterialPricesScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.ScientificCalculatorScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.ToolCalculatorScreen
import com.example.ui.screens.ToolsExplorerScreen
import com.example.ui.theme.BuildMasterTheme
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuildMasterApp(
    viewModel: MainViewModel,
    skipSplashForTest: Boolean = false
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val calculations by viewModel.calculations.collectAsStateWithLifecycle()
    val prices by viewModel.materialPrices.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeProject.collectAsStateWithLifecycle()
    val dashboardSummary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val statusMsg by viewModel.statusMessage.collectAsStateWithLifecycle()

    var showSplash by remember { mutableStateOf(!skipSplashForTest) }
    var currentSection by remember { mutableStateOf(SidebarSection.DASHBOARD) }
    var activeToolId by remember { mutableStateOf<ToolId?>(null) }

    val lang = settings.language
    val layoutDirection = if (lang.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var pendingJsonExportProjectId by remember { mutableStateOf<Long?>(null) }

    val pdfExportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val projRecords = if (activeProject != null) {
                    calculations.filter { it.projectId == activeProject?.id || it.projectId == null }
                } else calculations
                val bytes = ReportExporter.generatePdfBytes(activeProject, projRecords, settings)
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                viewModel.playCue(SoundCue.REPORT_READY)
                viewModel.postStatus(bi(lang, "گزارش PDF با موفقیت ذخیره شد.", "PDF report saved successfully."))
            }
        }
    }

    val excelExportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.ms-excel")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val projRecords = if (activeProject != null) {
                    calculations.filter { it.projectId == activeProject?.id || it.projectId == null }
                } else calculations
                val xml = ReportExporter.generateExcelXml(activeProject, projRecords, settings)
                context.contentResolver.openOutputStream(uri)?.use { it.write(xml.toByteArray(Charsets.UTF_8)) }
                viewModel.playCue(SoundCue.REPORT_READY)
                viewModel.postStatus(bi(lang, "فایل اکسل (.xls) با موفقیت ذخیره شد.", "Excel (.xls) report saved."))
            }
        }
    }

    val jsonBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val json = viewModel.repository.exportBackupJson(pendingJsonExportProjectId)
                context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                viewModel.playCue(SoundCue.SAVE_PROJECT)
                viewModel.postStatus(bi(lang, "فایل پشتیبان JSON ذخیره شد.", "JSON backup exported."))
            }
        }
    }

    val jsonImportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
                    val count = viewModel.repository.importBackupJson(text)
                    viewModel.playCue(SoundCue.SAVE_PROJECT)
                    viewModel.postStatus(bi(lang, "$count پروژه با موفقیت وارد شد.", "Imported $count project(s) successfully."))
                } catch (e: Exception) {
                    viewModel.postStatus(bi(lang, "خطا در خواندن فایل JSON.", "Failed to import JSON: ${e.message}"))
                }
            }
        }
    }

    LaunchedEffect(statusMsg) {
        statusMsg?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    BuildMasterTheme(
        darkTheme = settings.darkTheme,
        fontChoice = settings.fontChoice,
        fontScale = settings.fontScale
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            if (showSplash) {
                SplashScreen(
                    lang = lang,
                    animationsEnabled = settings.animationsEnabled,
                    onFinished = { showSplash = false }
                )
            } else {
                // Handle back navigation when inside a specific tool or secondary section
                BackHandler(enabled = activeToolId != null || currentSection != SidebarSection.DASHBOARD) {
                    if (activeToolId != null) {
                        activeToolId = null
                    } else {
                        currentSection = SidebarSection.DASHBOARD
                    }
                }

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val isWideScreen = maxWidth >= 840.dp
                    val drawerState = rememberDrawerState(DrawerValue.Closed)

                    val selectSection: (SidebarSection) -> Unit = { sec ->
                        viewModel.playCue(SoundCue.CLICK)
                        activeToolId = null
                        currentSection = sec
                        if (!isWideScreen) scope.launch { drawerState.close() }
                    }

                    val drawerContent: @Composable () -> Unit = {
                        SidebarMenuContent(
                            currentSection = currentSection,
                            settings = settings,
                            activeProjectName = activeProject?.name,
                            onSelectSection = selectSection
                        )
                    }

                    val mainScaffold: @Composable () -> Unit = {
                        Scaffold(
                            contentWindowInsets = WindowInsets(0, 0, 0, 0),
                            snackbarHost = { SnackbarHost(snackbarHostState) },
                            topBar = {
                                TopAppBar(
                                    colors = TopAppBarDefaults.topAppBarColors(
                                        containerColor = MaterialTheme.colorScheme.surface
                                    ),
                                    navigationIcon = {
                                        if (!isWideScreen) {
                                            IconButton(
                                                onClick = {
                                                    viewModel.playCue(SoundCue.MENU_OPEN)
                                                    scope.launch { drawerState.open() }
                                                },
                                                modifier = Modifier.testTag("drawer_menu_btn")
                                            ) {
                                                Icon(Icons.Default.Menu, contentDescription = bi(lang, "منوی کناری", "Menu"))
                                            }
                                        }
                                    },
                                    title = {
                                        Column {
                                            Text(
                                                text = "BUILD MASTER",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = EngineeringOrange
                                            )
                                            Text(
                                                text = activeProject?.name ?: bi(lang, "بدون پروژه فعال", "No Active Project"),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = ElectricBlue
                                            )
                                        }
                                    },
                                    actions = {
                                        // Mute/Unmute button in top bar as requested
                                        IconButton(
                                            onClick = { viewModel.toggleSoundMute() },
                                            modifier = Modifier.testTag("top_sound_toggle")
                                        ) {
                                            Icon(
                                                imageVector = if (settings.soundEnabled) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                                                contentDescription = bi(lang, "قطع و وصل صدا", "Toggle Sound"),
                                                tint = if (settings.soundEnabled) ElectricBlue else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        // Quick Language Toggle
                                        IconButton(
                                            onClick = { viewModel.toggleLanguage() },
                                            modifier = Modifier.testTag("top_language_toggle")
                                        ) {
                                            Icon(Icons.Default.Translate, contentDescription = bi(lang, "تغییر زبان", "Switch Language"))
                                        }
                                    }
                                )
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                                    .navigationBarsPadding()
                            ) {
                                val toolId = activeToolId
                                if (toolId != null) {
                                    ToolCalculatorScreen(
                                        toolId = toolId,
                                        activeProject = activeProject,
                                        priceCatalog = prices,
                                        settings = settings,
                                        onRunCalculation = { id, input -> viewModel.runAndEvaluate(id, input) },
                                        onSaveOutcome = { out -> viewModel.saveCalculationOutcome(out) },
                                        onPlayCue = { cue -> viewModel.playCue(cue) },
                                        onBack = { activeToolId = null }
                                    )
                                } else {
                                    when (currentSection) {
                                        SidebarSection.DASHBOARD -> DashboardScreen(
                                            summary = dashboardSummary,
                                            activeProject = activeProject,
                                            settings = settings,
                                            onNavigateSection = selectSection,
                                            onOpenTool = { id ->
                                                viewModel.playCue(SoundCue.CLICK)
                                                activeToolId = id
                                            }
                                        )
                                        SidebarSection.PROJECTS -> ProjectsScreen(
                                            projects = projects,
                                            activeProjectId = activeProject?.id,
                                            lang = lang,
                                            onSelectProject = { id -> viewModel.selectActiveProject(id) },
                                            onSaveProject = { p -> viewModel.saveProject(p) },
                                            onDeleteProject = { id -> viewModel.deleteProject(id) },
                                            onExportProjectJson = { id ->
                                                pendingJsonExportProjectId = id
                                                jsonBackupLauncher.launch("build_master_project_$id.json")
                                            },
                                            onImportProjectJson = {
                                                jsonImportLauncher.launch(arrayOf("application/json", "*/*"))
                                            }
                                        )
                                        SidebarSection.COST_PRICING -> MaterialPricesScreen(
                                            prices = prices,
                                            settings = settings,
                                            onUpsertPrice = { p -> viewModel.upsertPrice(p) },
                                            onResetDefaultPrices = { viewModel.resetDefaultPrices() },
                                            onOpenCostTool = { id -> activeToolId = id }
                                        )
                                        SidebarSection.SCIENTIFIC_CALC -> ScientificCalculatorScreen(
                                            lang = lang,
                                            onPlayCue = { cue -> viewModel.playCue(cue) }
                                        )
                                        SidebarSection.REPORTS -> ReportsScreen(
                                            activeProject = activeProject,
                                            records = calculations,
                                            settings = settings,
                                            onExportPdf = {
                                                val name = activeProject?.name?.replace(" ", "_") ?: "Report"
                                                pdfExportLauncher.launch("BuildMaster_$name.pdf")
                                            },
                                            onExportExcel = {
                                                val name = activeProject?.name?.replace(" ", "_") ?: "Report"
                                                excelExportLauncher.launch("BuildMaster_$name.xls")
                                            },
                                            onSharePdf = {
                                                val projRecords = if (activeProject != null) {
                                                    calculations.filter { it.projectId == activeProject?.id || it.projectId == null }
                                                } else calculations
                                                val bytes = ReportExporter.generatePdfBytes(activeProject, projRecords, settings)
                                                val file = ReportExporter.writeTempCacheFile(context, "BuildMaster_Report.pdf", bytes)
                                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "application/pdf"
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, bi(lang, "اشتراک‌گذاری گزارش PDF", "Share PDF Report")))
                                            },
                                            onPrint = {
                                                val projRecords = if (activeProject != null) {
                                                    calculations.filter { it.projectId == activeProject?.id || it.projectId == null }
                                                } else calculations
                                                ReportExporter.printReport(context, activeProject, projRecords, settings)
                                            },
                                            onOpenFinalBoqTool = { id -> activeToolId = id },
                                            onDeleteRecord = { id -> viewModel.deleteCalculation(id) }
                                        )
                                        SidebarSection.SETTINGS -> SettingsScreen(
                                            settings = settings,
                                            onUpdateSettings = { t -> viewModel.updateSettings(t) },
                                            onExportFullBackup = {
                                                pendingJsonExportProjectId = null
                                                jsonBackupLauncher.launch("build_master_backup.json")
                                            },
                                            onImportFullBackup = {
                                                jsonImportLauncher.launch(arrayOf("application/json", "*/*"))
                                            },
                                            onClearAllData = { viewModel.clearAllData() }
                                        )
                                        else -> ToolsExplorerScreen(
                                            section = currentSection,
                                            lang = lang,
                                            onOpenTool = { id ->
                                                viewModel.playCue(SoundCue.CLICK)
                                                activeToolId = id
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (isWideScreen) {
                        PermanentNavigationDrawer(
                            drawerContent = {
                                PermanentDrawerSheet(modifier = Modifier.width(280.dp)) {
                                    drawerContent()
                                }
                            },
                            content = mainScaffold
                        )
                    } else {
                        ModalNavigationDrawer(
                            drawerState = drawerState,
                            drawerContent = {
                                ModalDrawerSheet(modifier = Modifier.width(290.dp)) {
                                    drawerContent()
                                }
                            },
                            content = mainScaffold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SidebarMenuContent(
    currentSection: SidebarSection,
    settings: UserSettings,
    activeProjectName: String?,
    onSelectSection: (SidebarSection) -> Unit
) {
    val lang = settings.language
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .navigationBarsPadding()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(18.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Construction, contentDescription = null, tint = EngineeringOrange, modifier = Modifier.size(28.dp))
                    Column {
                        Text("BUILD MASTER", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EngineeringOrange)
                        Text(bi(lang, "مستر ساختمان", "Engineering Estimator"), style = MaterialTheme.typography.labelMedium, color = ElectricBlue)
                    }
                }
                if (activeProjectName != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${bi(lang, "پروژه فعال:", "Active:")} $activeProjectName",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        HorizontalDivider()
        LazyColumn(modifier = Modifier.weight(1f).padding(vertical = 8.dp)) {
            items(SidebarSection.entries) { section ->
                NavigationDrawerItem(
                    selected = currentSection == section,
                    onClick = { onSelectSection(section) },
                    icon = { Icon(iconForSection(section), contentDescription = null) },
                    label = { Text(section.title(lang), maxLines = 1) },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = EngineeringOrange.copy(alpha = 0.16f),
                        selectedIconColor = EngineeringOrange,
                        selectedTextColor = EngineeringOrange
                    ),
                    modifier = Modifier
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                        .testTag("nav_${section.route}")
                )
            }
        }
        HorizontalDivider()
        Text(
            text = bi(lang, "طراحی و توسعه: قاسم غلامرضاپور", "By: Ghasem Gholamrezapour"),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(14.dp)
        )
    }
}

private fun iconForSection(section: SidebarSection): ImageVector = when (section) {
    SidebarSection.DASHBOARD -> Icons.Default.Dashboard
    SidebarSection.PROJECTS -> Icons.Default.Apartment
    SidebarSection.BOQ_ESTIMATION -> Icons.Default.Architecture
    SidebarSection.CONCRETE -> Icons.Default.Layers
    SidebarSection.REBAR -> Icons.Default.ViewColumn
    SidebarSection.MASONRY -> Icons.Default.GridView
    SidebarSection.SLAB_ROOF -> Icons.Default.Roofing
    SidebarSection.TILES_CERAMIC -> Icons.Default.Build
    SidebarSection.MEP -> Icons.Default.Plumbing
    SidebarSection.COST_PRICING -> Icons.Default.AttachMoney
    SidebarSection.EARTHWORK -> Icons.Default.Terrain
    SidebarSection.PAINT_PLASTER -> Icons.Default.FormatPaint
    SidebarSection.SCIENTIFIC_CALC -> Icons.Default.Calculate
    SidebarSection.REPORTS -> Icons.Default.Description
    SidebarSection.SETTINGS -> Icons.Default.Settings
}
