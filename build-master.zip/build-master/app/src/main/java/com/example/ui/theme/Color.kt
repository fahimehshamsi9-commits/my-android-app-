package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Engineering Palette
val DeepNavy = Color(0xFF0A1531)
val NavySurface = Color(0xFF0F1D3D)
val NavyCard = Color(0xFF162547)
val GraphiteDark = Color(0xFF1E293B)
val GraphiteSlate = Color(0xFF334155)
val GraphiteBorder = Color(0xFF3E4C63)

val EngineeringOrange = Color(0xFFF97316)
val EngineeringOrangeDark = Color(0xFFEA580C)
val EngineeringOrangeSoft = Color(0x33F97316)

val ElectricBlue = Color(0xFF38BDF8)
val ElectricBlueDark = Color(0xFF0284C7)
val ElectricBlueSoft = Color(0x2838BDF8)

val VerifiedGreen = Color(0xFF10B981)
val VerifiedGreenSoft = Color(0x2610B981)

val PreliminaryAmber = Color(0xFFF59E0B)
val PreliminaryAmberSoft = Color(0x26F59E0B)

val AlertRed = Color(0xFFEF4444)
val AlertRedSoft = Color(0x26EF4444)

// Light Architectural Blueprint Theme Colors
val DraftingPaper = Color(0xFFF4F7FB)
val CrispWhite = Color(0xFFFFFFFF)
val BlueprintSurfaceVariant = Color(0xFFE6EDF6)
val InkNavy = Color(0xFF0B132B)
val MutedSlate = Color(0xFF475569)
val LightBorder = Color(0xFFCBD5E1)
