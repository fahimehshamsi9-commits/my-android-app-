package com.example.engine

import com.example.model.EngineeringUnit

object ToolCatalog {
    val allTools: List<ToolDefinition> = listOf(
        // ================= GROUP 1: GENERAL =================
        ToolDefinition(
            id = ToolId.LAND_AREA,
            titleFa = "۱. محاسبه مساحت زمین",
            titleEn = "1. Land Area",
            subtitleFa = "محاسبه مساحت کل زمین بر اساس طول و عرض با ضریب شکل",
            subtitleEn = "Calculate total plot area from length, width & shape factor",
            formulaFa = "A = L × W × k",
            formulaEn = "A = L × W × k",
            standardRef = "هندسه مسطحه / نظام مهندسی",
            fields = listOf(
                InputFieldSpec("length", "طول زمین", "Land Length", 20.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("width", "عرض زمین", "Land Width", 12.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("shapeFactor", "ضریب اصلاح هندسی", "Shape Factor", 1.0, EngineeringUnit.PCS)
            )
        ),
        ToolDefinition(
            id = ToolId.BUILT_UP_AREA,
            titleFa = "۲. محاسبه زیربنای کل",
            titleEn = "2. Total Built-up Area",
            subtitleFa = "محاسبه مجموع زیربنای طبقات، همکف، زیرزمین و بالکن",
            subtitleEn = "Total gross floor area across floors plus mezzanine/balcony",
            formulaFa = "A_total = (N × A_floor) + A_extra",
            formulaEn = "A_total = (N × A_floor) + A_extra",
            standardRef = "مبحث سوم و چهارم مقررات ملی",
            fields = listOf(
                InputFieldSpec("floors", "تعداد طبقات", "Number of Floors", 4.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("floorArea", "زیربنای هر طبقه", "Area per Floor", 160.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("extraArea", "زیربنای مشاعات / بالکن", "Common / Balcony Area", 25.0, EngineeringUnit.M2, areaUnits, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.BUILDING_VOLUME,
            titleFa = "۳. محاسبه حجم ساختمان",
            titleEn = "3. Building Geometric Volume",
            subtitleFa = "حجم هندسی کل بنا بر اساس ابعاد پلان و ارتفاع کل",
            subtitleEn = "Gross building volume from plan dimensions and total height",
            formulaFa = "V = L × W × H",
            formulaEn = "V = L × W × H",
            standardRef = "هندسه فضایی / برآورد تأسیسات",
            fields = listOf(
                InputFieldSpec("length", "طول بنا", "Building Length", 16.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("width", "عرض بنا", "Building Width", 10.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("height", "ارتفاع کل ساختمان", "Total Height", 13.5, EngineeringUnit.M, lengthUnits)
            )
        ),
        ToolDefinition(
            id = ToolId.TOTAL_CONCRETE_VOLUME,
            titleFa = "۴. محاسبه حجم بتن کلی",
            titleEn = "4. Total Concrete Volume",
            subtitleFa = "تجمیع حجم بتن فونداسیون، ستون، تیر، سقف و راه‌پله با ضریب پرت",
            subtitleEn = "Aggregate concrete volume across structural members + waste",
            formulaFa = "V_total = (V_f + V_c + V_b + V_s + V_st) × (1 + w%)",
            formulaEn = "V_total = (V_f + V_c + V_b + V_s + V_st) × (1 + w%)",
            standardRef = "نشریه ۵۵ / مبحث نهم مقررات ملی",
            fields = listOf(
                InputFieldSpec("foundation", "بتن فونداسیون", "Foundation Concrete", 32.0, EngineeringUnit.M3, volumeUnits, allowZero = true),
                InputFieldSpec("columns", "بتن ستون‌ها", "Columns Concrete", 18.0, EngineeringUnit.M3, volumeUnits, allowZero = true),
                InputFieldSpec("beams", "بتن تیرها", "Beams Concrete", 22.0, EngineeringUnit.M3, volumeUnits, allowZero = true),
                InputFieldSpec("slabs", "بتن سقف‌ها", "Slabs Concrete", 48.0, EngineeringUnit.M3, volumeUnits, allowZero = true),
                InputFieldSpec("stairs", "بتن راه‌پله", "Staircase Concrete", 6.0, EngineeringUnit.M3, volumeUnits, allowZero = true),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste Factor (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.EXCAVATION_VOLUME,
            titleFa = "۵. محاسبه حجم خاکبرداری",
            titleEn = "5. Excavation Volume",
            subtitleFa = "محاسبه حجم گودبرداری برجا و حجم خاک حمل‌شونده با ضریب تورم",
            subtitleEn = "Bank excavation volume and loose haulage volume with swell factor",
            formulaFa = "V_bank = (L + 2a) × (W + 2a) × D , V_loose = V_bank × S",
            formulaEn = "V_bank = (L + 2a) × (W + 2a) × D , V_loose = V_bank × S",
            standardRef = "نشریه ۵۵ / فهرست بهای ابنیه",
            fields = listOf(
                InputFieldSpec("length", "طول گود", "Excavation Length", 20.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("width", "عرض گود", "Excavation Width", 12.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("depth", "عمق گودبرداری", "Excavation Depth", 3.2, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("overcut", "فضای کار پیرامونی (هر طرف)", "Working Space Allowance", 0.3, EngineeringUnit.M, lengthUnits, allowZero = true),
                InputFieldSpec("swell", "ضریب تورم خاک", "Soil Swell Factor", 1.25, EngineeringUnit.PCS)
            )
        ),
        ToolDefinition(
            id = ToolId.BACKFILL_VOLUME,
            titleFa = "۶. محاسبه حجم خاکریزی",
            titleEn = "6. Backfill Volume",
            subtitleFa = "محاسبه خاک موردنیاز با اعمال ضریب تراکم و تورم خاک",
            subtitleEn = "Required borrow soil considering compaction and swell factors",
            formulaFa = "V_borrow = V_compacted × C_comp × S_swell",
            formulaEn = "V_borrow = V_compacted × C_comp × S_swell",
            standardRef = "نشریه ۵۵ / مکانیک خاک",
            fields = listOf(
                InputFieldSpec("length", "طول محل خاکریزی", "Fill Length", 18.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("width", "عرض محل خاکریزی", "Fill Width", 10.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("depth", "ضخامت/عمق خاکریزی", "Fill Depth", 0.8, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("compactionFactor", "ضریب تراکم (Shrinkage/Compaction)", "Compaction Factor", 1.15, EngineeringUnit.PCS),
                InputFieldSpec("swellFactor", "ضریب تورم حمل", "Haul Swell Factor", 1.20, EngineeringUnit.PCS)
            )
        ),

        // ================= GROUP 2: CONCRETE & MATERIALS =================
        ToolDefinition(
            id = ToolId.FOUNDATION_CONCRETE,
            titleFa = "۷. محاسبه بتن فونداسیون",
            titleEn = "7. Foundation Concrete",
            subtitleFa = "محاسبه حجم بتن فونداسیون و بتن نظافت (مگر) برای مقاطع پی",
            subtitleEn = "Structural footing concrete plus lean blinding concrete",
            formulaFa = "V = n × L × W × H , V_lean = n × (L+0.2) × (W+0.2) × t_lean",
            formulaEn = "V = n × L × W × H , V_lean = n × (L+0.2) × (W+0.2) × t_lean",
            standardRef = "مبحث نهم مقررات ملی / ACI 318",
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("count", "تعداد بخش/نوار پی", "Footing Segments Count", 6.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("length", "طول هر بخش", "Segment Length", 12.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("width", "عرض پی", "Footing Width", 1.2, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("height", "ارتفاع/ضخامت پی", "Footing Depth", 0.65, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("leanThickness", "ضخامت بتن مگر", "Lean Concrete Thickness", 0.1, EngineeringUnit.M, lengthUnits, allowZero = true),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.COLUMN_CONCRETE,
            titleFa = "۸. محاسبه بتن ستون",
            titleEn = "8. Column Concrete",
            subtitleFa = "حجم بتن ستون‌ها بر اساس تعداد، ابعاد مقطع و ارتفاع خالص",
            subtitleEn = "Column concrete volume from count, section dimensions & height",
            formulaFa = "V = N × b × h × H × (1 + w%)",
            formulaEn = "V = N × b × h × H × (1 + w%)",
            standardRef = "مبحث نهم مقررات ملی / ACI 318",
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("count", "تعداد ستون‌ها", "Column Count", 16.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("width", "عرض مقطع ستون", "Column Width", 45.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("depth", "طول مقطع ستون", "Column Depth", 45.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("height", "ارتفاع ستون", "Column Height", 3.2, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 4.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.BEAM_CONCRETE,
            titleFa = "۹. محاسبه بتن تیر",
            titleEn = "9. Beam Concrete",
            subtitleFa = "حجم بتن تیرهای اصلی و فرعی بر اساس طول و ابعاد مقطع",
            subtitleEn = "Beam concrete volume from count, span length & cross section",
            formulaFa = "V = N × L × b × h × (1 + w%)",
            formulaEn = "V = N × L × b × h × (1 + w%)",
            standardRef = "مبحث نهم مقررات ملی / ACI 318",
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("count", "تعداد تیرها", "Beam Count", 14.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("length", "طول هر تیر", "Beam Length", 5.5, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("width", "عرض تیر", "Beam Width", 35.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("depth", "ارتفاع تیر", "Beam Depth", 45.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 4.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.SLAB_CONCRETE,
            titleFa = "۱۰. محاسبه بتن سقف",
            titleEn = "10. Slab / Roof Concrete",
            subtitleFa = "حجم بتن دال یا دال فوقانی تیرچه‌بلوک بر اساس مساحت و ضخامت معادل",
            subtitleEn = "Slab concrete from area, effective concrete thickness & floors",
            formulaFa = "V = A × t_eff × N_floors × (1 + w%)",
            formulaEn = "V = A × t_eff × N_floors × (1 + w%)",
            standardRef = "مبحث نهم / نشریه ۵۵",
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("area", "مساحت هر سقف", "Slab Area", 160.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("thickness", "ضخامت معادل بتن سقف", "Effective Concrete Thickness", 11.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("floors", "تعداد سقف‌ها", "Number of Slabs", 1.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.STAIRCASE_CONCRETE,
            titleFa = "۱۱. محاسبه بتن راه‌پله",
            titleEn = "11. Staircase Concrete",
            subtitleFa = "محاسبه دقیق بتن کمرپله، پله‌ها (تک‌تک مثلث‌ها) و پاگرد",
            subtitleEn = "Exact stair waist slab, triangular steps & landing concrete",
            formulaFa = "V = N_f × [W × L_slope × t_waist + n_s × (0.5×R×T×W)] + V_landing",
            formulaEn = "V = N_f × [W × L_slope × t_waist + n_s × (0.5×R×T×W)] + V_landing",
            standardRef = "مبحث نهم مقررات ملی",
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("flights", "تعداد بازوهای پله", "Number of Flights", 2.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("width", "عرض پله", "Stair Width", 1.2, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("stepsPerFlight", "تعداد پله در هر بازو", "Steps per Flight", 9.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("riser", "ارتفاع خیز پله (Riser)", "Step Riser", 18.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("tread", "عرض کف پله (Tread)", "Step Tread", 30.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("waistThickness", "ضخامت دال شیب‌دار کمرپله", "Waist Slab Thickness", 15.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("landingArea", "مساحت کل پاگردها", "Total Landing Area", 3.6, EngineeringUnit.M2, areaUnits, allowZero = true),
                InputFieldSpec("landingThickness", "ضخامت دال پاگرد", "Landing Thickness", 15.0, EngineeringUnit.CM, lengthUnits, allowZero = true),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.CONCRETE_MIX_MATERIALS,
            titleFa = "۱۲. محاسبه سیمان، ماسه و شن",
            titleEn = "12. Cement, Sand & Gravel",
            subtitleFa = "محاسبه دقیق اجزای بتن بر اساس طرح اختلاط انتخابی (بدون نسبت ثابت عمومی)",
            subtitleEn = "Mix ingredients by explicit mix grade/ratio & dry volume factor",
            formulaFa = "V_dry = V_wet × 1.54 ; Qty_i = (Part_i / ΣParts) × V_dry × ρ_i",
            formulaEn = "V_dry = V_wet × 1.54 ; Qty_i = (Part_i / ΣParts) × V_dry × ρ_i",
            standardRef = "ACI 211.1 / مبحث نهم مقررات ملی",
            supportsMixGrade = true,
            fields = listOf(
                InputFieldSpec("volume", "حجم بتن خیس", "Wet Concrete Volume", 25.0, EngineeringUnit.M3, volumeUnits),
                InputFieldSpec("dryFactor", "ضریب تبدیل حجم خیس به خشک", "Dry-to-Wet Factor", 1.54, EngineeringUnit.PCS),
                InputFieldSpec("waste", "ضریب پرت مصالح (%)", "Material Waste (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.MORTAR_MATERIALS,
            titleFa = "۱۳. محاسبه ملات ساختمانی",
            titleEn = "13. Building Mortar Materials",
            subtitleFa = "محاسبه سیمان و ماسه برای ملات ماسه‌سیمان بر اساس نسبت اختلاط",
            subtitleEn = "Cement bags and sand volume for cement-sand mortar ratio",
            formulaFa = "V_dry = V_wet × 1.33 ; Cement = (1/(1+n))×V_dry×1440 kg",
            formulaEn = "V_dry = V_wet × 1.33 ; Cement = (1/(1+n))×V_dry×1440 kg",
            standardRef = "نشریه ۵۵ / ASTM C270",
            fields = listOf(
                InputFieldSpec("volume", "حجم ملات خیس", "Wet Mortar Volume", 4.5, EngineeringUnit.M3, volumeUnits),
                InputFieldSpec("sandRatio", "نسبت ماسه به ۱ قسمت سیمان (مثلاً ۴ یا ۵)", "Sand Ratio (1 : N)", 4.0, EngineeringUnit.PCS),
                InputFieldSpec("dryFactor", "ضریب حجم خشک ملات", "Dry Volume Factor", 1.33, EngineeringUnit.PCS),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.CONCRETE_WEIGHT,
            titleFa = "۱۴. محاسبه وزن بتن",
            titleEn = "14. Concrete Weight",
            subtitleFa = "محاسبه وزن کل بتن مسلح، غیرمسلح یا سبک بر اساس چگالی",
            subtitleEn = "Total mass of concrete from volume and selected density",
            formulaFa = "W = V × ρ",
            formulaEn = "W = V × ρ",
            standardRef = "مبحث ششم مقررات ملی (بارگذاری)",
            fields = listOf(
                InputFieldSpec("volume", "حجم بتن", "Concrete Volume", 20.0, EngineeringUnit.M3, volumeUnits),
                InputFieldSpec("density", "چگالی بتن (مسلح ۲۵۰۰، معمولی ۲۴۰۰ kg/m³)", "Concrete Density (kg/m³)", 2500.0, EngineeringUnit.KG)
            )
        ),

        // ================= GROUP 3: STEEL & REBAR =================
        ToolDefinition(
            id = ToolId.REBAR_WEIGHT,
            titleFa = "۱۵. محاسبه وزن میلگرد",
            titleEn = "15. Rebar Weight",
            subtitleFa = "محاسبه وزن استاندارد میلگرد با فرمول d² / 162 و تعداد شاخه ۱۲ متری",
            subtitleEn = "Theoretical rebar weight via d²/162 formula & 12m stock bars",
            formulaFa = "w/m = d² / 162  |  W_total = (d² / 162) × L × N",
            formulaEn = "w/m = d² / 162  |  W_total = (d² / 162) × L × N",
            standardRef = "ISIRI 3132 / ASTM A615 (فقط متره)",
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("diameter", "قطر میلگرد (میلی‌متر)", "Rebar Diameter (mm)", 16.0, EngineeringUnit.MM, lengthUnits),
                InputFieldSpec("length", "طول هر شاخه/قطعه", "Length per Piece", 12.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("count", "تعداد", "Quantity (Pieces)", 50.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("waste", "ضریب پرت برش/اورلپ (%)", "Waste/Lap (%)", 3.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.CUT_REBAR_LIST,
            titleFa = "۱۶. محاسبه وزن میلگردهای برش‌خورده",
            titleEn = "16. Cut Rebar Bar-Bending List",
            subtitleFa = "ثبت لیست چندتایی قطعات برش‌خورده با قطر، طول و تعداد متفاوت",
            subtitleEn = "Multi-row bar schedule with diameter, cut length and count",
            formulaFa = "W_total = Σ [(d_i² / 162) × L_i × N_i]",
            formulaEn = "W_total = Σ [(d_i² / 162) × L_i × N_i]",
            standardRef = "ISIRI 3132 / ACI 315 (فقط متره)",
            supportsCutRebarList = true,
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("waste", "ضریب پرت برشکاری (%)", "Cutting Waste (%)", 4.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.STEEL_PROFILE_WEIGHT,
            titleFa = "۱۷. محاسبه وزن پروفیل فولادی",
            titleEn = "17. Steel Profile Weight",
            subtitleFa = "محاسبه وزن قوطی، نبشی و ناودانی بر اساس جدول معتبر استاندارد",
            subtitleEn = "Hollow section, angle & channel weight from EN/DIN table",
            formulaFa = "W = w_table(kg/m) × L × N",
            formulaEn = "W = w_table(kg/m) × L × N",
            standardRef = "EN 10219 / DIN 1026 (فقط متره)",
            supportsProfilePicker = true,
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("length", "طول هر شاخه", "Length per Piece", 6.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("count", "تعداد شاخه", "Number of Pieces", 20.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 2.5, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.IBEAM_WEIGHT,
            titleFa = "۱۸. محاسبه وزن تیرآهن",
            titleEn = "18. I-Beam Steel Weight",
            subtitleFa = "محاسبه وزن تیرآهن IPE، هاش IPB/HEB و INP از جدول استاندارد",
            subtitleEn = "Standard IPE / HEB / INP beam mass from DIN 1025 table",
            formulaFa = "W = w_DIN(kg/m) × L × N",
            formulaEn = "W = w_DIN(kg/m) × L × N",
            standardRef = "DIN 1025 / ISIRI 1791 (فقط متره)",
            supportsIBeamPicker = true,
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("length", "طول هر تیرآهن", "Beam Length", 12.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("count", "تعداد تیرآهن", "Count", 8.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 2.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.STEEL_PLATE_WEIGHT,
            titleFa = "۱۹. محاسبه وزن ورق فولادی",
            titleEn = "19. Steel Plate Weight",
            subtitleFa = "محاسبه وزن ورق‌های بیس‌پلیت، سخت‌کننده و ورق عرشه با چگالی فولاد",
            subtitleEn = "Steel plate mass from length, width, thickness & density",
            formulaFa = "W = L × W × t × ρ_steel × N",
            formulaEn = "W = L × W × t × ρ_steel × N",
            standardRef = "DIN EN 10029 / مبحث دهم",
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("length", "طول ورق", "Plate Length", 2.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("width", "عرض ورق", "Plate Width", 1.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("thickness", "ضخامت ورق", "Thickness", 10.0, EngineeringUnit.MM, lengthUnits),
                InputFieldSpec("count", "تعداد ورق", "Count", 4.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("density", "چگالی فولاد (پیش‌فرض ۷۸۵۰)", "Steel Density (kg/m³)", 7850.0, EngineeringUnit.KG)
            )
        ),
        ToolDefinition(
            id = ToolId.TOTAL_PROJECT_STEEL,
            titleFa = "۲۰. مجموع فولاد مصرفی پروژه",
            titleEn = "20. Total Project Steel Summary",
            subtitleFa = "تجمیع خودکار وزن میلگردها، تیرآهن و پروفیل‌های ثبت‌شده در پروژه فعال",
            subtitleEn = "Aggregates all steel & rebar items saved in active project",
            formulaFa = "W_project = Σ W_rebar + Σ W_beams + Σ W_profiles + Σ W_plates",
            formulaEn = "W_project = Σ W_rebar + Σ W_beams + Σ W_profiles + Σ W_plates",
            standardRef = "فهرست مصالح پروژه (BOQ)",
            isStructuralAdvisory = true,
            fields = listOf(
                InputFieldSpec("extraSteelKg", "مقدار فولاد تکمیلی دستی (اختیاری)", "Additional Manual Steel (kg)", 0.0, EngineeringUnit.KG, massUnits, allowZero = true)
            )
        ),

        // ================= GROUP 4: MASONRY & WALLS =================
        ToolDefinition(
            id = ToolId.BRICK_COUNT,
            titleFa = "۲۱. محاسبه تعداد آجر",
            titleEn = "21. Brick Quantity",
            subtitleFa = "تعداد آجر دیوار با ابعاد آجر، ضخامت بند ملات و مساحت خالص دیوار",
            subtitleEn = "Brick count per wall area considering mortar joint & wythes",
            formulaFa = "N_m2 = (1 / ((L_b + j) × (H_b + j))) × Wythes ; N = A × N_m2 × (1+w%)",
            formulaEn = "N_m2 = (1 / ((L_b + j) × (H_b + j))) × Wythes ; N = A × N_m2 × (1+w%)",
            standardRef = "نشریه ۵۵ / آیین‌نامه بنایی",
            fields = listOf(
                InputFieldSpec("wallArea", "مساحت خالص دیوار", "Net Wall Area", 45.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("brickLength", "طول آجر", "Brick Length", 21.5, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("brickHeight", "ارتفاع آجر", "Brick Height", 5.5, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("jointThickness", "ضخامت بند ملات", "Mortar Joint", 1.2, EngineeringUnit.CM, lengthUnits, allowZero = true),
                InputFieldSpec("wythes", "ضریب ضخامت (۱=دیوار ۱۰، ۲=دیوار ۲۰)", "Wythe / Layer Factor", 1.0, EngineeringUnit.PCS),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.CEMENT_BLOCK_COUNT,
            titleFa = "۲۲. محاسبه تعداد بلوک سیمانی",
            titleEn = "22. Cement Block Quantity",
            subtitleFa = "تعداد بلوک سیمانی با کسر بازشوها و احتساب ضخامت بند ملات",
            subtitleEn = "Hollow cement blocks from wall L×H minus openings & joints",
            formulaFa = "A_net = (L×H) - A_open ; N = A_net / ((L_blk+j)×(H_blk+j))",
            formulaEn = "A_net = (L×H) - A_open ; N = A_net / ((L_blk+j)×(H_blk+j))",
            standardRef = "ASTM C90 / نشریه ۵۵",
            fields = listOf(
                InputFieldSpec("wallLength", "طول کل دیوار", "Wall Length", 14.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("wallHeight", "ارتفاع دیوار", "Wall Height", 3.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("openingsArea", "مساحت بازشوها (در و پنجره)", "Openings Area", 4.5, EngineeringUnit.M2, areaUnits, allowZero = true),
                InputFieldSpec("blockLength", "طول بلوک", "Block Length", 40.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("blockHeight", "ارتفاع بلوک", "Block Height", 20.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("jointThickness", "ضخامت بند ملات", "Mortar Joint", 1.5, EngineeringUnit.CM, lengthUnits, allowZero = true),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.AAC_HEBELX_BLOCK_COUNT,
            titleFa = "۲۳. محاسبه تعداد بلوک هبلکس (AAC)",
            titleEn = "23. AAC / Hebelx Block Quantity",
            subtitleFa = "تعداد بلوک سبک هبلکس به همراه چسب مخصوص نازک‌بند",
            subtitleEn = "Autoclaved aerated concrete blocks & thin-bed adhesive kg",
            formulaFa = "N = A_net / ((L_aac+0.003) × (H_aac+0.003)) × (1+w%)",
            formulaEn = "N = A_net / ((L_aac+0.003) × (H_aac+0.003)) × (1+w%)",
            standardRef = "EN 771-4 / استاندارد ۸۵۹۳",
            fields = listOf(
                InputFieldSpec("wallArea", "مساحت خالص دیوار", "Net Wall Area", 50.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("blockLength", "طول بلوک هبلکس", "AAC Length", 60.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("blockHeight", "ارتفاع بلوک هبلکس", "AAC Height", 25.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("blockThickness", "ضخامت بلوک (عرض دیوار)", "AAC Thickness", 15.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 4.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.MASONRY_MORTAR_VOLUME,
            titleFa = "۲۴. محاسبه حجم ملات دیوارچینی",
            titleEn = "24. Masonry Mortar Volume",
            subtitleFa = "حجم خالص ملات بین رج‌ها و بندهای عمودی بر اساس ابعاد واحد بنایی",
            subtitleEn = "Exact mortar volume = wall gross volume minus masonry unit volume",
            formulaFa = "V_mortar = V_wall - (N_units × L_u × W_u × H_u)",
            formulaEn = "V_mortar = V_wall - (N_units × L_u × W_u × H_u)",
            standardRef = "نشریه ۵۵ / آیین‌نامه دیوارچینی",
            fields = listOf(
                InputFieldSpec("wallArea", "مساحت خالص دیوار", "Net Wall Area", 45.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("wallThickness", "ضخامت دیوار", "Wall Thickness", 20.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("unitLength", "طول آجر یا بلوک", "Unit Length", 21.5, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("unitWidth", "عرض آجر یا بلوک", "Unit Width", 10.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("unitHeight", "ارتفاع آجر یا بلوک", "Unit Height", 5.5, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("jointThickness", "ضخامت بند ملات", "Joint Thickness", 1.2, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 7.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.WALL_NET_AREA,
            titleFa = "۲۵. محاسبه مساحت دیوارها",
            titleEn = "25. Net Wall Area",
            subtitleFa = "محاسبه مساحت کل دیوارها با کسر دقیق بازشوهای در و پنجره",
            subtitleEn = "Gross wall area minus door and window openings",
            formulaFa = "A_net = (N_w × L × H) - (N_d×W_d×H_d + N_win×W_win×H_win)",
            formulaEn = "A_net = (N_w × L × H) - (N_d×W_d×H_d + N_win×W_win×H_win)",
            standardRef = "متره و برآورد ابنیه",
            fields = listOf(
                InputFieldSpec("wallCount", "تعداد دیوار مشابه", "Wall Count", 4.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("wallLength", "طول هر دیوار", "Wall Length", 6.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("wallHeight", "ارتفاع دیوار", "Wall Height", 3.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("doorCount", "تعداد در", "Doors Count", 2.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("doorArea", "مساحت هر در", "Area per Door", 1.9, EngineeringUnit.M2, areaUnits, allowZero = true),
                InputFieldSpec("windowCount", "تعداد پنجره", "Windows Count", 2.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("windowArea", "مساحت هر پنجره", "Area per Window", 2.4, EngineeringUnit.M2, areaUnits, allowZero = true)
            )
        ),

        // ================= GROUP 5: FINISHING =================
        ToolDefinition(
            id = ToolId.GYPSUM_SOIL_PLASTER,
            titleFa = "۲۶. محاسبه گچ و خاک",
            titleEn = "26. Gypsum-Soil Undercoat Plaster",
            subtitleFa = "محاسبه مقدار گچ و خاک موردنیاز بر اساس مساحت، ضخامت لایه و پرت",
            subtitleEn = "Undercoat gypsum-clay plaster weight & bags from area & thickness",
            formulaFa = "W = A × t(m) × ρ_dry(1100 kg/m³) × (1 + w%)",
            formulaEn = "W = A × t(m) × ρ_dry(1100 kg/m³) × (1 + w%)",
            standardRef = "نشریه ۵۵ / نازک‌کاری",
            fields = listOf(
                InputFieldSpec("area", "مساحت دیوارها", "Wall Area", 120.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("thickness", "ضخامت لایه گچ و خاک", "Layer Thickness", 20.0, EngineeringUnit.MM, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 8.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.WHITE_PLASTER,
            titleFa = "۲۷. محاسبه سفیدکاری",
            titleEn = "27. White Finish Plaster",
            subtitleFa = "محاسبه گچ سفیدکاری دیوار و سقف بر اساس مساحت، ضخامت و کیسه",
            subtitleEn = "Finish gypsum plaster for walls and ceilings in kg & bags",
            formulaFa = "W = (A_wall + A_ceil) × t(m) × 950 kg/m³ × (1 + w%)",
            formulaEn = "W = (A_wall + A_ceil) × t(m) × 950 kg/m³ × (1 + w%)",
            standardRef = "نشریه ۵۵ / استاندارد گچ",
            fields = listOf(
                InputFieldSpec("wallArea", "مساحت دیوارها", "Wall Area", 120.0, EngineeringUnit.M2, areaUnits, allowZero = true),
                InputFieldSpec("ceilingArea", "مساحت سقف", "Ceiling Area", 45.0, EngineeringUnit.M2, areaUnits, allowZero = true),
                InputFieldSpec("thickness", "ضخامت سفیدکاری", "Finish Thickness", 5.0, EngineeringUnit.MM, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 7.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.BUILDING_PAINT,
            titleFa = "۲۸. محاسبه رنگ ساختمان",
            titleEn = "28. Building Paint",
            subtitleFa = "محاسبه لیتر و گالن رنگ بر اساس مساحت، تعداد دست و پوشش رنگ",
            subtitleEn = "Paint liters & buckets by area, coats, coverage & waste",
            formulaFa = "Liters = (A × Coats / Coverage) × (1 + w%)",
            formulaEn = "Liters = (A × Coats / Coverage) × (1 + w%)",
            standardRef = "فهرست بها / مشخصات فنی رنگ",
            fields = listOf(
                InputFieldSpec("area", "مساحت رنگ‌آمیزی", "Paintable Area", 180.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("coats", "تعداد دست رنگ", "Number of Coats", 2.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("coverage", "قدرت پوشش (مترمربع بر لیتر)", "Coverage (m²/L)", 10.0, EngineeringUnit.M2),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.FLOOR_CERAMIC,
            titleFa = "۲۹. محاسبه سرامیک کف",
            titleEn = "29. Floor Ceramic Tile",
            subtitleFa = "تعداد و متراژ سرامیک کف بر اساس ابعاد، الگوی چیدمان و پرت",
            subtitleEn = "Floor tile count, boxes & order area by layout pattern & waste",
            formulaFa = "A_order = (L×W) × (1 + w%) , N_tiles = A_order / (L_t × W_t)",
            formulaEn = "A_order = (L×W) × (1 + w%) , N_tiles = A_order / (L_t × W_t)",
            standardRef = "متره نازک‌کاری / الگوی چیدمان",
            supportsTilePattern = true,
            fields = listOf(
                InputFieldSpec("roomLength", "طول کف", "Floor Length", 10.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("roomWidth", "عرض کف", "Floor Width", 10.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("tileLength", "طول سرامیک", "Tile Length", 60.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("tileWidth", "عرض سرامیک", "Tile Width", 60.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("boxCoverage", "متراژ هر کارتن (m²)", "m² per Box", 1.44, EngineeringUnit.M2),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 10.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.WALL_TILE,
            titleFa = "۳۰. محاسبه کاشی دیوار",
            titleEn = "30. Wall Tile",
            subtitleFa = "تعداد کاشی دیوار، کارتن و چسب/ملات موردنیاز بر اساس مساحت خالص",
            subtitleEn = "Wall tile pieces, boxes & adhesive based on net wall area",
            formulaFa = "A_order = A_net × (1 + w%) , N = A_order / (L_t × W_t)",
            formulaEn = "A_order = A_net × (1 + w%) , N = A_order / (L_t × W_t)",
            standardRef = "نشریه ۵۵ / نازک‌کاری",
            fields = listOf(
                InputFieldSpec("netArea", "مساحت خالص دیوار", "Net Wall Area", 42.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("tileLength", "طول کاشی", "Tile Length", 60.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("tileWidth", "عرض کاشی", "Tile Width", 30.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("boxCoverage", "متراژ هر کارتن (m²)", "m² per Box", 1.26, EngineeringUnit.M2),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 10.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.FACADE_STONE,
            titleFa = "۳۱. محاسبه سنگ نما",
            titleEn = "31. Facade Stone",
            subtitleFa = "متراژ، تعداد پلاک سنگ نما و ملات/اسکوپ نصب با ضریب پرت",
            subtitleEn = "Facade stone slabs, area, anchor pins & mortar estimate",
            formulaFa = "A_order = A_facade × (1 + w%) , N_slabs = A_order / (L_s × W_s)",
            formulaEn = "A_order = A_facade × (1 + w%) , N_slabs = A_order / (L_s × W_s)",
            standardRef = "مبحث پنجم و یازدهم / ایمنی نما",
            fields = listOf(
                InputFieldSpec("facadeArea", "مساحت خالص نما", "Net Facade Area", 140.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("stoneLength", "طول هر پلاک سنگ", "Stone Length", 80.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("stoneWidth", "عرض هر پلاک سنگ", "Stone Width", 40.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت برش سنگ (%)", "Cutting Waste (%)", 12.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.FLOOR_STONE,
            titleFa = "۳۲. محاسبه سنگ کف",
            titleEn = "32. Floor Stone",
            subtitleFa = "تعداد پلاک، متراژ خالص و متراژ پیشنهادی خرید سنگ کف",
            subtitleEn = "Floor stone slab count, net area and order area with waste",
            formulaFa = "A_order = A_floor × (1 + w%) , N = A_order / (L_s × W_s)",
            formulaEn = "A_order = A_floor × (1 + w%) , N = A_order / (L_s × W_s)",
            standardRef = "نشریه ۵۵ / نازک‌کاری سنگ",
            fields = listOf(
                InputFieldSpec("floorArea", "مساحت کف", "Floor Area", 85.0, EngineeringUnit.M2, areaUnits),
                InputFieldSpec("stoneLength", "طول سنگ", "Stone Length", 60.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("stoneWidth", "عرض سنگ", "Stone Width", 60.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 10.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.SKIRTING_BASEBOARD,
            titleFa = "۳۳. محاسبه قرنیز",
            titleEn = "33. Skirting / Baseboard",
            subtitleFa = "محاسبه متر طول، مساحت و تعداد شاخه قرنیز با کسر عرض درها",
            subtitleEn = "Perimeter minus door widths -> linear meters, area & pieces",
            formulaFa = "L_net = P - ΣW_doors ; L_order = L_net × (1 + w%)",
            formulaEn = "L_net = P - ΣW_doors ; L_order = L_net × (1 + w%)",
            standardRef = "متره نازک‌کاری",
            fields = listOf(
                InputFieldSpec("perimeter", "مجموع محیط فضاها", "Total Room Perimeter", 48.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("doorsTotalWidth", "مجموع عرض درها", "Total Doors Width", 4.5, EngineeringUnit.M, lengthUnits, allowZero = true),
                InputFieldSpec("skirtingHeight", "ارتفاع قرنیز", "Skirting Height", 10.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("pieceLength", "طول هر شاخه/پلاک قرنیز", "Piece Length", 60.0, EngineeringUnit.CM, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 7.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),

        // ================= GROUP 6: MEP & FIXTURES =================
        ToolDefinition(
            id = ToolId.PLUMBING_PIPES,
            titleFa = "۳۴. محاسبه لوله‌کشی",
            titleEn = "34. Plumbing Pipes & Fittings",
            subtitleFa = "محاسبه طول کل لوله، تعداد شاخه و اتصالات مسیر لوله‌کشی",
            subtitleEn = "Total pipe run length, stock pipe lengths & fittings",
            formulaFa = "L_total = (L_horiz + L_vert) × (1 + w%)",
            formulaEn = "L_total = (L_horiz + L_vert) × (1 + w%)",
            standardRef = "مبحث شانزدهم مقررات ملی",
            fields = listOf(
                InputFieldSpec("horizontalLength", "طول مسیر افقی لوله", "Horizontal Route Length", 65.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("verticalLength", "طول مسیر عمودی/رایزر", "Vertical Riser Length", 24.0, EngineeringUnit.M, lengthUnits, allowZero = true),
                InputFieldSpec("diameterMm", "قطر لوله (میلی‌متر)", "Pipe Diameter (mm)", 25.0, EngineeringUnit.MM, lengthUnits),
                InputFieldSpec("fittingsCount", "تعداد اتصالات (زانو، سه‌راهی، بوشن)", "Fittings Count", 34.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("stockLength", "طول هر شاخه لوله (معمولاً ۴ یا ۶ متر)", "Stock Pipe Length", 4.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("waste", "ضریب پرت/اتصال (%)", "Waste (%)", 8.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.ELECTRICAL_CABLES,
            titleFa = "۳۵. محاسبه سیم و کابل برق",
            titleEn = "35. Electrical Wire & Cable",
            subtitleFa = "طول سیم‌کشی بر اساس تعداد مدارها، طول واقعی مسیر و اضافه سرسیم",
            subtitleEn = "Circuit wiring total meters & 100m coils considering drops",
            formulaFa = "L_wire = N_circuits × (L_avg + L_drop) × N_conductors × (1+w%)",
            formulaEn = "L_wire = N_circuits × (L_avg + L_drop) × N_conductors × (1+w%)",
            standardRef = "مبحث سیزدهم مقررات ملی / IEC 60364",
            fields = listOf(
                InputFieldSpec("circuits", "تعداد مدارهای برق", "Number of Circuits", 12.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("avgRouteLength", "متوسط طول مسیر هر مدار", "Avg Circuit Route Length", 18.0, EngineeringUnit.M, lengthUnits),
                InputFieldSpec("dropAllowance", "اضافه ارتفاع/سرسیم هر مدار", "Vertical Drop Allowance", 3.5, EngineeringUnit.M, lengthUnits, allowZero = true),
                InputFieldSpec("conductors", "تعداد رشته سیم در مسیر (فاز، نول، ارت = ۳)", "Conductors per Circuit", 3.0, EngineeringUnit.PCS, isInteger = true),
                InputFieldSpec("waste", "ضریب پرت (%)", "Waste (%)", 7.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.SWITCHES_OUTLETS,
            titleFa = "۳۶. محاسبه کلید و پریز",
            titleEn = "36. Switches & Outlets",
            subtitleFa = "برآورد تعداد کلیدهای تک‌پل/دوقطب، پریز برق، تلفن/شبکه و قوطی کلید",
            subtitleEn = "Count switches, power outlets, data points & junction boxes",
            formulaFa = "N_total = (N_sw1 + N_sw2 + N_out + N_data) × (1 + spare%)",
            formulaEn = "N_total = (N_sw1 + N_sw2 + N_out + N_data) × (1 + spare%)",
            standardRef = "مبحث سیزدهم / نقشه برق",
            fields = listOf(
                InputFieldSpec("singleSwitches", "تعداد کلید تک‌پل / تبدیل", "Single / Two-Way Switches", 12.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("doubleSwitches", "تعداد کلید دوقطب", "Double Switches", 6.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("powerOutlets", "تعداد پریز برق ارت‌دار", "Grounded Power Outlets", 28.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("dataOutlets", "تعداد پریز تلفن/شبکه/آنتن", "Data / TV / Phone Outlets", 6.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("sparePercent", "درصد ذخیره (%)", "Spare Allowance (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.LIGHTING_FIXTURES,
            titleFa = "۳۷. محاسبه تعداد چراغ‌ها",
            titleEn = "37. Lighting Fixtures",
            subtitleFa = "محاسبه تعداد چراغ‌ها و مجموع توان روشنایی بر اساس نقاط نقشه",
            subtitleEn = "Total lighting points, backup allowance & connected load (W)",
            formulaFa = "N_total = (N_main + N_spot + N_ext) × (1 + spare%)",
            formulaEn = "N_total = (N_main + N_spot + N_ext) × (1 + spare%)",
            standardRef = "مبحث سیزدهم / روشنایی ساختمان",
            fields = listOf(
                InputFieldSpec("mainLights", "چراغ سقفی/لوستر اصلی", "Main Ceiling Lights", 10.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("spotLights", "هالوژن / چراغ توکار", "Recessed / Spot Lights", 24.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("wallLights", "چراغ دیواری / راه‌پله / نما", "Wall / Stair / Exterior Lights", 8.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("avgWattage", "متوسط توان هر چراغ (وات)", "Avg Wattage per Fixture (W)", 12.0, EngineeringUnit.PCS, allowZero = true),
                InputFieldSpec("sparePercent", "درصد ذخیره (%)", "Spare (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.SANITARY_FIXTURES,
            titleFa = "۳۸. محاسبه تجهیزات سرویس بهداشتی",
            titleEn = "38. Sanitary & Bath Fixtures",
            subtitleFa = "ثبت و برآورد تعداد توالت، روشویی، دوش، شیرآلات و کف‌شور",
            subtitleEn = "Bill of toilets, basins, showers, faucets & floor drains",
            formulaFa = "N_total = N_wc + N_basin + N_shower + N_faucet + N_drain",
            formulaEn = "N_total = N_wc + N_basin + N_shower + N_faucet + N_drain",
            standardRef = "مبحث شانزدهم / تجهیزات بهداشتی",
            fields = listOf(
                InputFieldSpec("toilets", "تعداد توالت (ایرانی/فرنگی)", "Toilets (WC)", 3.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("vanities", "تعداد روشویی و آینه", "Vanity / Washbasins", 3.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("showers", "تعداد ست دوش حمام", "Shower Sets", 2.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("faucets", "تعداد کل شیرآلات", "Total Faucets / Mixers", 8.0, EngineeringUnit.PCS, isInteger = true, allowZero = true),
                InputFieldSpec("drains", "تعداد کف‌شور", "Floor Drains", 5.0, EngineeringUnit.PCS, isInteger = true, allowZero = true)
            )
        ),

        // ================= GROUP 7: COST & BOQ =================
        ToolDefinition(
            id = ToolId.MATERIAL_COST,
            titleFa = "۳۹. محاسبه هزینه مصالح",
            titleEn = "39. Material Cost Estimator",
            subtitleFa = "محاسبه هزینه دقیق مصالح بر اساس مقدار و قیمت روز ثبت‌شده کاربر",
            subtitleEn = "Calculate total material cost from quantities & user unit prices",
            formulaFa = "Cost_total = Σ (Qty_i × Price_i) + Transport + Overhead",
            formulaEn = "Cost_total = Σ (Qty_i × Price_i) + Transport + Overhead",
            standardRef = "برآورد مالی مصالح (آفلاین)",
            supportsMaterialCostList = true,
            fields = listOf(
                InputFieldSpec("transportCost", "هزینه حمل‌ونقل", "Transport Cost", 0.0, EngineeringUnit.PCS, allowZero = true),
                InputFieldSpec("contingencyPercent", "ضریب پیش‌بینی‌نشده (%)", "Contingency (%)", 5.0, EngineeringUnit.PCS, allowZero = true)
            )
        ),
        ToolDefinition(
            id = ToolId.FINAL_PROJECT_BOQ,
            titleFa = "۴۰. متره و برآورد نهایی پروژه",
            titleEn = "40. Final Project BOQ & Cost",
            subtitleFa = "تجمیع کامل تمام محاسبات ذخیره‌شده پروژه شامل مصالح، دستمزد، حمل و تجهیزات",
            subtitleEn = "Master project takeoff & budget combining materials, labor, transport & equipment",
            formulaFa = "Total = Cost_materials + Cost_labor + Cost_transport + Cost_equipment",
            formulaEn = "Total = Cost_materials + Cost_labor + Cost_transport + Cost_equipment",
            standardRef = "گزارش جامع متره و برآورد پروژه",
            fields = listOf(
                InputFieldSpec("laborCostPerM2", "دستمزد اجرا به ازای هر مترمربع زیربنا", "Labor Cost per m² Built-up", 3500000.0, EngineeringUnit.PCS, allowZero = true),
                InputFieldSpec("transportCost", "هزینه حمل و ماشین‌آلات", "Transport Cost", 45000000.0, EngineeringUnit.PCS, allowZero = true),
                InputFieldSpec("equipmentCost", "هزینه تجهیزات و تأسیسات", "Equipment & Fixtures Cost", 80000000.0, EngineeringUnit.PCS, allowZero = true),
                InputFieldSpec("contingencyPercent", "ضریب احتیاط و نوسان (%)", "Contingency (%)", 10.0, EngineeringUnit.PCS, allowZero = true)
            )
        )
    )

    private val mapById: Map<ToolId, ToolDefinition> = allTools.associateBy { it.id }

    fun get(id: ToolId): ToolDefinition = mapById.getValue(id)

    fun byGroup(group: ToolGroup): List<ToolDefinition> = allTools.filter { it.id.group == group }
}
