package com.example.engine

import com.example.model.EngineeringUnit
import com.example.model.UnitDimension
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.round

object UnitConverter {
    fun convert(value: Double, from: EngineeringUnit, to: EngineeringUnit): Double {
        if (from == to) return value
        require(from.dimension == to.dimension) {
            "Incompatible unit dimensions: ${from.name} -> ${to.name}"
        }
        val baseValue = value * from.toBaseFactor
        return baseValue / to.toBaseFactor
    }

    fun toMeters(value: Double, unit: EngineeringUnit): Double {
        return convert(value, unit, EngineeringUnit.M)
    }

    fun toMillimeters(value: Double, unit: EngineeringUnit): Double {
        return convert(value, unit, EngineeringUnit.MM)
    }

    fun toKilograms(value: Double, unit: EngineeringUnit): Double {
        return convert(value, unit, EngineeringUnit.KG)
    }

    fun canConvert(from: EngineeringUnit, to: EngineeringUnit): Boolean =
        from.dimension == to.dimension

    fun unitsForDimension(dimension: UnitDimension): List<EngineeringUnit> =
        EngineeringUnit.entries.filter { it.dimension == dimension }

    fun roundTo(value: Double, decimals: Int = 2): Double {
        if (value.isNaN() || value.isInfinite()) return 0.0
        var factor = 1.0
        repeat(decimals.coerceIn(0, 6)) { factor *= 10.0 }
        return round(value * factor) / factor
    }

    fun formatNumber(value: Double, decimals: Int = 2): String {
        val rounded = roundTo(value, decimals)
        val pattern = if (decimals <= 0) "#,##0" else "#,##0.${"#".repeat(decimals)}"
        val symbols = DecimalFormatSymbols(Locale.US)
        return DecimalFormat(pattern, symbols).format(rounded)
    }
}
