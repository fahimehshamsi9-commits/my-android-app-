package com.example.engine

import com.example.model.EngineeringUnit
import com.example.model.MaterialPriceEntity
import com.example.model.UnitDimension
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ceil

internal object CalcHelper {
    fun getMeters(input: CalculationInput, key: String, defaultMeters: Double): Double {
        val raw = input.values[key] ?: defaultMeters
        val unit = input.units[key] ?: EngineeringUnit.M
        return if (unit.dimension == UnitDimension.LENGTH) UnitConverter.toMeters(raw, unit) else raw
    }

    fun getMillimeters(input: CalculationInput, key: String, defaultMm: Double): Double {
        val raw = input.values[key] ?: defaultMm
        val unit = input.units[key] ?: EngineeringUnit.MM
        return if (unit.dimension == UnitDimension.LENGTH) UnitConverter.toMillimeters(raw, unit) else raw
    }

    fun getRaw(input: CalculationInput, key: String, defaultValue: Double): Double {
        return input.values[key] ?: defaultValue
    }

    fun getMassKg(input: CalculationInput, key: String, defaultKg: Double): Double {
        val raw = input.values[key] ?: defaultKg
        val unit = input.units[key] ?: EngineeringUnit.KG
        return if (unit.dimension == UnitDimension.MASS) UnitConverter.toKilograms(raw, unit) else raw
    }

    fun validateInputs(def: ToolDefinition, input: CalculationInput): CalculationOutcome? {
        for (field in def.fields) {
            val v = input.values[field.key] ?: field.defaultValue
            if (v.isNaN() || v.isInfinite()) {
                return errorOutcome(
                    def.id,
                    "مقدار وارد شده برای «${field.labelFa}» نامعتبر است.",
                    "Invalid numeric value for '${field.labelEn}'."
                )
            }
            if (v < 0.0) {
                return errorOutcome(
                    def.id,
                    "مقدار «${field.labelFa}» نمی‌تواند منفی باشد.",
                    "'${field.labelEn}' cannot be negative."
                )
            }
            if (!field.allowZero && v == 0.0) {
                return errorOutcome(
                    def.id,
                    "مقدار «${field.labelFa}» باید بزرگ‌تر از صفر باشد.",
                    "'${field.labelEn}' must be greater than zero."
                )
            }
            if (field.key == "waste" && v > 100.0) {
                return errorOutcome(
                    def.id,
                    "ضریب پرت نمی‌تواند بیشتر از ۱۰۰ درصد باشد.",
                    "Waste percentage cannot exceed 100%."
                )
            }
        }
        return null
    }

    fun errorOutcome(toolId: ToolId, fa: String, en: String): CalculationOutcome =
        CalculationOutcome(
            toolId = toolId,
            isSuccess = false,
            errorFa = fa,
            errorEn = en
        )

    fun priceFor(catalog: Map<String, MaterialPriceEntity>, key: String): Double =
        catalog[key]?.unitPrice ?: 0.0

    fun makeMaterial(
        key: String,
        nameFa: String,
        nameEn: String,
        netQty: Double,
        wastePct: Double,
        unit: EngineeringUnit,
        catalog: Map<String, MaterialPriceEntity>,
        packageDivisor: Double = 0.0,
        packageLabelFa: String = "",
        packageLabelEn: String = ""
    ): MaterialEstimate {
        val orderQty = netQty * (1.0 + wastePct / 100.0)
        val pkgCount = if (packageDivisor > 0.0) ceil(orderQty / packageDivisor) else 0.0
        val unitPrice = priceFor(catalog, key)
        val billableQty = when {
            key == "cement" && unit == EngineeringUnit.KG -> ceil(orderQty / 50.0) // catalog priced per 50kg bag
            packageDivisor > 0.0 && catalog[key]?.unit == EngineeringUnit.BAG -> pkgCount
            else -> orderQty
        }
        val totalCost = billableQty * unitPrice
        return MaterialEstimate(
            materialKey = key,
            nameFa = nameFa,
            nameEn = nameEn,
            netQuantity = UnitConverter.roundTo(netQty, 3),
            wastePercent = UnitConverter.roundTo(wastePct, 2),
            orderQuantity = UnitConverter.roundTo(orderQty, 3),
            unit = unit,
            packageLabelFa = packageLabelFa,
            packageLabelEn = packageLabelEn,
            packageCount = pkgCount,
            unitPrice = unitPrice,
            totalCost = UnitConverter.roundTo(totalCost, 0)
        )
    }

    fun standardEngineeringLimitations(isStructural: Boolean): Pair<List<String>, List<String>> {
        val fa = mutableListOf(
            "دقت ۱۰۰ درصدی تضمین نمی‌شود؛ تلرانس اجرا، پرت کارگاهی و شرایط واقعی کارگاه بر مقادیر نهایی مؤثر است.",
            "این خروجی برآورد هندسی و مهندسی بر پایه ورودی‌های فعلی است و نیازمند تطبیق با نقشه‌های مصوب اجرایی می‌باشد."
        )
        val en = mutableListOf(
            "100% precision is not guaranteed; site tolerances, cutting patterns, and workmanship affect final quantities.",
            "This result is a geometric engineering estimate based on current inputs and must be cross-checked against approved construction drawings."
        )
        if (isStructural) {
            fa.add(0, "محدودیت سازه‌ای: این ابزار صرفاً برای متره و کنترل مقادیر است. تعیین قطر، تعداد، آرایش میلگرد و ابعاد اعضا باید توسط مهندس محاسب دارای پروانه و نقشه‌های تأییدشده انجام شود.")
            en.add(0, "Structural Limitation: This tool is for quantity takeoff and checking only. Rebar diameter, spacing, detailing, and member sizing must come from a licensed structural engineer and approved drawings.")
        }
        return fa to en
    }

    fun outcomeToJson(outcome: CalculationOutcome): String {
        val root = JSONObject()
        root.put("toolId", outcome.toolId.name)
        root.put("primaryValue", outcome.primaryValue)
        root.put("primaryUnit", outcome.primaryUnit.name)
        root.put("isPreliminary", outcome.isPreliminary)
        root.put("formulaUsed", outcome.formulaUsed)
        root.put("standardRef", outcome.standardRef)
        root.put("totalEstimatedCost", outcome.totalEstimatedCost)

        val mats = JSONArray()
        outcome.materials.forEach { m ->
            val obj = JSONObject()
            obj.put("key", m.materialKey)
            obj.put("nameFa", m.nameFa)
            obj.put("nameEn", m.nameEn)
            obj.put("net", m.netQuantity)
            obj.put("waste", m.wastePercent)
            obj.put("order", m.orderQuantity)
            obj.put("unit", m.unit.name)
            obj.put("pkgCount", m.packageCount)
            obj.put("pkgFa", m.packageLabelFa)
            obj.put("pkgEn", m.packageLabelEn)
            obj.put("unitPrice", m.unitPrice)
            obj.put("totalCost", m.totalCost)
            mats.put(obj)
        }
        root.put("materials", mats)
        return root.toString()
    }

    fun parseMaterialsFromJson(json: String): List<MaterialEstimate> {
        return try {
            val root = JSONObject(json)
            val arr = root.optJSONArray("materials") ?: return emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val unit = EngineeringUnit.entries.firstOrNull { it.name == obj.optString("unit") }
                        ?: EngineeringUnit.PCS
                    add(
                        MaterialEstimate(
                            materialKey = obj.optString("key"),
                            nameFa = obj.optString("nameFa"),
                            nameEn = obj.optString("nameEn"),
                            netQuantity = obj.optDouble("net", 0.0),
                            wastePercent = obj.optDouble("waste", 0.0),
                            orderQuantity = obj.optDouble("order", 0.0),
                            unit = unit,
                            packageCount = obj.optDouble("pkgCount", 0.0),
                            packageLabelFa = obj.optString("pkgFa"),
                            packageLabelEn = obj.optString("pkgEn"),
                            unitPrice = obj.optDouble("unitPrice", 0.0),
                            totalCost = obj.optDouble("totalCost", 0.0)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
