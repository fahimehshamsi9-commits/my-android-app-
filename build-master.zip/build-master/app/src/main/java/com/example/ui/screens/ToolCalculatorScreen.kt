package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.audio.SoundCue
import com.example.engine.CalculationEngine
import com.example.engine.CalculationInput
import com.example.engine.CalculationOutcome
import com.example.engine.DynamicCostRow
import com.example.engine.DynamicCutRebarRow
import com.example.engine.SteelCatalog
import com.example.engine.ToolCatalog
import com.example.engine.ToolId
import com.example.model.ConcreteMixGrade
import com.example.model.EngineeringUnit
import com.example.model.MaterialPriceEntity
import com.example.model.ProjectEntity
import com.example.model.TileLayoutPattern
import com.example.model.UserSettings
import com.example.model.bi
import com.example.ui.components.CalculationReportPanel
import com.example.ui.components.EngineeringCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.VerifiedGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ToolCalculatorScreen(
    toolId: ToolId,
    activeProject: ProjectEntity?,
    priceCatalog: List<MaterialPriceEntity>,
    settings: UserSettings,
    onRunCalculation: (ToolId, CalculationInput) -> CalculationOutcome,
    onSaveOutcome: (CalculationOutcome) -> Unit,
    onPlayCue: (SoundCue) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val lang = settings.language
    val currency = settings.currency(lang)
    val def = remember(toolId) { ToolCatalog.get(toolId) }

    val initialPair = remember(toolId, activeProject?.id, settings.defaultWastePercent) {
        CalculationEngine.buildInitialInputs(toolId, activeProject, settings.defaultWastePercent)
    }

    val textValues = remember(toolId, activeProject?.id) {
        mutableStateMapOf<String, String>().apply {
            initialPair.first.forEach { (k, v) ->
                val isInt = def.fields.firstOrNull { it.key == k }?.isInteger == true
                put(k, if (isInt) v.toInt().toString() else v.toString().removeSuffix(".0"))
            }
        }
    }
    val selectedUnits = remember(toolId, activeProject?.id) {
        mutableStateMapOf<String, EngineeringUnit>().apply {
            putAll(initialPair.second)
        }
    }

    var mixGrade by remember(toolId) { mutableStateOf(ConcreteMixGrade.M20_1_15_3) }
    var tilePattern by remember(toolId) { mutableStateOf(TileLayoutPattern.STRAIGHT) }
    var selectedIBeam by remember(toolId) { mutableStateOf(SteelCatalog.iBeams.first().code) }
    var selectedProfile by remember(toolId) { mutableStateOf(SteelCatalog.profiles.first().code) }

    var cutRebarRows by remember(toolId) {
        mutableStateOf(
            listOf(
                DynamicCutRebarRow(1, 16, 12.0, 20),
                DynamicCutRebarRow(2, 10, 4.5, 40)
            )
        )
    }

    var costRows by remember(toolId, priceCatalog) {
        mutableStateOf(
            listOf(
                DynamicCostRow(1, "cement", "سیمان (کیسه)", "Cement (bags)", 120.0, EngineeringUnit.BAG, priceCatalog.firstOrNull { it.materialKey == "cement" }?.unitPrice ?: 115000.0),
                DynamicCostRow(2, "rebar", "میلگرد (کیلوگرم)", "Rebar (kg)", 3500.0, EngineeringUnit.KG, priceCatalog.firstOrNull { it.materialKey == "rebar" }?.unitPrice ?: 34500.0)
            )
        )
    }

    var outcome by remember(toolId) { mutableStateOf<CalculationOutcome?>(null) }
    var validationError by remember(toolId) { mutableStateOf<String?>(null) }

    fun evaluateNow() {
        val numericMap = mutableMapOf<String, Double>()
        for (field in def.fields) {
            val rawStr = textValues[field.key]?.trim().orEmpty()
            if (rawStr.isEmpty()) {
                validationError = bi(lang, "فیلد «${field.labelFa}» خالی است.", "Field '${field.labelEn}' is empty.")
                outcome = null
                return
            }
            val parsed = rawStr.toDoubleOrNull()
            if (parsed == null) {
                validationError = bi(lang, "مقدار عددی «${field.labelFa}» نامعتبر است.", "Invalid number in '${field.labelEn}'.")
                outcome = null
                return
            }
            numericMap[field.key] = parsed
        }
        val input = CalculationInput(
            values = numericMap,
            units = selectedUnits.toMap(),
            mixGrade = mixGrade,
            tilePattern = tilePattern,
            selectedIBeamCode = selectedIBeam,
            selectedProfileCode = selectedProfile,
            cutRebarRows = cutRebarRows,
            costRows = costRows
        )
        val res = onRunCalculation(toolId, input)
        if (!res.isSuccess) {
            validationError = res.error(lang)
            outcome = null
        } else {
            validationError = null
            outcome = res
            onPlayCue(SoundCue.CALCULATE)
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().testTag("tool_calculator_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header Card
        item {
            EngineeringCard(accentColor = EngineeringOrange) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("tool_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = bi(lang, "بازگشت", "Back"))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(def.title(lang), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(def.subtitle(lang), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${bi(lang, "فرمول:", "Formula:")} ${def.formula(lang)}  |  ${def.standardRef}",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = ElectricBlue
                )
                if (activeProject != null) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            val refill = CalculationEngine.buildInitialInputs(toolId, activeProject, settings.defaultWastePercent)
                            refill.first.forEach { (k, v) ->
                                val isInt = def.fields.firstOrNull { it.key == k }?.isInteger == true
                                textValues[k] = if (isInt) v.toInt().toString() else v.toString().removeSuffix(".0")
                            }
                            selectedUnits.putAll(refill.second)
                            onPlayCue(SoundCue.CLICK)
                        }
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(bi(lang, "بارگذاری ابعاد از پروژه «${activeProject.name}»", "Auto-fill from '${activeProject.name}'"))
                    }
                }
            }
        }

        // Inputs Card
        item {
            EngineeringCard(accentColor = ElectricBlue) {
                Text(bi(lang, "ورودی‌ها و پارامترها", "Inputs & Parameters"), style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                Spacer(Modifier.height(10.dp))

                // Special selectors
                if (def.supportsMixGrade) {
                    Text(bi(lang, "انتخاب طرح اختلاط بتن:", "Select Concrete Mix Grade:"), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(4.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ConcreteMixGrade.entries.forEach { g ->
                            FilterChip(selected = mixGrade == g, onClick = { mixGrade = g }, label = { Text(g.title(lang)) })
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                if (def.supportsTilePattern) {
                    Text(bi(lang, "الگوی چیدمان سرامیک:", "Tile Layout Pattern:"), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(4.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TileLayoutPattern.entries.forEach { p ->
                            FilterChip(
                                selected = tilePattern == p,
                                onClick = {
                                    tilePattern = p
                                    textValues["waste"] = p.recommendedWastePercent.toString()
                                },
                                label = { Text("${p.title(lang)} (${p.recommendedWastePercent.toInt()}%)") }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                if (def.supportsIBeamPicker) {
                    Text(bi(lang, "انتخاب مقطع تیرآهن (جدول اشتال):", "Select Standard I-Beam:"), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(4.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SteelCatalog.iBeams.forEach { spec ->
                            FilterChip(
                                selected = selectedIBeam == spec.code,
                                onClick = { selectedIBeam = spec.code },
                                label = { Text("${spec.code} (${spec.weightKgPerMeter} kg/m)") }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                if (def.supportsProfilePicker) {
                    Text(bi(lang, "انتخاب پروفیل فولادی:", "Select Steel Profile:"), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(4.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SteelCatalog.profiles.forEach { spec ->
                            FilterChip(
                                selected = selectedProfile == spec.code,
                                onClick = { selectedProfile = spec.code },
                                label = { Text("${spec.title(lang)} (${spec.weightKgPerMeter} kg/m)") }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                // Dynamic Cut Rebar Rows for Tool #16
                if (def.supportsCutRebarList) {
                    Text(bi(lang, "لیست قطعات میلگرد برش‌خورده:", "Cut Rebar Schedule Rows:"), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    cutRebarRows.forEachIndexed { idx, row ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = row.diameterMm.toString(),
                                onValueChange = { v ->
                                    val d = v.filter(Char::isDigit).toIntOrNull() ?: 0
                                    cutRebarRows = cutRebarRows.toMutableList().also { it[idx] = row.copy(diameterMm = d) }
                                },
                                label = { Text("Ømm") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = row.lengthM.toString(),
                                onValueChange = { v ->
                                    val l = v.toDoubleOrNull() ?: 0.0
                                    cutRebarRows = cutRebarRows.toMutableList().also { it[idx] = row.copy(lengthM = l) }
                                },
                                label = { Text("L(m)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = row.count.toString(),
                                onValueChange = { v ->
                                    val c = v.filter(Char::isDigit).toIntOrNull() ?: 0
                                    cutRebarRows = cutRebarRows.toMutableList().also { it[idx] = row.copy(count = c) }
                                },
                                label = { Text(bi(lang, "تعداد", "Qty")) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                if (cutRebarRows.size > 1) {
                                    cutRebarRows = cutRebarRows.filterIndexed { i, _ -> i != idx }
                                }
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = AlertRed)
                            }
                        }
                    }
                    OutlinedButton(onClick = {
                        val nextId = (cutRebarRows.maxOfOrNull { it.id } ?: 0) + 1
                        cutRebarRows = cutRebarRows + DynamicCutRebarRow(nextId, 12, 6.0, 10)
                    }) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text(bi(lang, "افزودن ردیف میلگرد", "Add Rebar Row"))
                    }
                    Spacer(Modifier.height(10.dp))
                }

                // Dynamic Material Cost Rows for Tool #39
                if (def.supportsMaterialCostList) {
                    Text(bi(lang, "اقلام مصالح و قیمت واحد:", "Material Quantities & Unit Prices:"), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    costRows.forEachIndexed { idx, row ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = if (lang == com.example.model.AppLanguage.FA) row.nameFa else row.nameEn,
                                onValueChange = { v ->
                                    costRows = costRows.toMutableList().also {
                                        it[idx] = if (lang == com.example.model.AppLanguage.FA) row.copy(nameFa = v) else row.copy(nameEn = v)
                                    }
                                },
                                label = { Text(bi(lang, "نام مصالح", "Item")) },
                                singleLine = true,
                                modifier = Modifier.weight(1.3f)
                            )
                            OutlinedTextField(
                                value = row.quantity.toString(),
                                onValueChange = { v ->
                                    val q = v.toDoubleOrNull() ?: 0.0
                                    costRows = costRows.toMutableList().also { it[idx] = row.copy(quantity = q) }
                                },
                                label = { Text(bi(lang, "مقدار", "Qty")) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(0.8f)
                            )
                            OutlinedTextField(
                                value = row.unitPrice.toLong().toString(),
                                onValueChange = { v ->
                                    val p = v.toDoubleOrNull() ?: 0.0
                                    costRows = costRows.toMutableList().also { it[idx] = row.copy(unitPrice = p) }
                                },
                                label = { Text(bi(lang, "قیمت", "Price")) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                if (costRows.size > 1) {
                                    costRows = costRows.filterIndexed { i, _ -> i != idx }
                                }
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = AlertRed)
                            }
                        }
                    }
                    OutlinedButton(onClick = {
                        val nextId = (costRows.maxOfOrNull { it.id } ?: 0) + 1
                        costRows = costRows + DynamicCostRow(nextId, "custom_$nextId", "مصالح جدید", "Custom Item", 10.0, EngineeringUnit.PCS, 50000.0)
                    }) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text(bi(lang, "افزودن ردیف مصالح", "Add Cost Row"))
                    }
                    Spacer(Modifier.height(10.dp))
                }

                // Standard Numeric Fields with optional Unit Picker
                def.fields.forEach { field ->
                    val currentUnit = selectedUnits[field.key] ?: field.defaultUnit
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textValues[field.key] ?: "",
                            onValueChange = { raw ->
                                textValues[field.key] = raw.filter { it.isDigit() || it == '.' || it == '-' }
                            },
                            label = { Text(field.label(lang)) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = if (field.isInteger) KeyboardType.Number else KeyboardType.Decimal
                            ),
                            modifier = Modifier.weight(1f).testTag("input_${field.key}")
                        )

                        if (field.allowedUnits.size > 1) {
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(onClick = { expanded = true }) {
                                    Text(currentUnit.symbol(lang))
                                }
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    field.allowedUnits.forEach { u ->
                                        DropdownMenuItem(
                                            text = { Text("${u.symbolFa} (${u.symbolEn})") },
                                            onClick = {
                                                selectedUnits[field.key] = u
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = currentUnit.symbol(lang),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp)
                            )
                        }
                    }
                }

                validationError?.let { err ->
                    Spacer(Modifier.height(8.dp))
                    Text(err, style = MaterialTheme.typography.bodyMedium, color = AlertRed, fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { evaluateNow() },
                        colors = ButtonDefaults.buttonColors(containerColor = EngineeringOrange),
                        modifier = Modifier.weight(1f).testTag("calculate_btn")
                    ) {
                        Icon(Icons.Default.Calculate, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(bi(lang, "محاسبه دقیق", "Calculate"))
                    }
                    if (outcome != null && outcome?.isSuccess == true) {
                        Button(
                            onClick = { outcome?.let(onSaveOutcome) },
                            colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen),
                            modifier = Modifier.weight(1f).testTag("save_calculation_btn")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(bi(lang, "ثبت در پروژه", "Save Result"))
                        }
                    }
                }
            }
        }

        // Result & 3-part Report
        outcome?.let { res ->
            if (res.isSuccess) {
                item {
                    CalculationReportPanel(outcome = res, lang = lang, currency = currency)
                }
            }
        }
    }
}
