package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.EngineeringUnit
import com.example.model.UserSettings
import com.example.ui.theme.AppFontChoice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "build_master_settings")

class SettingsDataStore(private val context: Context) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val FONT_CHOICE = stringPreferencesKey("font_choice")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val ANIMATIONS = booleanPreferencesKey("animations")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val SOUND_VOLUME = floatPreferencesKey("sound_volume")
        val DEFAULT_UNIT = stringPreferencesKey("default_unit")
        val DEFAULT_WASTE = doublePreferencesKey("default_waste")
        val CURRENCY_FA = stringPreferencesKey("currency_fa")
        val CURRENCY_EN = stringPreferencesKey("currency_en")
        val ACTIVE_PROJECT_ID = longPreferencesKey("active_project_id")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            language = AppLanguage.entries.firstOrNull { it.code == prefs[Keys.LANGUAGE] } ?: AppLanguage.FA,
            darkTheme = prefs[Keys.DARK_THEME] ?: true,
            fontChoice = AppFontChoice.entries.firstOrNull { it.key == prefs[Keys.FONT_CHOICE] } ?: AppFontChoice.VAZIRMATN,
            fontScale = prefs[Keys.FONT_SCALE] ?: 1.0f,
            animationsEnabled = prefs[Keys.ANIMATIONS] ?: true,
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            soundVolume = prefs[Keys.SOUND_VOLUME] ?: 0.6f,
            defaultLengthUnit = EngineeringUnit.entries.firstOrNull { it.name == prefs[Keys.DEFAULT_UNIT] } ?: EngineeringUnit.M,
            defaultWastePercent = prefs[Keys.DEFAULT_WASTE] ?: 5.0,
            currencySymbolFa = prefs[Keys.CURRENCY_FA] ?: "تومان",
            currencySymbolEn = prefs[Keys.CURRENCY_EN] ?: "Toman"
        )
    }

    val activeProjectIdFlow: Flow<Long?> = context.dataStore.data.map { prefs ->
        prefs[Keys.ACTIVE_PROJECT_ID]?.takeIf { it > 0L }
    }

    suspend fun updateSettings(transform: (UserSettings) -> UserSettings) {
        context.dataStore.edit { prefs ->
            val current = UserSettings(
                language = AppLanguage.entries.firstOrNull { it.code == prefs[Keys.LANGUAGE] } ?: AppLanguage.FA,
                darkTheme = prefs[Keys.DARK_THEME] ?: true,
                fontChoice = AppFontChoice.entries.firstOrNull { it.key == prefs[Keys.FONT_CHOICE] } ?: AppFontChoice.VAZIRMATN,
                fontScale = prefs[Keys.FONT_SCALE] ?: 1.0f,
                animationsEnabled = prefs[Keys.ANIMATIONS] ?: true,
                soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
                soundVolume = prefs[Keys.SOUND_VOLUME] ?: 0.6f,
                defaultLengthUnit = EngineeringUnit.entries.firstOrNull { it.name == prefs[Keys.DEFAULT_UNIT] } ?: EngineeringUnit.M,
                defaultWastePercent = prefs[Keys.DEFAULT_WASTE] ?: 5.0,
                currencySymbolFa = prefs[Keys.CURRENCY_FA] ?: "تومان",
                currencySymbolEn = prefs[Keys.CURRENCY_EN] ?: "Toman"
            )
            val next = transform(current)
            prefs[Keys.LANGUAGE] = next.language.code
            prefs[Keys.DARK_THEME] = next.darkTheme
            prefs[Keys.FONT_CHOICE] = next.fontChoice.key
            prefs[Keys.FONT_SCALE] = next.fontScale
            prefs[Keys.ANIMATIONS] = next.animationsEnabled
            prefs[Keys.SOUND_ENABLED] = next.soundEnabled
            prefs[Keys.SOUND_VOLUME] = next.soundVolume
            prefs[Keys.DEFAULT_UNIT] = next.defaultLengthUnit.name
            prefs[Keys.DEFAULT_WASTE] = next.defaultWastePercent
            prefs[Keys.CURRENCY_FA] = next.currencySymbolFa
            prefs[Keys.CURRENCY_EN] = next.currencySymbolEn
        }
    }

    suspend fun setActiveProjectId(projectId: Long?) {
        context.dataStore.edit { prefs ->
            if (projectId == null || projectId <= 0L) prefs.remove(Keys.ACTIVE_PROJECT_ID)
            else prefs[Keys.ACTIVE_PROJECT_ID] = projectId
        }
    }
}
