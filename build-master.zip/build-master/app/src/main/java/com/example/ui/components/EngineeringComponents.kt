package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.engine.CalculationOutcome
import com.example.engine.UnitConverter.formatNumber
import com.example.model.AppLanguage
import com.example.engine.MaterialEstimate
import com.example.model.bi
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EngineeringOrange
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PreliminaryAmber
import com.example.ui.theme.PreliminaryAmberSoft
import com.example.ui.theme.VerifiedGreen
import com.example.ui.theme.VerifiedGreenSoft

/**
 * 3D-elevated subtle engineering card with crisp top bevel and soft shadow.
 */
@Composable
fun EngineeringCard(
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.outline,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val cardModifier = modifier
        .shadow(elevation = 6.dp, shape = shape, clip = false)
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    val border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
    if (onClick != null) {
        Card(
            onClick = onClick,
            modifier = cardModifier,
            shape = shape,
            colors = colors,
            border = border
        ) {
            Column(modifier = Modifier.padding(16.dp), content = content)
        }
    } else {
        Card(
            modifier = cardModifier,
            shape = shape,
            colors = colors,
            border = border
        ) {
            Column(modifier = Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
fun KpiMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier
) {
    EngineeringCard(modifier = modifier, accentColor = accent) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium.copy(fontFamily = JetBrainsMonoFontFamily),
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun StatusBadge(
    isPreliminary: Boolean,
    lang: AppLanguage
) {
    val bg = if (isPreliminary) PreliminaryAmberSoft else VerifiedGreenSoft
    val fg = if (isPreliminary) PreliminaryAmber else VerifiedGreen
    val icon = if (isPreliminary) Icons.Default.Warning else Icons.Default.CheckCircle
    val label = if (isPreliminary) {
        bi(lang, "برآورد اولیه (اطلاعات ناقص)", "Preliminary Estimate")
    } else {
        bi(lang, "برآورد هندسی تأییدشده", "Verified Geometric Estimate")
    }

    Surface(
        shape = RoundedCornerShape(50),
        color = bg,
        border = BorderStroke(1.dp, fg.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = label, tint = fg, modifier = Modifier.size(16.dp))
            Text(label, style = MaterialTheme.typography.labelMedium, color = fg, fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * Displays the mandatory 3-part accuracy, assumptions, and limitations report for every calculation.
 */
@Composable
fun CalculationReportPanel(
    outcome: CalculationOutcome,
    lang: AppLanguage,
    currency: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Section 1: Result + Status
        EngineeringCard(
            accentColor = if (outcome.isPreliminary) PreliminaryAmber else VerifiedGreen
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = bi(lang, "۱. نتیجه محاسبه", "1. Calculation Result"),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                StatusBadge(isPreliminary = outcome.isPreliminary, lang = lang)
            }
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                MaterialTheme.colorScheme.surfaceVariant,
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                            )
                        )
                    )
                    .padding(14.dp)
            ) {
                Column {
                    Text(
                        text = outcome.primaryLabel(lang),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = formatNumber(outcome.primaryValue, 2),
                            style = MaterialTheme.typography.displayLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = if (outcome.isPreliminary) PreliminaryAmber else VerifiedGreen
                        )
                        Text(
                            text = outcome.primaryUnit.symbol(lang),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                    if (outcome.totalEstimatedCost > 0) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "${bi(lang, "برآورد هزینه:", "Estimated Cost:")} ${formatNumber(outcome.totalEstimatedCost, 0)} $currency",
                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = EngineeringOrange
                        )
                    }
                }
            }

            outcome.preliminaryReason(lang)?.let { reason ->
                Spacer(Modifier.height(8.dp))
                Text(reason, style = MaterialTheme.typography.bodySmall, color = PreliminaryAmber)
            }

            if (outcome.secondaryMetrics.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                outcome.secondaryMetrics.forEach { m ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(m.label(lang), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "${formatNumber(m.value, 2)} ${m.unit.symbol(lang)}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                }
            }
        }

        // Material Order Breakdown
        if (outcome.materials.isNotEmpty()) {
            EngineeringCard(accentColor = ElectricBlue) {
                Text(
                    text = bi(lang, "مقدار مصالح پیشنهادی خرید (با پرت و بسته‌بندی)", "Material Order Breakdown (Net, Waste & Packages)"),
                    style = MaterialTheme.typography.titleMedium,
                    color = ElectricBlue
                )
                Spacer(Modifier.height(10.dp))
                outcome.materials.forEachIndexed { idx, mat ->
                    MaterialEstimateRow(mat, lang, currency)
                    if (idx < outcome.materials.lastIndex) {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 8.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }

        // Step-by-Step Breakdown
        if (outcome.steps.isNotEmpty()) {
            EngineeringCard(accentColor = MaterialTheme.colorScheme.outline) {
                Text(
                    text = bi(lang, "مراحل محاسبه و فرمول", "Step-by-Step Calculation & Formula"),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${bi(lang, "فرمول:", "Formula:")} ${outcome.formulaUsed}  |  ${outcome.standardRef}",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = ElectricBlue
                )
                Spacer(Modifier.height(10.dp))
                outcome.steps.forEachIndexed { idx, step ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(EngineeringOrange.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("${idx + 1}", style = MaterialTheme.typography.labelSmall, color = EngineeringOrange)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(step.title(lang), style = MaterialTheme.typography.labelLarge)
                            Text(
                                text = "${step.expression}  =  ${step.resultFormatted}",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Assumptions
        EngineeringCard(accentColor = ElectricBlue) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Info, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(18.dp))
                Text(
                    text = bi(lang, "۲. فرضیات و اطلاعات استفاده‌شده", "2. Assumptions & Parameters Used"),
                    style = MaterialTheme.typography.titleMedium,
                    color = ElectricBlue
                )
            }
            Spacer(Modifier.height(8.dp))
            outcome.assumptions(lang).forEach { item ->
                Text("• $item", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 2.dp))
            }
        }

        // Section 3: Limitations & Uncertainty
        EngineeringCard(accentColor = PreliminaryAmber) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = PreliminaryAmber, modifier = Modifier.size(18.dp))
                Text(
                    text = bi(lang, "۳. محدودیت‌ها و عدم قطعیت مهندسی", "3. Engineering Limitations & Uncertainty"),
                    style = MaterialTheme.typography.titleMedium,
                    color = PreliminaryAmber
                )
            }
            Spacer(Modifier.height(8.dp))
            outcome.limitations(lang).forEach { item ->
                Text("• $item", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
    }
}

@Composable
private fun MaterialEstimateRow(mat: MaterialEstimate, lang: AppLanguage, currency: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(mat.name(lang), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            if (mat.totalCost > 0) {
                Text(
                    text = "${formatNumber(mat.totalCost, 0)} $currency",
                    style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = EngineeringOrange
                )
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                text = "${bi(lang, "خالص:", "Net:")} ${formatNumber(mat.netQuantity)} ${mat.unit.symbol(lang)} | ${bi(lang, "پرت:", "Waste:")} ${formatNumber(mat.wastePercent, 1)}%",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "${bi(lang, "خرید:", "Order:")} ${formatNumber(mat.orderQuantity)} ${mat.unit.symbol(lang)}",
                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                color = VerifiedGreen
            )
        }
        if (mat.packageCount > 0) {
            Text(
                text = "${bi(lang, "بسته‌بندی:", "Packages:")} ${mat.packageCount.toInt()} ${mat.packageLabel(lang)}",
                style = MaterialTheme.typography.labelMedium,
                color = ElectricBlue
            )
        }
    }
}

/**
 * Custom Canvas Donut Chart for Dashboard Material/Cost breakdown.
 */
@Composable
fun CostBreakdownDonutChart(
    slices: List<Triple<String, Double, Color>>,
    centerLabel: String,
    modifier: Modifier = Modifier
) {
    val total = slices.sumOf { it.second }.coerceAtLeast(1.0)
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(modifier = Modifier.size(120.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(116.dp)) {
                val strokeW = 18.dp.toPx()
                var startAngle = -90f
                val nonZero = slices.filter { it.second > 0 }
                if (nonZero.isEmpty()) {
                    drawArc(
                        color = Color.Gray.copy(alpha = 0.25f),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(width = strokeW)
                    )
                } else {
                    nonZero.forEach { (_, value, color) ->
                        val sweep = ((value / total) * 360.0).toFloat()
                        drawArc(
                            color = color,
                            startAngle = startAngle,
                            sweepAngle = (sweep - 2f).coerceAtLeast(1f),
                            useCenter = false,
                            topLeft = Offset(strokeW / 2f, strokeW / 2f),
                            size = Size(size.width - strokeW, size.height - strokeW),
                            style = Stroke(width = strokeW, cap = StrokeCap.Butt)
                        )
                        startAngle += sweep
                    }
                }
            }
            Text(
                text = centerLabel,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            slices.take(5).forEach { (label, valAmt, color) ->
                val pct = if (total > 0) (valAmt / total) * 100.0 else 0.0
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(color)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(label, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(
                        text = "${formatNumber(pct, 1)}%",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = color
                    )
                }
            }
        }
    }
}
