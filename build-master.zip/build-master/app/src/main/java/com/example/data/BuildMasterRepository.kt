package com.example.data

import com.example.model.BuildingType
import com.example.model.CalculationRecordEntity
import com.example.model.EngineeringUnit
import com.example.model.FoundationType
import com.example.model.FrameType
import com.example.model.MaterialPriceEntity
import com.example.model.ProjectEntity
import com.example.model.SlabType
import com.example.model.UserSettings
import com.example.model.WallType
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class BuildMasterRepository(
    private val db: AppDatabase,
    private val settingsStore: SettingsDataStore
) {
    private val projectDao = db.projectDao()
    private val calculationDao = db.calculationDao()
    private val priceDao = db.materialPriceDao()

    val projects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()
    val calculations: Flow<List<CalculationRecordEntity>> = calculationDao.getAllRecords()
    val materialPrices: Flow<List<MaterialPriceEntity>> = priceDao.getAllPrices()
    val settings: Flow<UserSettings> = settingsStore.settingsFlow
    val activeProjectId: Flow<Long?> = settingsStore.activeProjectIdFlow

    suspend fun ensureDefaultPricesSeeded() {
        val existing = priceDao.getAllPricesSnapshot()
        if (existing.isEmpty()) {
            priceDao.upsertAll(defaultBaselinePrices())
        }
    }

    suspend fun resetDefaultPrices() {
        priceDao.upsertAll(defaultBaselinePrices())
    }

    suspend fun upsertPrice(price: MaterialPriceEntity) {
        priceDao.upsert(price.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deletePrice(key: String) {
        priceDao.deleteByKey(key)
    }

    suspend fun saveProject(project: ProjectEntity): Long {
        val now = System.currentTimeMillis()
        val id = if (project.id == 0L) {
            projectDao.insertProject(project.copy(createdAt = now, updatedAt = now))
        } else {
            projectDao.updateProject(project.copy(updatedAt = now))
            project.id
        }
        settingsStore.setActiveProjectId(id)
        return id
    }

    suspend fun deleteProject(projectId: Long) {
        calculationDao.deleteRecordsByProject(projectId)
        projectDao.deleteProjectById(projectId)
    }

    suspend fun setActiveProject(projectId: Long?) {
        settingsStore.setActiveProjectId(projectId)
    }

    suspend fun saveCalculation(record: CalculationRecordEntity): Long {
        val id = calculationDao.insertRecord(record)
        record.projectId?.let { pid ->
            projectDao.getProjectById(pid)?.let { p ->
                projectDao.updateProject(p.copy(updatedAt = System.currentTimeMillis()))
            }
        }
        return id
    }

    suspend fun deleteCalculation(id: Long) {
        calculationDao.deleteRecordById(id)
    }

    suspend fun updateSettings(transform: (UserSettings) -> UserSettings) {
        settingsStore.updateSettings(transform)
    }

    suspend fun clearAllUserData() {
        calculationDao.clearAllRecords()
        projectDao.clearAllProjects()
        settingsStore.setActiveProjectId(null)
    }

    suspend fun exportBackupJson(singleProjectId: Long? = null): String {
        val projectsList = if (singleProjectId != null) {
            listOfNotNull(projectDao.getProjectById(singleProjectId))
        } else {
            projectDao.getAllProjectsSnapshot()
        }
        val recordsList = if (singleProjectId != null) {
            calculationDao.getAllRecordsSnapshot().filter { it.projectId == singleProjectId }
        } else {
            calculationDao.getAllRecordsSnapshot()
        }
        val pricesList = priceDao.getAllPricesSnapshot()

        val root = JSONObject()
        root.put("app", "BUILD MASTER")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val pArr = JSONArray()
        projectsList.forEach { p ->
            pArr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("location", p.location)
                put("buildingType", p.buildingType.name)
                put("floorsCount", p.floorsCount)
                put("unitsCount", p.unitsCount)
                put("landLengthM", p.landLengthM)
                put("landWidthM", p.landWidthM)
                put("landAreaM2", p.landAreaM2)
                put("floorBuiltUpAreaM2", p.floorBuiltUpAreaM2)
                put("floorHeightM", p.floorHeightM)
                put("frameType", p.frameType.name)
                put("slabType", p.slabType.name)
                put("wallType", p.wallType.name)
                put("foundationType", p.foundationType.name)
                put("wallThicknessCm", p.wallThicknessCm)
                put("roomsCount", p.roomsCount)
                put("bathroomsCount", p.bathroomsCount)
                put("kitchensCount", p.kitchensCount)
                put("materialGradeNote", p.materialGradeNote)
                put("createdAt", p.createdAt)
            })
        }
        root.put("projects", pArr)

        val rArr = JSONArray()
        recordsList.forEach { r ->
            rArr.put(JSONObject().apply {
                put("projectId", r.projectId ?: -1L)
                put("projectNameSnapshot", r.projectNameSnapshot)
                put("toolId", r.toolId)
                put("toolTitleFa", r.toolTitleFa)
                put("toolTitleEn", r.toolTitleEn)
                put("primaryValue", r.primaryValue)
                put("primaryUnit", r.primaryUnit.name)
                put("summaryFa", r.summaryFa)
                put("summaryEn", r.summaryEn)
                put("formulaUsed", r.formulaUsed)
                put("isPreliminary", r.isPreliminary)
                put("estimatedCost", r.estimatedCost)
                put("payloadJson", r.payloadJson)
                put("createdAt", r.createdAt)
            })
        }
        root.put("records", rArr)

        val mArr = JSONArray()
        pricesList.forEach { m ->
            mArr.put(JSONObject().apply {
                put("materialKey", m.materialKey)
                put("nameFa", m.nameFa)
                put("nameEn", m.nameEn)
                put("categoryFa", m.categoryFa)
                put("categoryEn", m.categoryEn)
                put("unit", m.unit.name)
                put("unitPrice", m.unitPrice)
                put("updatedAt", m.updatedAt)
            })
        }
        root.put("prices", mArr)
        return root.toString(2)
    }

    suspend fun importBackupJson(jsonText: String): Int {
        val root = JSONObject(jsonText)
        val pArr = root.optJSONArray("projects") ?: JSONArray()
        val idMapping = mutableMapOf<Long, Long>()
        var importedCount = 0

        for (i in 0 until pArr.length()) {
            val o = pArr.getJSONObject(i)
            val oldId = o.optLong("id", 0L)
            val entity = ProjectEntity(
                name = o.optString("name", "Imported Project"),
                location = o.optString("location", ""),
                buildingType = BuildingType.entries.firstOrNull { it.name == o.optString("buildingType") } ?: BuildingType.RESIDENTIAL,
                floorsCount = o.optInt("floorsCount", 0),
                unitsCount = o.optInt("unitsCount", 0),
                landLengthM = o.optDouble("landLengthM", 0.0),
                landWidthM = o.optDouble("landWidthM", 0.0),
                landAreaM2 = o.optDouble("landAreaM2", 0.0),
                floorBuiltUpAreaM2 = o.optDouble("floorBuiltUpAreaM2", 0.0),
                floorHeightM = o.optDouble("floorHeightM", 0.0),
                frameType = FrameType.entries.firstOrNull { it.name == o.optString("frameType") } ?: FrameType.CONCRETE,
                slabType = SlabType.entries.firstOrNull { it.name == o.optString("slabType") } ?: SlabType.JOIST_BLOCK,
                wallType = WallType.entries.firstOrNull { it.name == o.optString("wallType") } ?: WallType.BRICK,
                foundationType = FoundationType.entries.firstOrNull { it.name == o.optString("foundationType") } ?: FoundationType.STRIP,
                wallThicknessCm = o.optDouble("wallThicknessCm", 0.0),
                roomsCount = o.optInt("roomsCount", 0),
                bathroomsCount = o.optInt("bathroomsCount", 0),
                kitchensCount = o.optInt("kitchensCount", 0),
                materialGradeNote = o.optString("materialGradeNote", ""),
                createdAt = o.optLong("createdAt", System.currentTimeMillis())
            )
            val newId = projectDao.insertProject(entity)
            if (oldId > 0L) idMapping[oldId] = newId
            settingsStore.setActiveProjectId(newId)
            importedCount++
        }

        val rArr = root.optJSONArray("records") ?: JSONArray()
        for (i in 0 until rArr.length()) {
            val o = rArr.getJSONObject(i)
            val oldPid = o.optLong("projectId", -1L)
            val newPid = if (oldPid > 0L) idMapping[oldPid] else null
            val unit = EngineeringUnit.entries.firstOrNull { it.name == o.optString("primaryUnit") } ?: EngineeringUnit.PCS
            calculationDao.insertRecord(
                CalculationRecordEntity(
                    projectId = newPid,
                    projectNameSnapshot = o.optString("projectNameSnapshot", ""),
                    toolId = o.optString("toolId", "LAND_AREA"),
                    toolTitleFa = o.optString("toolTitleFa", ""),
                    toolTitleEn = o.optString("toolTitleEn", ""),
                    primaryValue = o.optDouble("primaryValue", 0.0),
                    primaryUnit = unit,
                    summaryFa = o.optString("summaryFa", ""),
                    summaryEn = o.optString("summaryEn", ""),
                    formulaUsed = o.optString("formulaUsed", ""),
                    isPreliminary = o.optBoolean("isPreliminary", false),
                    estimatedCost = o.optDouble("estimatedCost", 0.0),
                    payloadJson = o.optString("payloadJson", "{}"),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }

        val mArr = root.optJSONArray("prices") ?: JSONArray()
        val importedPrices = mutableListOf<MaterialPriceEntity>()
        for (i in 0 until mArr.length()) {
            val o = mArr.getJSONObject(i)
            val unit = EngineeringUnit.entries.firstOrNull { it.name == o.optString("unit") } ?: EngineeringUnit.PCS
            importedPrices.add(
                MaterialPriceEntity(
                    materialKey = o.getString("materialKey"),
                    nameFa = o.optString("nameFa", ""),
                    nameEn = o.optString("nameEn", ""),
                    categoryFa = o.optString("categoryFa", ""),
                    categoryEn = o.optString("categoryEn", ""),
                    unit = unit,
                    unitPrice = o.optDouble("unitPrice", 0.0),
                    updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
                )
            )
        }
        if (importedPrices.isNotEmpty()) priceDao.upsertAll(importedPrices)
        return importedCount
    }

    companion object {
        fun defaultBaselinePrices(): List<MaterialPriceEntity> {
            val now = System.currentTimeMillis()
            return listOf(
                MaterialPriceEntity("cement", "سیمان پرتلند (کیسه ۵۰ کیلویی)", "Portland Cement (50kg Bag)", "بتن و ملات", "Concrete & Mortar", EngineeringUnit.BAG, 115000.0, now),
                MaterialPriceEntity("ready_concrete", "بتن آماده (مترمکعب)", "Ready-Mix Concrete (m³)", "بتن و ملات", "Concrete & Mortar", EngineeringUnit.M3, 2850000.0, now),
                MaterialPriceEntity("sand", "ماسه شسته (مترمکعب)", "Washed Sand (m³)", "بتن و ملات", "Concrete & Mortar", EngineeringUnit.M3, 620000.0, now),
                MaterialPriceEntity("gravel", "شن دانه‌بندی (مترمکعب)", "Coarse Gravel (m³)", "بتن و ملات", "Concrete & Mortar", EngineeringUnit.M3, 580000.0, now),
                MaterialPriceEntity("rebar", "میلگرد آجدار (کیلوگرم)", "Deformed Rebar (kg)", "آهن‌آلات", "Steel & Rebar", EngineeringUnit.KG, 34500.0, now),
                MaterialPriceEntity("ibeam", "تیرآهن استاندارد (کیلوگرم)", "Standard I-Beam (kg)", "آهن‌آلات", "Steel & Rebar", EngineeringUnit.KG, 36000.0, now),
                MaterialPriceEntity("steel_profile", "پروفیل و ورق فولادی (کیلوگرم)", "Steel Profile / Plate (kg)", "آهن‌آلات", "Steel & Rebar", EngineeringUnit.KG, 38500.0, now),
                MaterialPriceEntity("brick", "آجر فشاری / سفال (عدد)", "Brick Unit (pcs)", "دیوارچینی", "Masonry", EngineeringUnit.PCS, 2900.0, now),
                MaterialPriceEntity("cement_block", "بلوک سیمانی (عدد)", "Cement Block (pcs)", "دیوارچینی", "Masonry", EngineeringUnit.PCS, 18500.0, now),
                MaterialPriceEntity("aac_block", "بلوک هبلکس AAC (عدد)", "AAC Hebelx Block (pcs)", "دیوارچینی", "Masonry", EngineeringUnit.PCS, 42000.0, now),
                MaterialPriceEntity("adhesive", "چسب هبلکس / کاشی (کیسه ۲۵ کیلو)", "Adhesive Mortar (kg)", "دیوارچینی و نازک‌کاری", "Masonry & Finishing", EngineeringUnit.KG, 9500.0, now),
                MaterialPriceEntity("ceramic", "کاشی و سرامیک (مترمربع)", "Ceramic / Wall Tile (m²)", "نازک‌کاری", "Finishing", EngineeringUnit.M2, 420000.0, now),
                MaterialPriceEntity("gypsum", "گچ ساختمانی (کیسه ۴۰ کیلو)", "Gypsum Plaster (40kg Bag)", "نازک‌کاری", "Finishing", EngineeringUnit.BAG, 85000.0, now),
                MaterialPriceEntity("stone", "سنگ نما / کف (مترمربع)", "Building Stone (m²)", "نازک‌کاری", "Finishing", EngineeringUnit.M2, 850000.0, now),
                MaterialPriceEntity("paint", "رنگ ساختمانی (لیتر)", "Building Paint (Liter)", "نازک‌کاری", "Finishing", EngineeringUnit.LITER, 165000.0, now),
                MaterialPriceEntity("pipe", "لوله تأسیسات (متر طول)", "Plumbing Pipe (lm)", "تأسیسات", "MEP", EngineeringUnit.LM, 68000.0, now),
                MaterialPriceEntity("cable", "سیم و کابل برق (متر طول)", "Electrical Wire/Cable (lm)", "تأسیسات", "MEP", EngineeringUnit.LM, 24000.0, now)
            )
        }
    }
}
