package com.example

import com.example.data.BuildMasterRepository
import com.example.engine.CalculationEngine
import com.example.engine.CalculationInput
import com.example.engine.DynamicCostRow
import com.example.engine.DynamicCutRebarRow
import com.example.engine.SciEvalResult
import com.example.engine.ScientificCalculatorEngine
import com.example.engine.ToolCatalog
import com.example.engine.ToolId
import com.example.engine.UnitConverter
import com.example.model.ConcreteMixGrade
import com.example.model.EngineeringUnit
import com.example.model.ProjectEntity
import com.example.model.TileLayoutPattern
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculationEngineAll40ToolsTest {

    private val priceMap = BuildMasterRepository.defaultBaselinePrices().associateBy { it.materialKey }

    @Test
    fun `all 40 tools exist in ToolCatalog and succeed on valid default inputs`() {
        assertEquals(40, ToolId.entries.size)
        assertEquals(40, ToolCatalog.allTools.size)

        val sampleProject = ProjectEntity(
            id = 1L,
            name = "Test Tower",
            floorsCount = 5,
            floorBuiltUpAreaM2 = 200.0,
            floorHeightM = 3.2,
            landLengthM = 25.0,
            landWidthM = 15.0,
            landAreaM2 = 375.0,
            wallThicknessCm = 20.0
        )

        ToolId.entries.forEach { toolId ->
            val (vals, units) = CalculationEngine.buildInitialInputs(toolId, sampleProject, 5.0)
            val input = CalculationInput(
                values = vals,
                units = units,
                project = sampleProject,
                priceCatalog = priceMap,
                cutRebarRows = listOf(DynamicCutRebarRow(1, 16, 12.0, 10)),
                costRows = listOf(DynamicCostRow(1, "cement", "سیمان", "Cement", 100.0, EngineeringUnit.BAG, 115000.0))
            )
            val outcome = CalculationEngine.calculate(toolId, input)
            assertTrue("Tool $toolId failed: ${outcome.errorEn}", outcome.isSuccess)
            assertTrue("Tool $toolId missing assumptions", outcome.assumptionsEn.isNotEmpty())
            assertTrue("Tool $toolId missing limitations", outcome.limitationsEn.isNotEmpty())
            assertTrue("Tool $toolId missing formula", outcome.formulaUsed.isNotBlank())
        }
    }

    @Test
    fun `all 40 tools reject negative inputs and NaN`() {
        ToolId.entries.forEach { toolId ->
            val def = ToolCatalog.get(toolId)
            val firstField = def.fields.first()
            val (vals, units) = CalculationEngine.buildInitialInputs(toolId, null, 5.0)

            val negVals = vals.toMutableMap().apply { put(firstField.key, -5.0) }
            val negRes = CalculationEngine.calculate(toolId, CalculationInput(values = negVals, units = units))
            assertFalse("Tool $toolId should reject negative ${firstField.key}", negRes.isSuccess)

            val nanVals = vals.toMutableMap().apply { put(firstField.key, Double.NaN) }
            val nanRes = CalculationEngine.calculate(toolId, CalculationInput(values = nanVals, units = units))
            assertFalse("Tool $toolId should reject NaN ${firstField.key}", nanRes.isSuccess)
        }
    }

    @Test
    fun `all 40 tools handle zero on strict positive fields and large values safely`() {
        ToolId.entries.forEach { toolId ->
            val def = ToolCatalog.get(toolId)
            val (vals, units) = CalculationEngine.buildInitialInputs(toolId, null, 5.0)

            val strictField = def.fields.firstOrNull { !it.allowZero }
            if (strictField != null) {
                val zeroVals = vals.toMutableMap().apply { put(strictField.key, 0.0) }
                val zeroRes = CalculationEngine.calculate(toolId, CalculationInput(values = zeroVals, units = units))
                assertFalse("Tool $toolId should reject zero on ${strictField.key}", zeroRes.isSuccess)
            }

            // Very large value check
            val largeField = def.fields.firstOrNull { it.key != "waste" && it.key != "sparePercent" && it.key != "contingencyPercent" }
            if (largeField != null) {
                val largeVals = vals.toMutableMap().apply { put(largeField.key, 100_000.0) }
                val largeRes = CalculationEngine.calculate(toolId, CalculationInput(values = largeVals, units = units, priceCatalog = priceMap))
                assertTrue("Tool $toolId failed on large value: ${largeRes.errorEn}", largeRes.isSuccess)
                assertFalse(largeRes.primaryValue.isNaN() || largeRes.primaryValue.isInfinite())
            }
        }
    }

    @Test
    fun `reference engineering formulas produce exact hand-calculated results`() {
        // 1. Rebar weight: d=16mm, L=12m, N=50, waste=0% -> (256/162)*12*50 = 948.15 kg
        val rebarOut = CalculationEngine.calculate(
            ToolId.REBAR_WEIGHT,
            CalculationInput(
                values = mapOf("diameter" to 16.0, "length" to 12.0, "count" to 50.0, "waste" to 0.0),
                units = mapOf("diameter" to EngineeringUnit.MM, "length" to EngineeringUnit.M),
                priceCatalog = priceMap
            )
        )
        assertTrue(rebarOut.isSuccess)
        assertEquals(948.15, rebarOut.primaryValue, 0.05)

        // 2. Floor ceramic: 10m x 10m = 100m2, 10% waste -> 110.0 m2
        val tileOut = CalculationEngine.calculate(
            ToolId.FLOOR_CERAMIC,
            CalculationInput(
                values = mapOf(
                    "roomLength" to 10.0, "roomWidth" to 10.0,
                    "tileLength" to 60.0, "tileWidth" to 60.0,
                    "boxCoverage" to 1.44, "waste" to 10.0
                ),
                units = mapOf(
                    "roomLength" to EngineeringUnit.M, "roomWidth" to EngineeringUnit.M,
                    "tileLength" to EngineeringUnit.CM, "tileWidth" to EngineeringUnit.CM
                ),
                tilePattern = TileLayoutPattern.RUNNING_BOND
            )
        )
        assertTrue(tileOut.isSuccess)
        assertEquals(110.0, tileOut.primaryValue, 0.01)

        // 3. I-Beam IPE180 (18.8 kg/m) * 12m * 5pcs * 0% waste = 1128.0 kg
        val ibeamOut = CalculationEngine.calculate(
            ToolId.IBEAM_WEIGHT,
            CalculationInput(
                values = mapOf("length" to 12.0, "count" to 5.0, "waste" to 0.0),
                units = mapOf("length" to EngineeringUnit.M),
                selectedIBeamCode = "IPE180"
            )
        )
        assertTrue(ibeamOut.isSuccess)
        assertEquals(1128.0, ibeamOut.primaryValue, 0.01)

        // 4. Concrete mix varies with mix grade (M15 vs M25)
        val m15 = CalculationEngine.calculate(
            ToolId.CONCRETE_MIX_MATERIALS,
            CalculationInput(values = mapOf("volume" to 10.0, "dryFactor" to 1.54, "waste" to 0.0), mixGrade = ConcreteMixGrade.M15_1_2_4)
        )
        val m25 = CalculationEngine.calculate(
            ToolId.CONCRETE_MIX_MATERIALS,
            CalculationInput(values = mapOf("volume" to 10.0, "dryFactor" to 1.54, "waste" to 0.0), mixGrade = ConcreteMixGrade.M25_1_1_2)
        )
        assertEquals(60.0, m15.primaryValue, 0.1) // 10 * 300 / 50 = 60 bags
        assertEquals(80.0, m25.primaryValue, 0.1) // 10 * 400 / 50 = 80 bags
    }

    @Test
    fun `unit conversions and incomplete project preliminary flagging work`() {
        assertEquals(2.5, UnitConverter.convert(250.0, EngineeringUnit.CM, EngineeringUnit.M), 0.0001)
        assertEquals(15.0, UnitConverter.convert(15000.0, EngineeringUnit.KG, EngineeringUnit.TON), 0.0001)

        val incompleteProj = ProjectEntity(name = "Partial Project", floorsCount = 0)
        val out = CalculationEngine.calculate(
            ToolId.BUILT_UP_AREA,
            CalculationInput(
                values = mapOf("floors" to 2.0, "floorArea" to 100.0, "extraArea" to 0.0),
                project = incompleteProj
            )
        )
        assertTrue(out.isSuccess)
        assertTrue(out.isPreliminary)
    }

    @Test
    fun `scientific calculator evaluates expressions and handles errors`() {
        val r1 = ScientificCalculatorEngine.evaluate("2 + 3 * (4^2) - sqrt(144)", useDegrees = true)
        assertTrue(r1 is SciEvalResult.Success)
        assertEquals(38.0, (r1 as SciEvalResult.Success).value, 0.0001)

        val r2 = ScientificCalculatorEngine.evaluate("sin(30) + cos(60)", useDegrees = true)
        assertTrue(r2 is SciEvalResult.Success)
        assertEquals(1.0, (r2 as SciEvalResult.Success).value, 0.0001)

        val divZero = ScientificCalculatorEngine.evaluate("10 / (5 - 5)")
        assertTrue(divZero is SciEvalResult.Error)

        val badParen = ScientificCalculatorEngine.evaluate("(2 + 3")
        assertTrue(badParen is SciEvalResult.Error)
    }
}
