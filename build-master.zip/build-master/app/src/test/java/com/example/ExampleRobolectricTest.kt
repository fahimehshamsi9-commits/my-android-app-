package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.BuildMasterRepository
import com.example.data.SettingsDataStore
import com.example.export.ReportExporter
import com.example.model.BuildingType
import com.example.model.CalculationRecordEntity
import com.example.model.EngineeringUnit
import com.example.model.ProjectEntity
import com.example.model.UserSettings
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("BUILD MASTER", appName)
    }

    @Test
    fun `room persistence, backup export-import, and PDF-Excel export work offline`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val settingsStore = SettingsDataStore(context)
        val repo = BuildMasterRepository(db, settingsStore)

        repo.ensureDefaultPricesSeeded()
        val prices = repo.materialPrices.first()
        assertTrue(prices.isNotEmpty())

        val projectId = repo.saveProject(
            ProjectEntity(
                name = "ساختمان مهر",
                location = "تهران",
                buildingType = BuildingType.RESIDENTIAL,
                floorsCount = 4,
                floorBuiltUpAreaM2 = 180.0,
                floorHeightM = 3.2,
                landLengthM = 20.0,
                landWidthM = 12.0,
                landAreaM2 = 240.0,
                wallThicknessCm = 20.0
            )
        )
        assertTrue(projectId > 0)

        repo.saveCalculation(
            CalculationRecordEntity(
                projectId = projectId,
                projectNameSnapshot = "ساختمان مهر",
                toolId = "REBAR_WEIGHT",
                toolTitleFa = "محاسبه وزن میلگرد",
                toolTitleEn = "Rebar Weight",
                primaryValue = 948.15,
                primaryUnit = EngineeringUnit.KG,
                summaryFa = "۹۴۸.۱۵ کیلوگرم",
                summaryEn = "948.15 kg",
                formulaUsed = "W = (d^2 / 162) * L * N",
                isPreliminary = false,
                estimatedCost = 32711175.0,
                payloadJson = "{}"
            )
        )

        val savedProj = repo.projects.first().first()
        val savedRecs = repo.calculations.first()
        assertEquals(1, savedRecs.size)

        // Verify JSON backup & restore
        val backupJson = repo.exportBackupJson()
        repo.clearAllUserData()
        assertTrue(repo.projects.first().isEmpty())
        val imported = repo.importBackupJson(backupJson)
        assertEquals(1, imported)
        assertEquals(1, repo.calculations.first().size)

        // Verify PDF & Excel generation
        val pdfBytes = ReportExporter.generatePdfBytes(savedProj, savedRecs, UserSettings())
        assertTrue(pdfBytes.size > 100)
        val header = String(pdfBytes.copyOfRange(0, 4))
        assertEquals("%PDF", header)

        val excelXml = ReportExporter.generateExcelXml(savedProj, savedRecs, UserSettings())
        assertTrue(excelXml.contains("<Workbook"))
        assertTrue(excelXml.contains("Materials_BOQ"))

        db.close()
    }
}
